port module Main exposing (main)

import ApplicationCreator as AppCreator
import ApplicationPlayer as Play
import Browser exposing (..)
import Browser.Dom as DOM exposing (Error, Viewport, getViewport)
import Browser.Events exposing (onAnimationFrame)
import Browser.Navigation as Nav exposing (..)
import Chat_Creator exposing (..)
import Element as L exposing (..)
import Element.Background as Bg exposing (color, gradient)
import Element.Border as Border exposing (..)
import Element.Events as Events exposing (..)
import Element.Font as Font
import Element.Input as Input exposing (button)
import File as File
import Graphic_Downloader as GraphicList exposing (..)
import Graphic_Element as GraphEl exposing (..)
import Html exposing (map)
import Html.Events exposing (custom, on)
import Html.Events.Extra.Drag as Drag exposing (..)
import Http exposing (Progress)
import Json.Decode as Decode
import Json.Encode as E
import Platform.Sub as Sub exposing (batch)
import SubstancePlayer as Sub exposing (..)
import Task exposing (..)
import Time exposing (Posix)
import Tuple exposing (first, second)
import Url exposing (..)
import Url.Builder as Builder



-- MODEL


type alias LucasUrl =
    { scheme : String
    , urlPath : String
    }


type alias UserInfo =
    { userId : String
    , login : String
    , uploadImageId : String
    , uploadVideoId : String
    }


type alias FriendInfo =
    { userId : String
    , login : String
    }


type DisplayMode
    = ChatDisplay
    | LoginDisplay
    | ChatMessages
    | PlayApplication
    | UploadFile
    | SelectMedia
    | ViewSubstance
    | DicoSubstance
    | ApplicationModule
    | TableSubstance


type Externals
    = None
    | ChatModel Chat_Creator.Model


type alias Model =
    { userInfo : Maybe UserInfo
    , errorMsg : Http.Error
    , navKey : Key
    , chatMsg : Maybe (List ChatData)
    , friends : Maybe (List FriendInfo)
    , displayMode : DisplayMode
    , imgChoices : GraphicList.GraphicData Msg
    , vidChoices : GraphicList.GraphicData Msg
    , subChoices : Sub.SelectElement Msg
    , subEditor : GraphEl.ElementEdited Msg
    , appEditor : AppCreator.AppEdited Msg
    , player : Play.PlayApp Msg
    , dloadValue : Float
    , uploadValue : Float
    , backendCall : String
    , successFileList : List String
    , failFileList : List String
    , totalFileList : List File.File
    , externals : Externals
    }



-- INIT


init : Maybe UserInfo -> Url -> Key -> ( Model, Cmd Msg )
init jsData url key =
    ( { userInfo = jsData
      , navKey = key
      , errorMsg = Http.Timeout
      , displayMode = LoginDisplay
      , chatMsg = Maybe.Nothing
      , friends = Maybe.Nothing
      , imgChoices = GraphicList.initGraphic "0" "image" ImagesPicked LoadNextImagesSet LoadPreviousImagesSet
      , vidChoices = GraphicList.initGraphic "0" "video" VideosPicked LoadNextVideosSet LoadPreviousVideosSet
      , subChoices = Sub.initSelectElement "0" SubstancePicked SubstanceChosen AppSubstancePicked LoadPreviousSubstanceSet LoadNextSubstanceSet CleanDico
      , subEditor = GraphEl.initElement CreerPotentielle CreerMotrice CreerRelation SelectImage SelectVideo SetTitle SelectSubstance DeploySelectedSubstance EnregistrerSubstance "0"
      , appEditor = AppCreator.initApp CreerNouvelleApplication SelectImage SetModTitle SelectSequence "0" EditApplication InitialiserApplication
      , player = Play.initPlayer ActivateApplication "0" MessageAcquisition CancelSelection ConfirmMessage SenderOfData SubstancePicker ZoomCancel ContainerPicker Reseteur Closit ZoomRecord RecordInFile AppMenuHandler ShareAllUserChecked
      , dloadValue = 0
      , uploadValue = 0
      , backendCall = ""
      , externals = None
      , successFileList = []
      , failFileList = []
      , totalFileList = []
      }
    , let
        infos =
            jsData
      in
      case url.path of
        "/user" ->
            Nav.load (Url.toString url)

        somethingElse ->
            case infos of
                Maybe.Nothing ->
                    case url.fragment of
                        Maybe.Nothing ->
                            Cmd.none

                        Maybe.Just frag ->
                            case frag of
                                "_=_" ->
                                    Http.get
                                        { url = "/user"
                                        , expect = Http.expectJson LoginAndGetUser decodeUserId
                                        }

                                otherwise ->
                                    Cmd.none

                Maybe.Just _ ->
                    Nav.pushUrl key (Url.toString url)
    )


decodeUserId : Decode.Decoder UserInfo
decodeUserId =
    Decode.map4 UserInfo
        (Decode.field "userId" Decode.string)
        (Decode.field "login" Decode.string)
        (Decode.field "uploadImageId" Decode.string)
        (Decode.field "uploadVideoId" Decode.string)


decodeFriendsData : Decode.Decoder (List FriendInfo)
decodeFriendsData =
    Decode.list
        (Decode.map2 FriendInfo
            (Decode.field "userId" Decode.string)
            (Decode.field "login" Decode.string)
        )


decodeChatData : Decode.Decoder (Maybe (List ChatData))
decodeChatData =
    Decode.nullable
        (Decode.list
            (Decode.map3 ChatData
                (Decode.field "completedWidgets"
                    (Decode.list
                        (Decode.map5 VisualWidget
                            (Decode.field "displayUrl" Decode.string)
                            (Decode.field "tools"
                                (Decode.list
                                    (Decode.map4 ToolWidget
                                        (Decode.field "displayUrl" Decode.string)
                                        (Decode.field "position"
                                            (Decode.map2 Coordinate
                                                (Decode.field "clientX" Decode.float)
                                                (Decode.field "clientY" Decode.float)
                                            )
                                        )
                                        (Decode.field "widgetId" Decode.int)
                                        (Decode.field "parentId" Decode.int)
                                    )
                                )
                            )
                            (Decode.field "position"
                                (Decode.map2 Coordinate
                                    (Decode.field "clientX" Decode.float)
                                    (Decode.field "clientY" Decode.float)
                                )
                            )
                            (Decode.field "widgetId" Decode.int)
                            (Decode.field "category"
                                (Decode.string
                                    |> Decode.andThen
                                        (\string ->
                                            case string of
                                                "Image" ->
                                                    Decode.succeed Image

                                                "Video" ->
                                                    Decode.succeed Video

                                                _ ->
                                                    Decode.fail "Invalid WidgetNature"
                                        )
                                )
                            )
                        )
                    )
                )
                (Decode.field "groupWidgets"
                    (Decode.list
                        (Decode.map5 GroupWidget
                            (Decode.field "displayUrl" Decode.string)
                            (Decode.field "widgetId" Decode.int)
                            (Decode.field "position"
                                (Decode.map2 Coordinate
                                    (Decode.field "clientX" Decode.float)
                                    (Decode.field "clientY" Decode.float)
                                )
                            )
                            (Decode.field "constituant"
                                (Decode.list
                                    (Decode.map5 VisualWidget
                                        (Decode.field "displayUrl" Decode.string)
                                        (Decode.field "tools"
                                            (Decode.list
                                                (Decode.map4 ToolWidget
                                                    (Decode.field "displayUrl" Decode.string)
                                                    (Decode.field "position"
                                                        (Decode.map2 Coordinate
                                                            (Decode.field "clientX" Decode.float)
                                                            (Decode.field "clientY" Decode.float)
                                                        )
                                                    )
                                                    (Decode.field "widgetId" Decode.int)
                                                    (Decode.field "parentId" Decode.int)
                                                )
                                            )
                                        )
                                        (Decode.field "position"
                                            (Decode.map2 Coordinate
                                                (Decode.field "clientX" Decode.float)
                                                (Decode.field "clientY" Decode.float)
                                            )
                                        )
                                        (Decode.field "widgetId" Decode.int)
                                        (Decode.field "category"
                                            (Decode.string
                                                |> Decode.andThen
                                                    (\string ->
                                                        case string of
                                                            "Image" ->
                                                                Decode.succeed Image

                                                            "Video" ->
                                                                Decode.succeed Video

                                                            _ ->
                                                                Decode.fail "Invalid WidgetNature"
                                                    )
                                            )
                                        )
                                    )
                                )
                            )
                            (Decode.field "answer" Decode.int)
                        )
                    )
                )
                (Decode.field "contactId" Decode.string)
            )
        )


decodeFiles : Decode.Decoder (List File.File)
decodeFiles =
    Decode.field "dataTransfer" (Decode.field "files" (Decode.list File.decoder))



-- UPDATE


type Msg
    = LoginAndGetUser (Result Http.Error UserInfo)
    | GotMail (Result Http.Error (Maybe (List ChatData)))
    | GotFriends (Result Http.Error (List FriendInfo))
    | Start Drag.Event
    | RequestUrl UrlRequest
    | ChangeUrl Url
    | Chat Chat_Creator.Msg
    | Stream E.Value
    | Edit_Chat ChatData
    | SendFiles Drag.Event
    | FileSuccess (Result Http.Error ())
    | FileCode File.File (Result Http.Error String)
    | AppInfoListe (Result Http.Error AppCreator.ListeAppInfo)
    | LoadNextImagesSet
    | LoadPreviousImagesSet
    | ImagesPicked String
    | IconePicked String
    | GotImagesList (Result Http.Error GraphicList)
    | LoadNextVideosSet
    | LoadPreviousVideosSet
    | VideosPicked String
    | GotVideosList (Result Http.Error GraphicList)
    | SelectImage
    | SelectVideo
    | SetTitle String
    | SetModTitle String
    | SelectSubstance
    | SelectSequence String String
    | DeploySelectedSubstance GraphEl.CanvasSubstance
    | LoadPreviousSubstanceSet
    | LoadNextSubstanceSet
    | GotSubstanceList (Result Http.Error Sub.SubstanceList)
    | GotSequenceList (Result Http.Error Sub.SubstanceList)
    | CreerPotentielle
    | CreerMotrice
    | CreerRelation
    | CreerNouvelleApplication AppCreator.CanvasApplication
    | InitialiserApplication AppCreator.CanvasApplication
    | EditApplication AppCreator.CanvasApplication Play.AppInfo
    | SubstancePicked Sub.Substance
    | AppSubstancePicked Sub.Substance
    | EnregistrerSubstance
    | SubstanceDone (Result Http.Error ())
    | ApplicationDone (Result Http.Error ())
    | Progression Http.Progress
    | GotScreenSize (Result Error DOM.Viewport)
    | SubstanceChosen Substance
    | CleanDico
    | SelectNewMedia String
    | FileTelecharge String (Result Http.Error ())
    | ActivateApplication Play.AppInfo
    | AppDetailsLoaded (Result Http.Error (List Play.ElementInteractif))
    | MessageAcquisition Play.SubstanceInteractive String
    | CancelSelection Play.SubstanceInteractive String
    | ConfirmMessage Play.Geste
    | SenderOfData Play.InterfaceInteractive String
    | SubstancePicker Play.SubstanceInactive Sub.Substance
    | DeploySubstance Play.SubstanceInactive Sub.Substance
    | ZoomSubstance Sub.Substance
    | ZoomCancel
    | ContainerPicker Play.SubstanceContainer Play.ElementGraphique
    | DeploySequence Play.ElementGraphique Play.Geste
    | Reseteur
    | Closit
    | ZoomRecord
    | RecordInFile
    | AppMenuHandler Play.AppInfo
    | ShareApplication Play.AppInfo
    | ShareAllUserChecked Bool


updateChatWith : (Externals -> Model) -> (subMsg -> Msg) -> Model -> ( Chat_Creator.Model, Cmd subMsg ) -> ( Model, Cmd Msg )
updateChatWith toModel toMsg model ( subModel, subCmd ) =
    ( toModel (ChatModel subModel)
    , Cmd.map toMsg subCmd
    )


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        Start _ ->
            ( model, Cmd.none )

        RequestUrl request ->
            case request of
                Browser.Internal url ->
                    case url.path of
                        "/login/facebook" ->
                            ( model, Nav.load (Url.toString url) )

                        "github/login" ->
                            ( model, Nav.load (Url.toString url) )

                        somethingElse ->
                            case model.userInfo of
                                Maybe.Nothing ->
                                    ( model, Cmd.none )

                                Maybe.Just _ ->
                                    ( model, Nav.pushUrl model.navKey (Url.toString url) )

                Browser.External url ->
                    ( model, Cmd.none )

        ChangeUrl url ->
            case url.path of
                "/chat" ->
                    case model.friends of
                        Maybe.Just lstFriends ->
                            ( { model | displayMode = ChatMessages }, Cmd.none )

                        Maybe.Nothing ->
                            case model.userInfo of
                                Maybe.Just userData ->
                                    ( model
                                    , let
                                        msgPath =
                                            Builder.absolute [ "downloadFriends" ]
                                                [ Builder.string "userId"
                                                    userData.userId
                                                ]
                                      in
                                      Http.get
                                        { url = msgPath
                                        , expect = Http.expectJson GotFriends decodeFriendsData
                                        }
                                    )

                                Maybe.Nothing ->
                                    ( model, Cmd.none )

                "/multimedia" ->
                    ( { model | displayMode = UploadFile }, Cmd.none )

                "/didactique" ->
                    ( { model | displayMode = PlayApplication, player = Play.resetPlayer model.player }
                    , Cmd.batch
                        [ attempt GotScreenSize <| DOM.getViewport
                        , let
                            msgPath =
                                Builder.absolute [ "getUserApplications" ]
                                    [ Builder.string "userId"
                                        model.imgChoices.userId
                                    ]
                          in
                          Http.get
                            { url = msgPath
                            , expect = Http.expectJson AppInfoListe AppCreator.decodeAppState
                            }
                        ]
                    )

                "/dictionnaire" ->
                    ( { model
                        | displayMode = DicoSubstance
                        , imgChoices =
                            GraphicList.initGraphic model.imgChoices.userId
                                "image"
                                ImagesPicked
                                LoadNextImagesSet
                                LoadPreviousImagesSet
                      }
                    , Cmd.none
                    )

                "/applicationModule" ->
                    ( { model
                        | displayMode = ApplicationModule
                        , imgChoices =
                            GraphicList.initGraphic model.imgChoices.userId
                                "image"
                                IconePicked
                                LoadNextImagesSet
                                LoadPreviousImagesSet
                        , appEditor = AppCreator.resetApplication model.appEditor
                      }
                    , let
                        msgPath =
                            Builder.absolute [ "getUserApplications" ]
                                [ Builder.string "userId"
                                    model.imgChoices.userId
                                ]
                      in
                      Http.get
                        { url = msgPath
                        , expect = Http.expectJson AppInfoListe AppCreator.decodeAppState
                        }
                    )

                "/tableSubstance" ->
                    ( { model | displayMode = TableSubstance, backendCall = "downloadSubstancePage" }, Sub.obtainGraphicList model.subChoices GotSubstanceList "downloadSubstancePage" )

                "/login" ->
                    ( { model
                        | displayMode = LoginDisplay
                        , appEditor = AppCreator.resetApplication model.appEditor
                        , player = Play.closePlayer model.player
                        , subEditor = GraphEl.resetSubstance model.subEditor
                      }
                    , Cmd.none
                    )

                somethingElse ->
                    ( model, Cmd.none )

        LoginAndGetUser (Result.Ok userData) ->
            ( { model
                | userInfo = Maybe.Just userData
                , imgChoices = GraphicList.initGraphic userData.userId "image" ImagesPicked LoadNextImagesSet LoadPreviousImagesSet
                , vidChoices = GraphicList.initGraphic userData.userId "video" VideosPicked LoadNextVideosSet LoadPreviousVideosSet
                , subEditor = GraphEl.initElement CreerPotentielle CreerMotrice CreerRelation SelectImage SelectVideo SetTitle SelectSubstance DeploySelectedSubstance EnregistrerSubstance userData.userId
                , subChoices = Sub.initSelectElement userData.userId SubstancePicked SubstanceChosen AppSubstancePicked LoadPreviousSubstanceSet LoadNextSubstanceSet CleanDico
                , appEditor = AppCreator.initApp CreerNouvelleApplication SelectImage SetModTitle SelectSequence userData.userId EditApplication InitialiserApplication
                , player = Play.initPlayer ActivateApplication userData.userId MessageAcquisition CancelSelection ConfirmMessage SenderOfData SubstancePicker ZoomCancel ContainerPicker Reseteur Closit ZoomRecord RecordInFile AppMenuHandler ShareAllUserChecked
              }
            , Cmd.none
            )

        LoginAndGetUser (Result.Err errMsg) ->
            ( { model | errorMsg = errMsg }, Cmd.none )

        AppInfoListe (Result.Err errMsg) ->
            ( { model | errorMsg = errMsg }, Cmd.none )

        AppInfoListe (Result.Ok appState) ->
            ( { model | appEditor = AppCreator.addAppState model.appEditor appState, player = Play.addPlayState model.player appState.activeApplication }
            , Cmd.none
            )

        GotFriends (Result.Err errMsg) ->
            ( { model | errorMsg = errMsg }, Cmd.none )

        GotFriends (Result.Ok lstFriends) ->
            case model.userInfo of
                Maybe.Just userData ->
                    ( { model | friends = Maybe.Just lstFriends, displayMode = ChatMessages }
                    , let
                        msgPath =
                            Builder.absolute [ "downloadChatMsg" ]
                                [ Builder.string "userId"
                                    userData.userId
                                ]
                      in
                      Http.get
                        { url = msgPath
                        , expect = Http.expectJson GotMail decodeChatData
                        }
                    )

                Maybe.Nothing ->
                    ( model, Cmd.none )

        GotMail (Result.Err errMsg) ->
            ( { model | errorMsg = errMsg }, Cmd.none )

        GotMail (Result.Ok resultLst) ->
            ( { model | chatMsg = resultLst }, Cmd.none )

        CreerPotentielle ->
            ( { model | subEditor = GraphEl.createSubstancePotentielle model.subEditor }, Cmd.none )

        CreerMotrice ->
            ( { model | subEditor = GraphEl.creerSubstanceMotrice model.subEditor }, Cmd.none )

        CreerRelation ->
            ( { model | subEditor = GraphEl.creerSubstanceRelation model.subEditor }, Cmd.none )

        CreerNouvelleApplication canvas ->
            ( { model | appEditor = AppCreator.creerApplication model.appEditor canvas }, Cmd.none )

        InitialiserApplication canvas ->
            ( model, AppCreator.initializeApplicationModule model.appEditor canvas FileSuccess )

        EditApplication canvas info ->
            ( { model | appEditor = AppCreator.editSelectedApplication model.appEditor canvas info }, Cmd.none )

        SelectImage ->
            ( { model | displayMode = SelectMedia }, GraphicList.obtainGraphicList model.imgChoices GotImagesList )

        SetTitle titre ->
            ( { model | subEditor = GraphEl.ajouterTitre model.subEditor titre }, Cmd.none )

        SetModTitle titre ->
            ( { model | appEditor = AppCreator.setTitle model.appEditor titre }, Cmd.none )

        SelectVideo ->
            ( { model | displayMode = SelectMedia }, GraphicList.obtainGraphicList model.vidChoices GotVideosList )

        SelectSubstance ->
            ( { model
                | subChoices = Sub.resetPaging model.subChoices
                , displayMode = ViewSubstance
                , backendCall = "downloadSubstancePage"
              }
            , Sub.obtainGraphicList model.subChoices GotSubstanceList "downloadSubstancePage"
            )

        SelectSequence metaData appId ->
            ( { model
                | subChoices = Sub.resetPaging model.subChoices
                , displayMode = ViewSubstance
                , backendCall = "downloadMetaSubstancePage"
              }
            , AppCreator.obtainMetaSearchResult model.subChoices metaData appId GotSequenceList "downloadMetaSubstancePage"
            )

        DeploySelectedSubstance depSub ->
            ( model, Cmd.none )

        EnregistrerSubstance ->
            ( model
            , GraphEl.expedieSubstance model.subEditor SubstanceDone
            )

        SubstanceDone (Result.Err _) ->
            ( model, Cmd.none )

        SubstanceDone (Result.Ok _) ->
            ( { model | subEditor = GraphEl.resetSubstance model.subEditor }, Cmd.none )

        ApplicationDone (Result.Err _) ->
            ( model, Cmd.none )

        ApplicationDone (Result.Ok _) ->
            ( { model | appEditor = AppCreator.resetApplication model.appEditor }, Cmd.none )

        LoadNextImagesSet ->
            case model.imgChoices.graphicPages of
                Maybe.Just pages ->
                    let
                        choices =
                            model.imgChoices
                    in
                    if model.imgChoices.currentPage + 2 > List.length pages then
                        ( { model | imgChoices = { choices | currentPage = choices.currentPage + 1 } }
                        , GraphicList.nextGraphicList model.imgChoices GotImagesList
                        )

                    else
                        ( { model | imgChoices = GraphicList.updateGraphicData { choices | currentPage = choices.currentPage + 1 } }
                        , Cmd.none
                        )

                Maybe.Nothing ->
                    ( model, Cmd.none )

        LoadPreviousImagesSet ->
            let
                choices =
                    model.imgChoices
            in
            ( { model | imgChoices = GraphicList.updateGraphicData { choices | currentPage = choices.currentPage - 1 } }
            , Cmd.none
            )

        LoadNextVideosSet ->
            case model.vidChoices.graphicPages of
                Maybe.Just pages ->
                    let
                        choices =
                            model.vidChoices
                    in
                    if model.vidChoices.currentPage + 2 > List.length pages then
                        ( { model | vidChoices = { choices | currentPage = choices.currentPage + 1 } }
                        , GraphicList.nextGraphicList model.vidChoices GotVideosList
                        )

                    else
                        ( { model | vidChoices = GraphicList.updateGraphicData { choices | currentPage = choices.currentPage + 1 } }
                        , Cmd.none
                        )

                Maybe.Nothing ->
                    ( model, Cmd.none )

        LoadPreviousVideosSet ->
            let
                choices =
                    model.vidChoices
            in
            ( { model | vidChoices = GraphicList.updateGraphicData { choices | currentPage = choices.currentPage - 1 } }
            , Cmd.none
            )

        LoadPreviousSubstanceSet ->
            let
                choices =
                    model.subChoices
            in
            ( { model | subChoices = Sub.updateGraphicData { choices | currentPage = choices.currentPage - 1 } }
            , Cmd.none
            )

        LoadNextSubstanceSet ->
            let
                choices =
                    model.subChoices
            in
            ( { model | subChoices = Sub.updateGraphicData { choices | currentPage = choices.currentPage + 1 } }
            , Sub.nextGraphicList model.subChoices GotSubstanceList model.backendCall
            )

        GotImagesList (Result.Ok imagesPackage) ->
            ( { model
                | imgChoices =
                    GraphicList.addNewPage imagesPackage model.imgChoices
                        |> GraphicList.updateGraphicData
              }
              -- , GraphicList.obtainGraphicList model.videoChoices GotVideoList
            , Cmd.none
            )

        GotImagesList (Result.Err error) ->
            ( { model | errorMsg = error }, Cmd.none )

        GotVideosList (Result.Ok videosPackage) ->
            ( { model
                | vidChoices =
                    GraphicList.addNewPage videosPackage model.vidChoices
                        |> GraphicList.updateGraphicData
              }
            , Cmd.none
            )

        GotVideosList (Result.Err error) ->
            ( { model | errorMsg = error }, Cmd.none )

        GotSubstanceList (Result.Err error) ->
            ( { model | errorMsg = error }, Cmd.none )

        GotSubstanceList (Result.Ok subList) ->
            ( { model | subChoices = Sub.addNewPage subList model.subChoices |> Sub.updateGraphicData }
            , Cmd.none
            )

        GotSequenceList (Result.Err error) ->
            ( { model | errorMsg = error }, Cmd.none )

        GotSequenceList (Result.Ok subList) ->
            ( { model | subChoices = Sub.addNewPage subList model.subChoices |> Sub.updateGraphicData }
            , Cmd.none
            )

        ImagesPicked src ->
            ( { model
                | subEditor = GraphEl.definirMedia model.subEditor src
                , displayMode = DicoSubstance
              }
            , Cmd.none
            )

        IconePicked src ->
            ( model
            , Cmd.none
            )

        VideosPicked src ->
            ( { model
                | subEditor = GraphEl.definirMedia model.subEditor src
                , displayMode = DicoSubstance
              }
            , Cmd.none
            )

        SubstancePicked sub ->
            ( { model
                | subEditor = GraphEl.addSubstance model.subEditor sub
                , displayMode = DicoSubstance
              }
            , Cmd.none
            )

        SubstanceChosen sub ->
            case sub of
                Potential _ ->
                    ( { model
                        | subChoices = Sub.recordSubstance model.subChoices sub
                        , displayMode = SelectMedia
                        , imgChoices = GraphicList.changeClickAction model.imgChoices SelectNewMedia
                      }
                    , GraphicList.obtainGraphicList model.vidChoices GotImagesList
                    )

                _ ->
                    ( { model
                        | subChoices = Sub.recordSubstance model.subChoices sub
                        , displayMode = SelectMedia
                        , vidChoices = GraphicList.changeClickAction model.vidChoices SelectNewMedia
                      }
                    , GraphicList.obtainGraphicList model.vidChoices GotVideosList
                    )

        SelectNewMedia media ->
            ( model, Sub.modifySubstanceMedia model.subChoices media FileSuccess )

        AppSubstancePicked seq ->
            ( { model
                | appEditor = AppCreator.addAppSubstance model.appEditor seq
                , displayMode = ApplicationModule
              }
            , AppCreator.addMetaSubstance model.appEditor seq FileSuccess
            )

        ActivateApplication appChoiceInfo ->
            ( { model | player = Play.setChosenApp model.player appChoiceInfo }, Play.executeLaunchApp model.player appChoiceInfo.appId AppDetailsLoaded )

        AppDetailsLoaded (Result.Err error) ->
            ( { model | errorMsg = error }, Cmd.none )

        AppDetailsLoaded (Result.Ok lstRez) ->
            ( { model | displayMode = PlayApplication, player = Play.loadUpData model.player lstRez }, Cmd.none )

        MessageAcquisition interSub substance ->
            ( { model | player = Play.substanceClicked model.player interSub substance }, Cmd.none )

        CancelSelection interSub substance ->
            ( { model | player = Play.cancelSubstanceSelection model.player interSub substance }, Cmd.none )

        ConfirmMessage geste ->
            let
                nouPlay =
                    Play.resetPlayer model.player
            in
            ( { model | player = nouPlay }, Play.sendGeste nouPlay geste AppDetailsLoaded )

        DeploySequence elemGrap geste ->
            ( { model | player = Play.deployContainer model.player elemGrap }, Play.sendGeste model.player geste AppDetailsLoaded )

        SenderOfData geste data ->
            ( { model | player = Play.addDataToGeste model.player data geste }, Cmd.none )

        SubstancePicker inacSub subPicked ->
            ( { model | player = Play.addSubstance model.player inacSub (menuDevelopper inacSub subPicked) }, Cmd.none )

        DeploySubstance subInactive sub2Dep ->
            ( { model | player = Play.deploySubstance model.player subInactive sub2Dep (menuDevelopper subInactive sub2Dep) }, Cmd.none )

        ZoomSubstance substance ->
            ( { model | player = Play.zoomSubstance model.player substance }, Cmd.none )

        ZoomCancel ->
            ( { model | player = Play.cancelZoom model.player }, Cmd.none )

        ContainerPicker contSub elemInter ->
            ( { model | player = Play.addContainer model.player contSub (menuContainer contSub elemInter) }, Cmd.none )

        Reseteur ->
            ( { model | player = Play.resetMenu model.player }, Cmd.none )

        Closit ->
            ( { model | player = Play.resetDeployment model.player }, Cmd.none )

        ZoomRecord ->
            ( { model | player = Play.recordZoomedSubstance model.player }, sendVid (E.string "#elmVid") )

        RecordInFile ->
            ( { model | player = Play.startSavingMime model.player }, Cmd.none )

        AppMenuHandler appInfo ->
            ( { model | player = Play.addMenu2App model.player appInfo (menuApplication appInfo model.userInfo) }, Cmd.none )

        ShareAllUserChecked shareOrNot ->
            ( { model | player = Play.updateAppState model.player shareOrNot }, Play.sendAppState model.player shareOrNot FileSuccess )

        Edit_Chat selectedMsg ->
            case model.userInfo of
                Maybe.Just userData ->
                    ( { model | displayMode = ChatDisplay, externals = ChatModel (Chat_Creator.initialize userData.userId selectedMsg) }
                    , Cmd.none
                    )

                Maybe.Nothing ->
                    ( model, Cmd.none )

        Stream recording ->
            ( model, Cmd.none )

        Chat chatMsg ->
            case model.externals of
                ChatModel modelDida ->
                    Chat_Creator.update chatMsg modelDida
                        |> updateChatWith
                            (Model model.userInfo
                                model.errorMsg
                                model.navKey
                                model.chatMsg
                                model.friends
                                model.displayMode
                                model.imgChoices
                                model.vidChoices
                                model.subChoices
                                model.subEditor
                                model.appEditor
                                model.player
                                model.dloadValue
                                model.uploadValue
                                model.backendCall
                                model.successFileList
                                model.failFileList
                                model.totalFileList
                            )
                            Chat
                            model

                _ ->
                    ( model, Cmd.none )

        SendFiles fileEvent ->
            case model.userInfo of
                Maybe.Just info ->
                    ( { model | totalFileList = fileEvent.dataTransfer.files }
                    , Cmd.batch
                        (List.map
                            (\a -> sendMediaElement a info)
                            fileEvent.dataTransfer.files
                        )
                    )

                _ ->
                    ( model, Cmd.none )

        FileSuccess (Result.Err erreur) ->
            ( { model | errorMsg = erreur, displayMode = LoginDisplay }, Nav.pushUrl model.navKey "/" )

        FileSuccess (Result.Ok _) ->
            ( { model | displayMode = LoginDisplay }, Nav.pushUrl model.navKey "/" )

        Progression progresElem ->
            case progresElem of
                Http.Sending value ->
                    ( { model | uploadValue = toFloat value.sent / toFloat value.size }, Cmd.none )

                Http.Receiving value ->
                    ( { model | dloadValue = toFloat value.received / toFloat (Maybe.withDefault value.received value.size) }, Cmd.none )

        GotScreenSize (Result.Err errMsg) ->
            ( model, Cmd.none )

        GotScreenSize (Result.Ok viewPort) ->
            ( { model | player = Play.updateViewport model.player viewPort }, Cmd.none )

        CleanDico ->
            ( model
            , Http.get
                { url = "/deleteDictionnaire"
                , expect = Http.expectWhatever FileSuccess
                }
            )

        FileCode _ (Result.Err errorMsg) ->
            ( { model | errorMsg = errorMsg, displayMode = LoginDisplay }, Cmd.none )

        FileCode file2Send (Result.Ok filePath) ->
            ( model
            , Http.request
                { url = filePath
                , method = "PUT"
                , body = Http.fileBody file2Send
                , expect = Http.expectWhatever (FileTelecharge (File.name file2Send))
                , headers = []
                , timeout = Maybe.Nothing
                , tracker = Maybe.Just "media.pdf"
                }
            )

        FileTelecharge fileName (Result.Err error) ->
            ( { model | failFileList = fileName :: model.failFileList }
            , evaluateFiles model.successFileList model.failFileList model.totalFileList
            )

        FileTelecharge fileName (Result.Ok _) ->
            ( { model | successFileList = fileName :: model.successFileList }
            , evaluateFiles model.successFileList model.failFileList model.totalFileList
            )

        ShareApplication appInfo ->
            ( { model | player = Play.addApplicationMenu model.player appInfo Play.NotShared }, Cmd.none )


evaluateFiles : List String -> List String -> List File.File -> Cmd Msg
evaluateFiles successList failList totalList =
    if List.length successList + List.length failList >= List.length totalList - 1 then
        Http.get
            { url = "/completeUpload"
            , expect = Http.expectWhatever FileSuccess
            }

    else
        Cmd.none



-- sendMediaElementTask : File.File -> UserInfo -> Task.Task String String
-- sendMediaElementTask file userInfo =
--     if File.size file > 40000 then
--         let
--             pagePath =
--                 if String.contains "image" (File.mime file) then
--                     Builder.absolute [ "getMediaCode" ]
--                         [ Builder.string "objectKey"
--                             (userInfo.uploadImageId
--                                 ++ File.name file
--                             )
--                         , Builder.string "contentType" (File.mime file)
--                         ]
--
--                 else
--                     Builder.absolute [ "getMediaCode" ]
--                         [ Builder.string "objectKey"
--                             (userInfo.uploadVideoId
--                                 ++ File.name file
--                             )
--                         , Builder.string "contentType" (File.mime file)
--                         ]
--         in
--         Http.task
--             { method = "GET"
--             , headers = []
--             , url = pagePath
--             , body = Http.emptyBody
--             , resolver = Http.stringResolver resolveString
--             , timeout = Nothing
--             }
--
--     else
--         let
--             pagePath =
--                 if String.contains "image" (File.mime file) then
--                     Builder.absolute [ "uploadGraphic" ]
--                         [ Builder.string "objectKey"
--                             (userInfo.uploadImageId
--                                 ++ File.name file
--                             )
--                         ]
--
--                 else
--                     Builder.absolute [ "uploadGraphic" ]
--                         [ Builder.string "objectKey"
--                             (userInfo.uploadVideoId
--                                 ++ File.name file
--                             )
--                         ]
--         in
--         Http.task
--             { method = "Post"
--             , headers = []
--             , url = pagePath
--             , body = Http.fileBody file
--             , resolver = Http.stringResolver resolveString
--             , timeout = Nothing
--             }


sendMediaElement : File.File -> UserInfo -> Cmd Msg
sendMediaElement file userInfo =
    if File.size file > 33554432 then
        let
            pagePath =
                if String.contains "image" (File.mime file) then
                    Builder.absolute [ "getMediaCode" ]
                        [ Builder.string "objectKey"
                            (userInfo.uploadImageId
                                ++ File.name file
                            )
                        , Builder.string "contentType" (File.mime file)
                        ]

                else
                    Builder.absolute [ "getMediaCode" ]
                        [ Builder.string "objectKey"
                            (userInfo.uploadVideoId
                                ++ File.name file
                            )
                        , Builder.string "contentType" (File.mime file)
                        ]
        in
        Http.get
            { url = pagePath
            , expect = Http.expectString (FileCode file)
            }

    else
        let
            pagePath =
                if String.contains "image" (File.mime file) then
                    Builder.absolute [ "uploadGraphic" ]
                        [ Builder.string "objectKey"
                            (userInfo.uploadImageId
                                ++ File.name file
                            )
                        ]

                else
                    Builder.absolute [ "uploadGraphic" ]
                        [ Builder.string "objectKey"
                            (userInfo.uploadVideoId
                                ++ File.name file
                            )
                        ]
        in
        Http.post
            { url = pagePath
            , body = Http.fileBody file
            , expect = Http.expectWhatever (FileTelecharge (File.name file))
            }


isImage : File.File -> Bool
isImage file =
    String.contains "image" (File.mime file)


mapDocument : (msg1 -> msg2) -> Document msg1 -> Document msg2
mapDocument function { title, body } =
    { title = title
    , body =
        -- [ layout
        --     [ Bg.color (rgb255 229 229 229)
        --     ]
        --     styledHeader
        -- ]
        List.map (Html.map function) body
    }


displayChatMsg : ChatData -> Maybe (List FriendInfo) -> Element Msg
displayChatMsg chatData friends =
    case friends of
        Just userInfoList ->
            let
                fUser =
                    List.head (List.filter (\a -> a.userId == chatData.contactId) userInfoList)
            in
            case fUser of
                Just userValue ->
                    row []
                        [ text "Message de:"
                        , button [ Border.innerGlow (L.rgb255 55 25 200) 2 ]
                            { onPress = Maybe.Just (Edit_Chat chatData)
                            , label = text userValue.login
                            }
                        ]

                Nothing ->
                    text "Pas d'amis qui correspond à l'expéditeur"

        Nothing ->
            text "Pas d'amis donc pas de messages"


displayChatRecipient : FriendInfo -> Element Msg
displayChatRecipient userInfo =
    row []
        [ text "Expédier message à:"
        , button [ Border.innerGlow (L.rgb255 200 55 25) 2 ]
            { onPress = Maybe.Just (Edit_Chat (Chat_Creator.ChatData [] [] userInfo.userId))
            , label = text userInfo.login
            }
        ]


onDrop : (List File.File -> msg) -> Attribute msg
onDrop msg =
    htmlAttribute <|
        on "drop"
            (decodeFiles
                |> Decode.map msg
            )


styledLinkLabel : String -> String -> Bool -> Bool -> Element msg
styledLinkLabel message imgUrl isLeftSide isTop =
    image
        [ L.width (px 393)
        , L.height (px 290)
        , inFront
            (el
                [ if isTop then
                    alignTop

                  else
                    alignBottom
                , if isTop then
                    moveDown 83

                  else
                    moveUp 83
                , if isLeftSide then
                    moveLeft 0

                  else
                    moveRight 70
                , L.width (px 323)
                , L.height (px 124)
                , paddingEach
                    { top = 37
                    , bottom = 37
                    , right = 0
                    , left = 0
                    }
                , Font.color (rgb255 0 0 0)
                , Font.size 16
                , Font.bold
                , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
                , Font.center
                ]
                (text message)
            )
        ]
        { src = imgUrl, description = message }


styledHeader : Element msgGet
styledHeader =
    row
        [ L.height (px 187), L.width fill ]
        [ image [ centerX, centerY, L.height (px 62), L.width (px 323) ]
            { src = "img/logo.png", description = "Lucas CET" }
        , link [ alignRight, centerY, L.height (px 50), L.width (px 66) ]
            { url = "/login"
            , label =
                image []
                    { src = "img/Icons/icon-menu.png", description = "Lucas CET" }
            }
        ]


menuApplication : Play.AppInfo -> Maybe UserInfo -> Maybe ( String, List (L.Attribute Msg) )
menuApplication appInfoPlay userInfoMaybe =
    case userInfoMaybe of
        Just userInfo ->
            if appInfoPlay.appType == Play.DidactiqueModule && appInfoPlay.creatorId == userInfo.userId then
                Just
                    ( appInfoPlay.appId
                    , [ inFront
                            (button []
                                { onPress = Just (ShareApplication appInfoPlay)
                                , label =
                                    image []
                                        { src = "img/Icons/share-icon1.png"
                                        , description = "Partage Application"
                                        }
                                }
                            )
                      ]
                    )

            else
                Nothing

        Nothing ->
            Nothing


menuContainer : Play.SubstanceContainer -> Play.ElementGraphique -> ( String, List (L.Attribute Msg) )
menuContainer substanceContainerPlay elementGraphiquePlay =
    case elementGraphiquePlay.visuel of
        Play.Video ->
            ( elementGraphiquePlay.valeur, deployElementMenu substanceContainerPlay elementGraphiquePlay )

        _ ->
            ( "", [] )


deployElementMenu : Play.SubstanceContainer -> Play.ElementGraphique -> List (L.Attribute Msg)
deployElementMenu substanceContainer elementGraphique =
    let
        nouGeste =
            substanceContainer.gesteAssocie
    in
    if substanceContainer.autoDeploy then
        let
            gesteUpdate =
                { nouGeste | metaData = elementGraphique.valeur }
        in
        if substanceContainer.zoomable then
            [ inFront
                (row []
                    [ button []
                        { onPress = Just (DeploySequence elementGraphique gesteUpdate)
                        , label =
                            image []
                                { src = "img/Icons/icon-relation.png"
                                , description = "Deploiement"
                                }
                        }
                    , button []
                        { onPress = Nothing
                        , label =
                            image []
                                { src = "img/Icons/icon-zoom.png"
                                , description = "Zoom"
                                }
                        }
                    ]
                )
            ]

        else
            [ inFront
                (row []
                    [ button []
                        { onPress = Just (DeploySequence elementGraphique gesteUpdate)
                        , label =
                            image []
                                { src = "img/Icons/icon-relation.png"
                                , description = "Deploiement"
                                }
                        }
                    ]
                )
            ]

    else
        []


menuDevelopper : Play.SubstanceInactive -> Substance -> ( String, List (L.Attribute Msg) )
menuDevelopper substanceInactivePlay selectedSubstance =
    case selectedSubstance of
        Sub.Relation subRel ->
            ( subRel.subId, deployMenu substanceInactivePlay selectedSubstance )

        Sub.Dynamic subDym ->
            ( subDym.subId, deployMenu substanceInactivePlay selectedSubstance )

        Sub.Potential subPot ->
            if substanceInactivePlay.zoomable then
                ( subPot.subId
                , [ inFront
                        (button []
                            { onPress = Nothing
                            , label =
                                image []
                                    { src = "img/Icons/icon-zoom.png"
                                    , description = "Zoom"
                                    }
                            }
                        )
                  ]
                )

            else
                ( subPot.subId, [] )


deployMenu : Play.SubstanceInactive -> Substance -> List (L.Attribute Msg)
deployMenu substanceInactivePlay substance =
    if substanceInactivePlay.autoDeploy then
        if substanceInactivePlay.zoomable then
            [ inFront
                (row []
                    [ button []
                        { onPress = Just (DeploySubstance substanceInactivePlay substance)
                        , label =
                            image []
                                { src = "img/Icons/icon-relation.png"
                                , description = "Deploiement"
                                }
                        }
                    , button []
                        { onPress = Just (ZoomSubstance substance)
                        , label =
                            image []
                                { src = "img/Icons/icon-zoom.png"
                                , description = "Zoom"
                                }
                        }
                    ]
                )
            ]

        else
            [ inFront
                (row []
                    [ button []
                        { onPress = Just (DeploySubstance substanceInactivePlay substance)
                        , label =
                            image []
                                { src = "img/Icons/icon-relation.png"
                                , description = "Deploiement"
                                }
                        }
                    ]
                )
            ]

    else
        []


mainContainerAttributes : List (L.Attribute appMsg)
mainContainerAttributes =
    [ padding 50
    , Bg.color (rgb255 255 255 255)
    , Border.rounded 15
    , Border.width 1
    ]



-- View


view : Model -> Document Msg
view model =
    case model.userInfo of
        Maybe.Nothing ->
            { title = "LUCAS CET"
            , body =
                [ layout []
                    (column []
                        [ paragraph [] [ text "Login" ]
                        , link [] { url = "/login/facebook", label = text "Click to log on facebook" }
                        , paragraph [] [ text (displayErrorMsg model.errorMsg) ]
                        ]
                    )
                ]
            }

        Maybe.Just info ->
            case model.displayMode of
                ChatDisplay ->
                    case model.externals of
                        ChatModel modelDida ->
                            mapDocument Chat (Chat_Creator.view modelDida)

                        _ ->
                            { title = "LUCAS CET"
                            , body =
                                [ layout []
                                    (text "Model Error")
                                ]
                            }

                LoginDisplay ->
                    if info.userId == "105882307882687" || info.userId == "112747567193397" then
                        { title = "LUCAS CET"
                        , body =
                            [ layout [ Bg.color (rgb255 229 229 229) ]
                                (column
                                    [ L.width fill
                                    , centerX
                                    , paddingEach
                                        { top = 35
                                        , bottom = 0
                                        , right = 0
                                        , left = 0
                                        }
                                    ]
                                    [ styledHeader
                                    , column [ alignTop, centerX, L.width (px 810), spacingXY 0 18 ]
                                        [ row
                                            [ L.width fill, L.height (px 290), spacingXY 18 0 ]
                                            [ link []
                                                { url = "/multimedia"
                                                , label = styledLinkLabel "MULTIMEDIA" "img/menu-item-3.png" True False
                                                }
                                            , link []
                                                { url = "/chat"
                                                , label = styledLinkLabel "Application Artisanale" "img/menu-item-4.png" False False
                                                }
                                            ]
                                        , paragraph [] [ text (Sub.displayErrorMsg model.errorMsg) ]
                                        ]
                                    ]
                                )
                            ]
                        }

                    else
                        { title = "LUCAS CET"
                        , body =
                            [ layout [ Bg.color (rgb255 229 229 229) ]
                                (column
                                    [ L.width fill
                                    , centerX
                                    , paddingEach
                                        { top = 35
                                        , bottom = 0
                                        , right = 0
                                        , left = 0
                                        }
                                    ]
                                    [ styledHeader
                                    , column [ alignTop, centerX, L.width (px 810), spacingXY 0 18 ]
                                        [ row [ L.width fill, L.height (px 290), spacingXY 18 0 ]
                                            [ link []
                                                { url = "/didactique"
                                                , label = styledLinkLabel "DIDACTIC APPLICATION" "img/menu-item-1.png" True True
                                                }
                                            , link []
                                                { url = "/dictionnaire"
                                                , label = styledLinkLabel "DICTIONNAIRE SUBSTANCE" "img/menu-item-2.png" False True
                                                }
                                            ]
                                        , row [ L.width fill, L.height (px 290), spacingXY 18 0 ]
                                            [ link []
                                                { url = "/multimedia"
                                                , label = styledLinkLabel "MULTIMEDIA" "img/menu-item-3.png" True False
                                                }
                                            , link []
                                                { url = "/applicationModule"
                                                , label = styledLinkLabel "CREER UNE APPLICATION" "img/menu-item-4.png" False False
                                                }
                                            ]
                                        , paragraph [] [ text (Sub.displayErrorMsg model.errorMsg) ]
                                        ]
                                    ]
                                )
                            ]
                        }

                PlayApplication ->
                    case model.player.chosenApp of
                        Nothing ->
                            { title = "LUCAS CET"
                            , body =
                                [ layout [ L.width fill, L.height fill ]
                                    (column
                                        [ L.width fill
                                        , L.height fill
                                        , centerX
                                        , Bg.color (rgb255 229 229 229)
                                        , paddingEach
                                            { top = 35
                                            , bottom = 20
                                            , right = 20
                                            , left = 20
                                            }
                                        , scrollbarY
                                        ]
                                        [ styledHeader
                                        , Play.displayAvailableApp
                                            model.player
                                        ]
                                    )
                                ]
                            }

                        Just appChoice ->
                            { title = "LUCAS CET"
                            , body =
                                [ layout [ L.width fill, L.height fill ]
                                    (column (Play.appPlayAttribute model.player)
                                        [ styledHeader
                                        , Play.displayTitle appChoice
                                        , Play.displayChosenApp model.player
                                            appChoice
                                        ]
                                    )
                                ]
                            }

                ChatMessages ->
                    case model.friends of
                        Maybe.Just lstFr ->
                            case model.chatMsg of
                                Maybe.Just lstMsgs ->
                                    { title = "LUCAS CET"
                                    , body =
                                        [ layout [ Bg.color (rgb255 229 229 229) ]
                                            (column
                                                [ L.width fill
                                                , centerX
                                                , paddingEach
                                                    { top = 35
                                                    , bottom = 0
                                                    , right = 0
                                                    , left = 0
                                                    }
                                                ]
                                                ([ styledHeader
                                                 , text info.login
                                                 ]
                                                    ++ List.map (\a -> displayChatMsg a model.friends) lstMsgs
                                                    ++ List.map displayChatRecipient lstFr
                                                )
                                            )
                                        ]
                                    }

                                Maybe.Nothing ->
                                    { title = "LUCAS CET"
                                    , body =
                                        [ layout [ Bg.color (rgb255 229 229 229) ]
                                            (column
                                                [ L.width fill
                                                , centerX
                                                , paddingEach
                                                    { top = 35
                                                    , bottom = 0
                                                    , right = 0
                                                    , left = 0
                                                    }
                                                ]
                                                ([ styledHeader
                                                 , text info.login
                                                 ]
                                                    ++ List.map displayChatRecipient lstFr
                                                )
                                            )
                                        ]
                                    }

                        Maybe.Nothing ->
                            { title = "LUCAS CET"
                            , body =
                                [ layout []
                                    (text "Model Error")
                                ]
                            }

                UploadFile ->
                    { title = "LUCAS CET"
                    , body =
                        [ layout [ Bg.color (rgb255 229 229 229) ]
                            (column
                                [ L.width fill
                                , centerX
                                , paddingEach
                                    { top = 35
                                    , bottom = 0
                                    , right = 0
                                    , left = 0
                                    }
                                ]
                                [ styledHeader
                                , text "Site Visumation"
                                , text "Gestion Multimédia"
                                , text "Déposer un fichier ci-dessous pour le télécharger"
                                , column
                                    ([ L.height fill
                                     , L.width fill
                                     , Bg.color (rgb255 14 255 235)
                                     ]
                                        ++ List.map htmlAttribute
                                            (Drag.onFileFromOS
                                                { onOver = Start
                                                , onDrop = SendFiles
                                                , onEnter = Maybe.Nothing
                                                , onLeave = Maybe.Nothing
                                                }
                                            )
                                    )
                                    [ el [ centerX, centerY ] (text "Déposer le fichier ici")
                                    , image [ centerX, centerY ] { src = "/img/multimedia.jpg", description = "" }
                                    , el [ centerX, centerY ] (text (String.fromFloat model.uploadValue))
                                    ]
                                ]
                            )
                        ]
                    }

                SelectMedia ->
                    { title = "LUCAS CET"
                    , body =
                        [ layout [ L.height fill, L.width fill ]
                            (column [ L.height fill, L.width fill, padding 30 ]
                                [ text "Site Visumation"
                                , text "Dictionnaire Substance"
                                , GraphicList.showImageList [ L.height (fillPortion 4), L.width fill ] model.imgChoices
                                , GraphicList.showVideoList [ L.height (fillPortion 4), L.width fill ] model.vidChoices
                                ]
                            )
                        ]
                    }

                ViewSubstance ->
                    { title = "LUCAS CET"
                    , body =
                        [ layout [ Bg.color (rgb255 229 229 229) ]
                            (column
                                [ L.width fill
                                , centerX
                                , paddingEach
                                    { top = 35
                                    , bottom = 0
                                    , right = 0
                                    , left = 0
                                    }
                                ]
                                [ styledHeader
                                , text "Site Visumation"
                                , text "Dictionnaire Substance"
                                , Sub.showSubstanceList [ L.height (fillPortion 4), L.width fill ] model.backendCall model.subChoices
                                ]
                            )
                        ]
                    }

                DicoSubstance ->
                    { title = "LUCAS CET"
                    , body =
                        [ layout [ Bg.color (rgb255 229 229 229) ]
                            (column
                                [ L.width fill
                                , centerX
                                , paddingEach
                                    { top = 35
                                    , bottom = 0
                                    , right = 0
                                    , left = 0
                                    }
                                ]
                                [ styledHeader
                                , text "Site Visumation"
                                , text "Dictionnaire Substance"
                                , GraphEl.displayCanvas model.subEditor
                                ]
                            )
                        ]
                    }

                ApplicationModule ->
                    { title = "LUCAS CET"
                    , body =
                        [ layout [ Bg.color (rgb255 229 229 229) ]
                            (column
                                [ L.width fill
                                , centerX
                                , paddingEach
                                    { top = 35
                                    , bottom = 0
                                    , right = 0
                                    , left = 0
                                    }
                                ]
                                [ styledHeader
                                , text "Site Visumation"
                                , text "Applications :"
                                , AppCreator.displayModule model.appEditor
                                ]
                            )
                        ]
                    }

                TableSubstance ->
                    { title = "LUCAS CET"
                    , body =
                        [ layout [ L.height fill, L.width fill ]
                            (column [ L.height fill, L.width fill, padding 30 ]
                                [ text "Site Visumation"
                                , text "Table des Substances"
                                , Sub.displayTable model.subChoices
                                ]
                            )
                        ]
                    }



-- Subscription


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch [ getStream Stream, Http.track "media.pdf" Progression ]



-- port


port sendVid : E.Value -> Cmd msg


port getStream : (E.Value -> msg) -> Sub msg



-- Main


main : Program (Maybe UserInfo) Model Msg
main =
    Browser.application
        { init = init
        , view = view
        , update = update
        , subscriptions = subscriptions
        , onUrlRequest = RequestUrl
        , onUrlChange = ChangeUrl
        }
