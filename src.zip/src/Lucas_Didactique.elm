module Lucas_Didactique exposing
    ( Model
    , Msg(..)
    , Substance(..)
    , SubstanceDynamic
    , decodeAppList
    , update
    , view
    )

import Browser exposing (Document)
import Browser.Dom as DOM exposing (Error, Viewport, getViewport)
import Dict exposing (Dict)
import Element exposing (..)
import Element.Background as Bg exposing (color, gradient)
import Element.Border as Border exposing (..)
import Element.Events as Events exposing (..)
import Element.Input as Input exposing (button)
import Html exposing (video)
import Html.Attributes as H exposing (autoplay, controls, height, id, src, width)
import Http
import Json.Decode as Decode
import Json.Encode as E
import Task exposing (attempt)
import Tuple exposing (first, second)
import Url exposing (..)
import Url.Builder as Builder



-- MODEL


type alias SubstancePotential =
    { subId : String
    , image : String
    , name : String
    }


type alias SubstanceDynamic =
    { subId : String
    , video : String
    , name : String
    , principal : SubstanceLiee
    }


type SubstanceLiee
    = Lien String
    | SubLiee Substance
    | Error String


type alias SubstanceRelation =
    { subId : String
    , media : String
    , name : String
    , substance1 : SubstanceLiee
    , substance2 : SubstanceLiee
    }


type alias Sequence =
    { video : String
    , name : String
    }


type Substance
    = Relation SubstanceRelation
    | Dynamic SubstanceDynamic
    | Potential SubstancePotential
    | Practice Substance


type alias Application =
    { name : String
    , seqList : Dict String String
    }


type alias Model =
    { applications : Maybe (List Application)
    , selectedApplication : Maybe Application
    , selectedSequence : Maybe Sequence
    , selectedSubstance : Maybe Substance
    , subList : List Substance
    , breadCumb : Maybe (List Substance)
    , pathSubstance : Maybe (List Substance)
    , errorMsg : Http.Error
    , stream : Maybe E.Value
    , dimension : ( Float, Float )
    }


decodeAppList : Decode.Decoder (List Application)
decodeAppList =
    Decode.list
        (Decode.map2
            Application
            (Decode.field "title" Decode.string)
            (Decode.field "seqData" (Decode.dict Decode.string))
        )


decodeSequencePackage : Decode.Decoder ( Sequence, List Substance )
decodeSequencePackage =
    Decode.map2 Tuple.pair (Decode.field "sequence" decodeSequence) (Decode.field "substances" (Decode.list decodeSubstance))


decodeSequence : Decode.Decoder Sequence
decodeSequence =
    Decode.map2 Sequence
        (Decode.field "media" Decode.string)
        (Decode.field "title" Decode.string)


decodeRelation : Decode.Decoder SubstanceRelation
decodeRelation =
    Decode.map5 SubstanceRelation
        (Decode.field "subId" Decode.string)
        (Decode.field "media" Decode.string)
        (Decode.field "title" Decode.string)
        (Decode.map Lien (Decode.field "firstSubstance" Decode.string))
        (Decode.map Lien (Decode.field "secondSubstance" Decode.string))


decodeDynamic : Decode.Decoder SubstanceDynamic
decodeDynamic =
    Decode.map4 SubstanceDynamic
        (Decode.field "subId" Decode.string)
        (Decode.field "media" Decode.string)
        (Decode.field "title" Decode.string)
        (Decode.map Lien (Decode.field "firstSubstance" Decode.string))


decodePotential : Decode.Decoder SubstancePotential
decodePotential =
    Decode.map3 SubstancePotential (Decode.field "subId" Decode.string) (Decode.field "media" Decode.string) (Decode.field "title" Decode.string)


decodeSubstance : Decode.Decoder Substance
decodeSubstance =
    Decode.field "subType" Decode.string
        |> Decode.andThen
            (\str ->
                case str of
                    "relation" ->
                        Decode.map Relation decodeRelation

                    "dynamic" ->
                        Decode.map Dynamic decodeDynamic

                    "potential" ->
                        Decode.map Potential decodePotential

                    somethingElse ->
                        Decode.fail <| "Unknown media type" ++ somethingElse
            )



-- UPDATE


testSubstance : Substance -> String -> Bool
testSubstance substance idSub =
    case substance of
        Relation substanceRelation ->
            substanceRelation.subId == idSub

        Dynamic substanceDynamic ->
            substanceDynamic.subId == idSub

        Potential substancePotential ->
            substancePotential.subId == idSub

        Practice _ ->
            False


findSubstance : SubstanceLiee -> List Substance -> SubstanceLiee
findSubstance substanceLiee substanceList =
    case substanceLiee of
        Lien idSub ->
            let
                substanceRes =
                    List.head (List.filter (\sub -> testSubstance sub idSub) substanceList)
            in
            case substanceRes of
                Maybe.Just value ->
                    SubLiee value

                Maybe.Nothing ->
                    Error ("Error LCA-1D ecode error in finding:" ++ idSub)

        SubLiee substance ->
            SubLiee substance

        Error msg ->
            Error msg


refineSubstance : SubstanceLiee -> List Substance -> SubstanceLiee
refineSubstance substanceLiee subList =
    case substanceLiee of
        Lien string ->
            Error ("Error LCA-2D ecode error in finding:" ++ string)

        SubLiee substance ->
            SubLiee (extractSubstance substance subList)

        Error err ->
            Error err


extractSubstance : Substance -> List Substance -> Substance
extractSubstance sub substanceList =
    case sub of
        Relation substanceRelation ->
            Relation
                { substanceRelation
                    | substance1 = refineSubstance (findSubstance substanceRelation.substance1 substanceList) substanceList
                    , substance2 = refineSubstance (findSubstance substanceRelation.substance2 substanceList) substanceList
                }

        Dynamic substanceDynamic ->
            Dynamic { substanceDynamic | principal = refineSubstance (findSubstance substanceDynamic.principal substanceList) substanceList }

        Potential substancePotential ->
            Potential substancePotential

        Practice _ ->
            sub


type Msg
    = Depart
    | GetApplications (Result Http.Error (List Application))
    | DeployApplication Application
    | SelectSequence String
    | CancelApp
    | GetSequence (Result Http.Error ( Sequence, List Substance ))
    | ActivateSubstance Substance
    | ResetSequence Sequence
    | GotScreenSize (Result Error DOM.Viewport)


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case Debug.log "didactique message:" msg of
        Depart ->
            ( model
            , Http.get
                { url = "downloadApplications"
                , expect = Http.expectJson GetApplications decodeAppList
                }
            )

        GetApplications (Result.Ok appData) ->
            ( { model | applications = Maybe.Just appData }, attempt GotScreenSize <| DOM.getViewport )

        GetApplications (Result.Err errMsg) ->
            ( { model | errorMsg = errMsg }, Cmd.none )

        DeployApplication app ->
            ( { model | selectedApplication = Maybe.Just app }, Cmd.none )

        CancelApp ->
            ( { model | selectedApplication = Maybe.Nothing }, Cmd.none )

        SelectSequence seqId ->
            let
                seqPath =
                    Builder.absolute [ "downloadSequence" ] [ Builder.string "sequenceId" seqId ]
            in
            ( model
            , Http.get
                { url = seqPath
                , expect = Http.expectJson GetSequence decodeSequencePackage
                }
            )

        GetSequence (Result.Err errMsg) ->
            ( { model | errorMsg = errMsg }, Cmd.none )

        GetSequence (Result.Ok ( sequence, lstSubstances )) ->
            ( { model
                | selectedSequence = Maybe.Just sequence
                , subList = List.map (\currentSub -> extractSubstance currentSub lstSubstances) lstSubstances
              }
            , Cmd.none
            )

        ActivateSubstance substance ->
            case model.breadCumb of
                Just substanceList ->
                    if List.member substance substanceList then
                        ( { model | selectedSubstance = Maybe.Just substance }, Cmd.none )

                    else
                        ( { model | selectedSubstance = Maybe.Just substance, breadCumb = Maybe.Just (List.append substanceList [ substance ]) }, Cmd.none )

                Nothing ->
                    ( { model | selectedSubstance = Maybe.Just substance, breadCumb = Maybe.Just [ substance ] }, Cmd.none )

        ResetSequence sequence ->
            ( { model | selectedSubstance = Maybe.Nothing, breadCumb = Maybe.Nothing }, Cmd.none )

        GotScreenSize (Result.Err _) ->
            ( model, Cmd.none )

        GotScreenSize (Result.Ok viewPort) ->
            ( { model | dimension = ( viewPort.viewport.width, viewPort.viewport.height ) }, Cmd.none )



-- View


isRelation : Substance -> ( Float, Float ) -> Maybe (Element Msg)
isRelation substance dimension =
    case substance of
        Relation substanceRelation ->
            Maybe.Just
                (el
                    [ Bg.color (rgb255 0 0 0)
                    , padding 2
                    , centerX
                    , centerY
                    ]
                    (el
                        [ onClick (ActivateSubstance substance)
                        , centerX
                        , centerY
                        ]
                        (Element.html
                            (video
                                [ src substanceRelation.media
                                , controls True
                                , H.width (round (first dimension * 0.2))
                                , H.height (round (second dimension * 0.2))
                                ]
                                []
                            )
                        )
                    )
                )

        _ ->
            Maybe.Nothing


displaySubstanceLink : Substance -> ( Float, Float ) -> Element Msg
displaySubstanceLink substance dimension =
    case substance of
        Relation substanceRelation ->
            el
                [ Bg.color (rgb255 0 0 0)
                , padding 2
                , centerX
                , centerY
                ]
                (el
                    [ onClick (ActivateSubstance (Relation substanceRelation))
                    , centerX
                    , centerY
                    ]
                    (Element.html
                        (video
                            [ src substanceRelation.media
                            , controls True
                            , H.width (round (first dimension * 0.2))
                            , H.height (round (second dimension * 0.2))
                            ]
                            []
                        )
                    )
                )

        Dynamic substanceDynamic ->
            el
                [ Bg.color (rgb255 0 0 0)
                , padding 2
                , centerX
                , centerY
                ]
                (el
                    [ onClick (ActivateSubstance (Dynamic substanceDynamic))
                    , centerX
                    , centerY
                    ]
                    (Element.html
                        (video
                            [ src substanceDynamic.video
                            , controls True
                            , H.width (round (first dimension * 0.2))
                            , H.height (round (second dimension * 0.2))
                            ]
                            []
                        )
                    )
                )

        Potential substancePotential ->
            image
                [ Bg.color (rgb255 0 0 0)
                , onClick (ActivateSubstance (Potential substancePotential))
                ]
                { src = substancePotential.image, description = substancePotential.name }

        Practice _ ->
            el [] (paragraph [] [ text "error LCA-11S practice should never be a child" ])


displaySubstance : Substance -> ( Float, Float ) -> Element Msg
displaySubstance substance dimension =
    case substance of
        Relation substanceRelation ->
            case substanceRelation.substance1 of
                SubLiee substance1Liee ->
                    case substanceRelation.substance2 of
                        SubLiee substance2Liee ->
                            row rowAttribute
                                [ column columnAttribute
                                    [ decorateVideo substanceRelation.media (round (first dimension * 0.6)) (round (second dimension * 0.6))
                                    , paragraph [] [ text substanceRelation.name ]
                                    , button [ onClick (ActivateSubstance (Practice substance)) ] { label = text "Practice", onPress = Maybe.Nothing }
                                    ]
                                , column [ alignTop, Element.width (fillPortion 1) ]
                                    [ text "Children:"
                                    , column gradientEffect
                                        (List.map (\a -> displaySubstanceLink a dimension)
                                            [ substance1Liee, substance2Liee ]
                                        )
                                    ]
                                ]

                        Error err ->
                            column []
                                [ el [] (Element.html (video [ src substanceRelation.media ] []))
                                , paragraph [] [ text err ]
                                ]

                        Lien str ->
                            column []
                                [ el [] (Element.html (video [ src substanceRelation.media ] []))
                                , paragraph [] [ text ("Error LCA-2S Can't link substance:" ++ str) ]
                                ]

                Error msg ->
                    column []
                        [ el [] (Element.html (video [ src substanceRelation.media ] []))
                        , paragraph [] [ text msg ]
                        ]

                Lien path ->
                    column []
                        [ el [] (Element.html (video [ src substanceRelation.media ] []))
                        , paragraph [] [ text ("Error LCA-3S Can't link substance:" ++ path) ]
                        ]

        Dynamic substanceDynamic ->
            case substanceDynamic.principal of
                SubLiee principale ->
                    row rowAttribute
                        [ column columnAttribute
                            [ decorateVideo substanceDynamic.video (round (first dimension * 0.6)) (round (second dimension * 0.6))
                            , paragraph [] [ text substanceDynamic.name ]
                            , button [ onClick (ActivateSubstance (Practice substance)) ] { label = text "Practice", onPress = Maybe.Nothing }
                            ]
                        , column [ alignTop, Element.width (fillPortion 1) ]
                            [ text "Children:"
                            , column gradientEffect [ displaySubstanceLink principale dimension ]
                            ]
                        ]

                Error err ->
                    column []
                        [ el [] (Element.html (video [ src substanceDynamic.video ] []))
                        , paragraph [] [ text err ]
                        ]

                Lien str ->
                    column []
                        [ el [] (Element.html (video [ src substanceDynamic.video ] []))
                        , paragraph [] [ text ("Error LCA-4S Can't link substance:" ++ str) ]
                        ]

        Potential substancePotential ->
            column []
                [ image [] { src = substancePotential.image, description = "Potential" }
                ]

        Practice substance2Practice ->
            case substance2Practice of
                Relation subRel ->
                    row rowAttribute
                        [ el
                            []
                            (Element.html
                                (video
                                    [ src subRel.media
                                    , controls True
                                    , H.width (round (first dimension * 0.6))
                                    , H.height (round (second dimension * 0.6))
                                    ]
                                    []
                                )
                            )
                        , el gradientEffect (Element.html (video [ id "elmVid", autoplay True ] []))
                        ]

                Dynamic subDyna ->
                    row rowAttribute
                        [ el
                            []
                            (Element.html
                                (video
                                    [ src subDyna.video
                                    , controls True
                                    , H.width (round (first dimension * 0.6))
                                    , H.height (round (second dimension * 0.6))
                                    ]
                                    []
                                )
                            )
                        , el gradientEffect (Element.html (video [ id "elmVid", autoplay True ] []))
                        ]

                Potential subPoten ->
                    row rowAttribute
                        [ image [] { src = subPoten.image, description = "Potential" }
                        , el gradientEffect (Element.html (video [ id "elmVid", autoplay True ] []))
                        ]

                Practice _ ->
                    el [] (paragraph [] [ text "error LCA-10S recursive practice" ])


afficherCrumb : Substance -> Element Msg
afficherCrumb substance =
    case substance of
        Relation substanceRelation ->
            paragraph [ onClick (ActivateSubstance substance) ] [ text (substanceRelation.name ++ "->") ]

        Dynamic substanceDynamic ->
            paragraph [ onClick (ActivateSubstance substance) ] [ text (substanceDynamic.name ++ "->") ]

        Potential substancePotential ->
            paragraph [ onClick (ActivateSubstance substance) ] [ text (substancePotential.name ++ "->") ]

        Practice _ ->
            paragraph [] [ text "Practice" ]


viewApp : Application -> Element Msg
viewApp app =
    Input.button [ Events.onClick (DeployApplication app) ] { label = text app.name, onPress = Maybe.Nothing }


viewSeqChoice : String -> String -> ( Float, Float ) -> Element Msg
viewSeqChoice seqId seqVid dimension =
    el [ Events.onClick (SelectSequence seqId) ]
        (Element.html
            (Html.video
                [ src seqVid
                , controls True
                , H.width (round (first dimension * 0.3))
                , H.height (round (second dimension * 0.3))
                ]
                []
            )
        )


columnAttribute : List (Element.Attribute Msg)
columnAttribute =
    [ alignTop, padding 3, spaceEvenly, Element.width (fillPortion 4), Element.height fill ]


rowAttribute : List (Element.Attribute Msg)
rowAttribute =
    [ Bg.color (rgb255 150 150 150)
    , padding 3
    , spaceEvenly
    ]


gradientEffect : List (Element.Attribute Msg)
gradientEffect =
    [ padding 3
    , spaceEvenly
    , gradient { angle = 0, steps = [ rgb255 150 150 150, rgb255 205 205 205 ] }
    ]


decorateVideo : String -> Int -> Int -> Element Msg
decorateVideo videoLink maxWidth maxHeight =
    el
        [ Bg.color (rgb255 0 0 0)
        , padding 1
        , centerX
        , centerY
        ]
        (el
            [ centerX
            , centerY
            ]
            (Element.html
                (video
                    [ src videoLink
                    , controls True
                    , H.width maxWidth
                    , H.height maxHeight
                    ]
                    []
                )
            )
        )


view : Model -> Document Msg
view model =
    case model.applications of
        Maybe.Nothing ->
            { title = "LUCAS DIDACTIQUE"
            , body =
                [ layout []
                    (column []
                        [ paragraph []
                            [ text "No Apps..." ]
                        , paragraph [] [ text (Debug.toString model.errorMsg) ]
                        ]
                    )
                ]
            }

        Maybe.Just lstApps ->
            case model.selectedApplication of
                Maybe.Nothing ->
                    { title = "LUCAS DIDACTIQUE"
                    , body =
                        [ layout
                            []
                            (column []
                                [ paragraph []
                                    [ text "Application list :" ]
                                , paragraph [] [ text (Debug.toString model.errorMsg) ]
                                , column []
                                    (List.map viewApp lstApps)
                                ]
                            )
                        ]
                    }

                Maybe.Just app ->
                    case model.selectedSequence of
                        Maybe.Nothing ->
                            { title = "LUCAS DIDACTIQUE"
                            , body =
                                [ layout
                                    [ Element.width (fill |> maximum (round (first model.dimension)))
                                    , Element.height (fill |> maximum (round (second model.dimension)))
                                    ]
                                    (column
                                        [ Element.width (fill |> maximum (round (first model.dimension)))
                                        , Element.height (fill |> maximum (round (second model.dimension)))
                                        ]
                                        [ paragraph [] [ text (Debug.toString model.errorMsg) ]
                                        , column [] (Dict.values (Dict.map (\k a -> viewSeqChoice k a model.dimension) app.seqList))
                                        , column []
                                            [ button
                                                [ Events.onClick CancelApp
                                                , Border.width 2
                                                , solid
                                                , innerGlow (rgb255 255 200 150) 1
                                                ]
                                                { label = text "Cancel Application Selection", onPress = Maybe.Nothing }
                                            ]
                                        ]
                                    )
                                ]
                            }

                        Maybe.Just sequence ->
                            case model.selectedSubstance of
                                Nothing ->
                                    { title = "LUCAS DIDACTIQUE"
                                    , body =
                                        [ layout
                                            [ Element.width (fill |> maximum (round (first model.dimension)))
                                            , Element.height (fill |> maximum (round (second model.dimension)))
                                            ]
                                            (row
                                                (rowAttribute
                                                    ++ [ Element.width (fill |> maximum (round (first model.dimension)))
                                                       , Element.height (fill |> maximum (round (second model.dimension)))
                                                       ]
                                                )
                                                [ column columnAttribute
                                                    [ decorateVideo sequence.video (round (first model.dimension * 0.6)) (round (second model.dimension * 0.6))
                                                    , paragraph [] [ text sequence.name ]
                                                    ]
                                                , column [ alignTop, Element.width (fillPortion 1) ]
                                                    [ text "Relations:"
                                                    , column gradientEffect (List.filterMap (\a -> isRelation a model.dimension) model.subList)
                                                    ]
                                                ]
                                            )
                                        ]
                                    }

                                Just substance ->
                                    case model.breadCumb of
                                        Just substanceList ->
                                            { title = "LUCAS DIDACTIQUE"
                                            , body =
                                                [ layout
                                                    [ Element.width (fill |> maximum (round (first model.dimension)))
                                                    , Element.height (fill |> maximum (round (second model.dimension)))
                                                    ]
                                                    (column
                                                        [ Element.width (fill |> maximum (round (first model.dimension)))
                                                        , Element.height (fill |> maximum (round (second model.dimension)))
                                                        ]
                                                        [ paragraph [ onClick (ResetSequence sequence) ] [ text sequence.name ]
                                                        , row [] (List.map afficherCrumb substanceList)
                                                        , displaySubstance substance model.dimension
                                                        ]
                                                    )
                                                ]
                                            }

                                        Nothing ->
                                            { title = "LUCAS DIDACTIQUE"
                                            , body =
                                                [ layout
                                                    [ Element.width (fill |> maximum (round (first model.dimension)))
                                                    , Element.height (fill |> maximum (round (second model.dimension)))
                                                    ]
                                                    (column
                                                        [ Element.width (fill |> maximum (round (first model.dimension)))
                                                        , Element.height (fill |> maximum (round (second model.dimension)))
                                                        ]
                                                        [ paragraph [ onClick (ResetSequence sequence) ] [ text sequence.name ]
                                                        , column [] [ displaySubstance substance model.dimension ]
                                                        ]
                                                    )
                                                ]
                                            }
