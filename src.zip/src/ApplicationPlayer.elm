module ApplicationPlayer exposing (AppInfo, AppShareStatus(..), AppType(..), ElementGraphique, ElementInteractif, FiltreSubstance, Geste, InterfaceInteractive, PlayApp, SubstanceContainer, SubstanceInactive, SubstanceInteractive, TypeFiltreSubstance(..), TypeGeste(..), TypeMultimedia(..), TypeResultat(..), addApplicationMenu, addContainer, addDataToGeste, addMenu2App, addPlayState, addSubstance, afficherInterfaceSelection, afficherPlayApp, appPlayAttribute, cancelSubstanceSelection, cancelZoom, closePlayer, decodeAppInfo, decodeAppType, deployContainer, deploySubstance, displayAvailableApp, displayChosenApp, displayTitle, executeLaunchApp, initPlayer, loadUpData, recordZoomedSubstance, resetDeployment, resetMenu, resetPlayer, sendAppState, sendGeste, setChosenApp, startSavingMime, substanceClicked, updateAppState, updateViewport, zoomSubstance)

import Browser exposing (Document)
import Browser.Dom as DOM exposing (Error, Viewport, getViewport)
import Dict exposing (Dict)
import Element as L exposing (..)
import Element.Background as Bg exposing (color, gradient)
import Element.Border as Border exposing (..)
import Element.Events as Events exposing (..)
import Element.Font as Font
import Element.Input as Input exposing (..)
import Graphic_Downloader exposing (GraphicList)
import Graphic_Element as GraphEl exposing (..)
import Html exposing (video)
import Html.Attributes as H exposing (autoplay, controls, height, id, src, width)
import Http
import Json.Decode as Decode
import Json.Encode as Encode
import List.Extra as List
import Maybe.Extra as Maybe
import SubstancePlayer as Sub exposing (..)
import Task exposing (attempt)
import Tuple exposing (first, second)
import Url exposing (..)
import Url.Builder as Builder


type TypeFiltreSubstance
    = FiltrePotentielle
    | FiltreDynamique
    | FiltreRelation
    | FiltrePrincipale
    | FiltrePremiere
    | FiltreSeconde
    | FiltreIDSubstance
    | FiltreMetaData
    | FiltreDateTime


type alias FiltreSubstance =
    { metaData : Maybe (List String)
    , idSubstance : Maybe (List String)
    , listeFiltres : Maybe (List TypeFiltreSubstance)
    }


type TypeGeste
    = Significatif
    | Integratif
    | Harmonique


type TypeResultat
    = PotentielleSub
    | DynamiqueSub
    | RelationSub
    | SubstanceElement
    | ListeSubstanceElement
    | BinaryFile
    | DataString
    | DateTime
    | Duree


type alias Geste =
    { idGeste : String
    , idFonctionAcquisition : String
    , idApplication : String
    , typeResultat : TypeResultat
    , valeurDepart : Maybe (List String)
    , filtre : FiltreSubstance
    , catGeste : TypeGeste
    , metaData : String
    }


type ElementInteractif
    = SubstanceInteractiveElement SubstanceInteractive
    | InterfaceElement InterfaceInteractive
    | SubstanceInactiveElement SubstanceInactive
    | Container SubstanceContainer


type alias SubstanceInteractive =
    { metaData : String
    , substanceDisplay : Maybe (List Sub.Substance)
    , gesteAssocie : Geste
    }


type alias InterfaceInteractive =
    { metaData : String
    , interfaceElement : Maybe (List ElementGraphique)
    , gesteAssocie : Geste
    }


type alias SubstanceInactive =
    { metaData : String
    , substanceDisplay : Maybe (List Substance)
    , childrenSubstance : Maybe (List Substance)
    , autoDeploy : Bool
    , zoomable : Bool
    }


type alias SubstanceContainer =
    { metaData : String
    , interfaceElement : Maybe (List ElementGraphique)
    , gesteAssocie : Geste
    , autoDeploy : Bool
    , zoomable : Bool
    }


type alias ElementGraphique =
    { visuel : TypeMultimedia
    , valeur : String
    }


type TypeMultimedia
    = Bouton
    | Image
    | Video
    | Date
    | Text


type AppType
    = DidactiqueModule
    | ProprietaireModule
    | LocataireModule
    | FournisseurModule


type alias AppInfo =
    { appId : String
    , iconUrl : String
    , title : String
    , creatorId : String
    , appType : AppType
    , status : AppShareStatus
    }


type AppShareStatus
    = NoStatus
    | NotShared
    | Global
    | Selected (List String)


type alias PlayApp appMsg =
    { activeAppList : Maybe (List AppInfo)
    , activateApp : AppInfo -> appMsg
    , selectedAppId : String
    , deployAppMenu : AppInfo -> appMsg
    , shareState : AppShareStatus
    , appMenu : Maybe ( String, List (L.Attribute appMsg) )
    , recordChosen : appMsg
    , shareAllUserChecked : Bool -> appMsg
    , sendMsgAcquisition : SubstanceInteractive -> String -> appMsg
    , cancelSelection : SubstanceInteractive -> String -> appMsg
    , sendSubSelected : SubstanceInactive -> Sub.Substance -> appMsg
    , cancelZoom : appMsg
    , sendGeste : Geste -> appMsg
    , userId : String
    , subInterList : Maybe (List SubstanceInteractive)
    , interfaceList : Maybe (List InterfaceInteractive)
    , subInactiveList : Maybe (List SubstanceInactive)
    , chosenApp : Maybe AppInfo
    , dataToSend : InterfaceInteractive -> String -> appMsg
    , listSubDeployed : Maybe (List String)
    , deployedSubstance : Maybe (Sub.DeployedSubstance appMsg)
    , selectedSubstanceMenu : Maybe ( String, List (L.Attribute appMsg) )
    , deployOrigin : Maybe Sub.Substance
    , zoomedSubtance : Maybe Sub.Substance
    , recordZoom : Bool
    , record2File : Bool
    , deploymentList : Maybe (List String)
    , subContainerList : Maybe (List SubstanceContainer)
    , deployedContainer : Maybe (Sub.DeployedSubstance appMsg)
    , sendElemSelected : SubstanceContainer -> ElementGraphique -> appMsg
    , originElement : Maybe ElementGraphique
    , selectedElementMenu : Maybe ( String, List (L.Attribute appMsg) )
    , viewPortInfo : Maybe Viewport
    , deactivate : appMsg
    , unDeploy : appMsg
    , startSavingMime : appMsg
    }


initPlayer : (AppInfo -> appMsg) -> String -> (SubstanceInteractive -> String -> appMsg) -> (SubstanceInteractive -> String -> appMsg) -> (Geste -> appMsg) -> (InterfaceInteractive -> String -> appMsg) -> (SubstanceInactive -> Sub.Substance -> appMsg) -> appMsg -> (SubstanceContainer -> ElementGraphique -> appMsg) -> appMsg -> appMsg -> appMsg -> appMsg -> (AppInfo -> appMsg) -> (Bool -> appMsg) -> PlayApp appMsg
initPlayer activator userData messenger cancelMsg gesteSender dataSender subPicker zoomKiller elemPicker resetor fermeur recorder saveMime appMenuEvent allSharedSelected =
    { activeAppList = Nothing
    , deployAppMenu = appMenuEvent
    , activateApp = activator
    , userId = userData
    , sendMsgAcquisition = messenger
    , selectedAppId = ""
    , cancelSelection = cancelMsg
    , recordChosen = recorder
    , sendSubSelected = subPicker
    , sendGeste = gesteSender
    , sendElemSelected = elemPicker
    , startSavingMime = saveMime
    , shareAllUserChecked = allSharedSelected
    , subInterList = Nothing
    , interfaceList = Nothing
    , subInactiveList = Nothing
    , chosenApp = Nothing
    , dataToSend = dataSender
    , listSubDeployed = Nothing
    , deployedSubstance = Nothing
    , selectedSubstanceMenu = Nothing
    , appMenu = Nothing
    , deployOrigin = Nothing
    , zoomedSubtance = Nothing
    , recordZoom = False
    , record2File = False
    , deploymentList = Nothing
    , cancelZoom = zoomKiller
    , subContainerList = Nothing
    , deployedContainer = Nothing
    , originElement = Nothing
    , selectedElementMenu = Nothing
    , viewPortInfo = Nothing
    , deactivate = resetor
    , unDeploy = fermeur
    , shareState = NoStatus
    }


encodeGeste : Geste -> Encode.Value
encodeGeste v =
    Encode.object
        [ ( "IDGeste", Encode.string v.idGeste )
        , ( "IDFonctionAcquisition", Encode.string v.idFonctionAcquisition )
        , ( "IDApplication", Encode.string v.idApplication )
        , ( "TypeResultat"
          , case v.typeResultat of
                PotentielleSub ->
                    Encode.int 1

                DynamiqueSub ->
                    Encode.int 2

                RelationSub ->
                    Encode.int 3

                SubstanceElement ->
                    Encode.int 4

                ListeSubstanceElement ->
                    Encode.int 5

                BinaryFile ->
                    Encode.int 6

                DataString ->
                    Encode.int 7

                DateTime ->
                    Encode.int 8

                Duree ->
                    Encode.int 9
          )
        , ( "ValeurDepart"
          , case v.valeurDepart of
                Just val ->
                    Encode.list
                        (\valeur -> Encode.string valeur)
                        val

                Nothing ->
                    Encode.null
          )
        , ( "Filtre"
          , Encode.object
                [ ( "MetaData"
                  , case v.filtre.metaData of
                        Just meta ->
                            Encode.list
                                (\data -> Encode.string data)
                                meta

                        Nothing ->
                            Encode.null
                  )
                , ( "ValueData"
                  , case v.filtre.idSubstance of
                        Just idSub ->
                            Encode.list
                                (\subId -> Encode.string subId)
                                idSub

                        Nothing ->
                            Encode.null
                  )
                , ( "ListeFiltres"
                  , case v.filtre.listeFiltres of
                        Just filtre ->
                            Encode.list
                                (\vF ->
                                    case vF of
                                        FiltrePotentielle ->
                                            Encode.int 1

                                        FiltreDynamique ->
                                            Encode.int 2

                                        FiltreRelation ->
                                            Encode.int 3

                                        FiltrePrincipale ->
                                            Encode.int 4

                                        FiltrePremiere ->
                                            Encode.int 5

                                        FiltreSeconde ->
                                            Encode.int 6

                                        FiltreIDSubstance ->
                                            Encode.int 7

                                        FiltreMetaData ->
                                            Encode.int 8

                                        FiltreDateTime ->
                                            Encode.int 9
                                )
                                filtre

                        Nothing ->
                            Encode.null
                  )
                ]
          )
        , ( "CatGeste"
          , case v.catGeste of
                Significatif ->
                    Encode.string "Significatif"

                Integratif ->
                    Encode.string "Integratif"

                Harmonique ->
                    Encode.string "Harmonique"
          )
        , ( "MetaData", Encode.string v.metaData )
        ]


decodeTypeSubstanceFiltre : Decode.Decoder TypeFiltreSubstance
decodeTypeSubstanceFiltre =
    Decode.int
        |> Decode.andThen
            (\int ->
                case int of
                    1 ->
                        Decode.succeed FiltrePotentielle

                    2 ->
                        Decode.succeed FiltreDynamique

                    3 ->
                        Decode.succeed FiltreRelation

                    4 ->
                        Decode.succeed FiltrePrincipale

                    5 ->
                        Decode.succeed FiltrePremiere

                    6 ->
                        Decode.succeed FiltreSeconde

                    7 ->
                        Decode.succeed FiltreIDSubstance

                    8 ->
                        Decode.succeed FiltreMetaData

                    9 ->
                        Decode.succeed FiltreDateTime

                    _ ->
                        Decode.fail "Invalid TypeFiltreSubstance"
            )


decodeTypeResultat : Decode.Decoder TypeResultat
decodeTypeResultat =
    Decode.int
        |> Decode.andThen
            (\int ->
                case int of
                    1 ->
                        Decode.succeed PotentielleSub

                    2 ->
                        Decode.succeed DynamiqueSub

                    3 ->
                        Decode.succeed RelationSub

                    4 ->
                        Decode.succeed SubstanceElement

                    5 ->
                        Decode.succeed ListeSubstanceElement

                    6 ->
                        Decode.succeed BinaryFile

                    7 ->
                        Decode.succeed DataString

                    8 ->
                        Decode.succeed DateTime

                    9 ->
                        Decode.succeed Duree

                    _ ->
                        Decode.fail "Invalid TypeResultat"
            )


decodeFiltreSubstance : Decode.Decoder FiltreSubstance
decodeFiltreSubstance =
    Decode.map3 FiltreSubstance
        (Decode.field "metaData" (Decode.maybe (Decode.list Decode.string)))
        (Decode.field "idSubstance" (Decode.succeed Nothing))
        (Decode.field "listeFiltres"
            (Decode.maybe
                (Decode.list
                    decodeTypeSubstanceFiltre
                )
            )
        )


decodeTypeGeste : Decode.Decoder TypeGeste
decodeTypeGeste =
    Decode.string
        |> Decode.andThen
            (\string ->
                case string of
                    "Significatif" ->
                        Decode.succeed Significatif

                    "Integratif" ->
                        Decode.succeed Integratif

                    "Harmonique" ->
                        Decode.succeed Harmonique

                    _ ->
                        Decode.fail "Invalid TypeGeste"
            )


decodeGeste : Decode.Decoder Geste
decodeGeste =
    Decode.map8 Geste
        (Decode.field "idGeste" Decode.string)
        (Decode.field "idFonctionAcquisition" Decode.string)
        (Decode.field "idApplication" Decode.string)
        (Decode.field "typeResultat"
            decodeTypeResultat
        )
        (Decode.field "valeurDepart" (Decode.maybe (Decode.list Decode.string)))
        (Decode.field "filtre"
            decodeFiltreSubstance
        )
        (Decode.field "catGeste"
            decodeTypeGeste
        )
        (Decode.field "metaData" Decode.string)


decodeSubstancesInteractives : Decode.Decoder SubstanceInteractive
decodeSubstancesInteractives =
    Decode.map3 SubstanceInteractive
        (Decode.field "metaData" Decode.string)
        (Decode.field "substanceDisplay"
            (Decode.maybe
                (Decode.list
                    Sub.decodeSubstance
                )
            )
        )
        (Decode.field "gesteAssocie"
            decodeGeste
        )


decodeSubstanceInactive : Decode.Decoder SubstanceInactive
decodeSubstanceInactive =
    Decode.map5 SubstanceInactive
        (Decode.field "metaData" Decode.string)
        (Decode.field "substanceDisplay"
            (Decode.maybe
                (Decode.list
                    Sub.decodeSubstance
                )
            )
        )
        (Decode.field "childrenSubstance"
            (Decode.maybe
                (Decode.list
                    Sub.decodeSubstance
                )
            )
        )
        (Decode.field "autoDeploy" Decode.bool)
        (Decode.field "zoomable" Decode.bool)


decodeSubstanceContainer : Decode.Decoder SubstanceContainer
decodeSubstanceContainer =
    Decode.map5 SubstanceContainer
        (Decode.field "metaData" Decode.string)
        (Decode.field "interfaceElement"
            (Decode.maybe
                (Decode.list decodeElementGraphique)
            )
        )
        (Decode.field "gesteAssocie" decodeGeste)
        (Decode.field "autoDeploy" Decode.bool)
        (Decode.field "zoomable" Decode.bool)


decodeTypeMultimedia : Decode.Decoder TypeMultimedia
decodeTypeMultimedia =
    Decode.string
        |> Decode.andThen
            (\string ->
                case string of
                    "Bouton" ->
                        Decode.succeed Bouton

                    "Image" ->
                        Decode.succeed Image

                    "Video" ->
                        Decode.succeed Video

                    "Date" ->
                        Decode.succeed Date

                    "Text" ->
                        Decode.succeed Text

                    _ ->
                        Decode.fail "Invalid TypeMultimedia"
            )


decodeElementGraphique : Decode.Decoder ElementGraphique
decodeElementGraphique =
    Decode.map2 ElementGraphique
        (Decode.field "visuel"
            decodeTypeMultimedia
        )
        (Decode.field "valeur" Decode.string)


decodeInterfaceInteractive : Decode.Decoder InterfaceInteractive
decodeInterfaceInteractive =
    Decode.map3 InterfaceInteractive
        (Decode.field "metaData" Decode.string)
        (Decode.field "interfaceElement"
            (Decode.maybe
                (Decode.list
                    decodeElementGraphique
                )
            )
        )
        (Decode.field "gesteAssocie"
            decodeGeste
        )


decodeListeElementInteractif : Decode.Decoder (List ElementInteractif)
decodeListeElementInteractif =
    Decode.list
        (Decode.field "typeData" Decode.string
            |> Decode.andThen
                (\string ->
                    case string of
                        "interactive" ->
                            Decode.map SubstanceInteractiveElement decodeSubstancesInteractives

                        "interface" ->
                            Decode.map InterfaceElement decodeInterfaceInteractive

                        "inactive" ->
                            Decode.map SubstanceInactiveElement decodeSubstanceInactive

                        "container" ->
                            Decode.map Container decodeSubstanceContainer

                        _ ->
                            Decode.fail "Invalid ElementInteractif"
                )
        )


decodeAppType : Decode.Decoder AppType
decodeAppType =
    Decode.string
        |> Decode.andThen
            (\string ->
                case string of
                    "didactique" ->
                        Decode.succeed DidactiqueModule

                    "proprietaire" ->
                        Decode.succeed ProprietaireModule

                    "locataire" ->
                        Decode.succeed LocataireModule

                    "fournisseur" ->
                        Decode.succeed FournisseurModule

                    _ ->
                        Decode.fail "Invalid AppType"
            )


decodeShareStatus : Decode.Decoder AppShareStatus
decodeShareStatus =
    Decode.string
        |> Decode.andThen
            (\string ->
                case string of
                    "NoStatus" ->
                        Decode.succeed NoStatus

                    "NotShared" ->
                        Decode.succeed NotShared

                    "Global" ->
                        Decode.succeed Global

                    _ ->
                        Decode.fail "Invalid AppShareStatus"
            )


decodeAppInfo : Decode.Decoder AppInfo
decodeAppInfo =
    Decode.map6 AppInfo
        (Decode.field "appId" Decode.string)
        (Decode.field "iconUrl" Decode.string)
        (Decode.field "title" Decode.string)
        (Decode.field "creatorId" Decode.string)
        (Decode.field "appType"
            decodeAppType
        )
        (Decode.field "status" decodeShareStatus)


sendGeste : PlayApp appMsg -> Geste -> (Result Http.Error (List ElementInteractif) -> appMsg) -> Cmd appMsg
sendGeste appMsgPlayApp gesteSignificatif results =
    case appMsgPlayApp.chosenApp of
        Nothing ->
            Cmd.none

        Just chosen ->
            let
                gestePath =
                    Builder.absolute [ "gesteHandler" ]
                        [ Builder.string "appId" chosen.appId
                        ]
            in
            Http.post
                { url = gestePath
                , body = Http.jsonBody (encodeGeste gesteSignificatif)
                , expect = Http.expectJson results decodeListeElementInteractif
                }


executeLaunchApp : PlayApp appMsg -> String -> (Result Http.Error (List ElementInteractif) -> appMsg) -> Cmd appMsg
executeLaunchApp eleMsgAppEdited appId results =
    let
        appExecPath =
            Builder.absolute [ "activateLucasApplication" ]
                [ Builder.string "appId" appId
                , Builder.string "userId" eleMsgAppEdited.userId
                ]
    in
    Http.get
        { url = appExecPath
        , expect = Http.expectJson results decodeListeElementInteractif
        }


loadUpData : PlayApp appMsg -> List ElementInteractif -> PlayApp appMsg
loadUpData appMsgPlayApp substanceInteractiveList =
    case appMsgPlayApp.originElement of
        Just deployedElement ->
            let
                sequenceList =
                    List.filterMap siftInactive substanceInteractiveList
            in
            { appMsgPlayApp
                | subInactiveList = Just sequenceList
                , deployedContainer =
                    Just
                        { subId = deployedElement.valeur
                        , deployment =
                            row
                                (childrenContainer
                                    ++ [ onRight
                                            (button closerAttribute { onPress = Just appMsgPlayApp.unDeploy, label = L.text "X" })
                                       ]
                                )
                                (List.map (\a -> displayInactiveSubElement appMsgPlayApp a) sequenceList)
                        }
            }

        Nothing ->
            let
                listSequences =
                    List.filterMap siftContainer substanceInteractiveList
            in
            if List.length listSequences > 0 then
                { appMsgPlayApp
                    | subInterList = Just (List.filterMap siftSubInter substanceInteractiveList)
                    , interfaceList = Just (List.filterMap siftInterface substanceInteractiveList)
                    , subContainerList = Just listSequences
                    , subInactiveList = Nothing
                }

            else
                { appMsgPlayApp
                    | subInterList = Just (List.filterMap siftSubInter substanceInteractiveList)
                    , interfaceList = Just (List.filterMap siftInterface substanceInteractiveList)
                    , subContainerList = Nothing
                    , subInactiveList = Nothing
                }


siftSubInter : ElementInteractif -> Maybe SubstanceInteractive
siftSubInter elementInteractif =
    case elementInteractif of
        SubstanceInteractiveElement substanceInteractive ->
            Just substanceInteractive

        InterfaceElement interfaceInteractive ->
            Nothing

        SubstanceInactiveElement _ ->
            Nothing

        Container _ ->
            Nothing


siftInterface : ElementInteractif -> Maybe InterfaceInteractive
siftInterface elementInteractif =
    case elementInteractif of
        SubstanceInteractiveElement substanceInteractive ->
            Nothing

        InterfaceElement interfaceInteractive ->
            Just interfaceInteractive

        SubstanceInactiveElement _ ->
            Nothing

        Container _ ->
            Nothing


siftInactive : ElementInteractif -> Maybe SubstanceInactive
siftInactive elementInteractif =
    case elementInteractif of
        SubstanceInteractiveElement substanceInteractive ->
            Nothing

        InterfaceElement interfaceInteractive ->
            Nothing

        SubstanceInactiveElement subInactive ->
            Just subInactive

        Container _ ->
            Nothing


siftContainer : ElementInteractif -> Maybe SubstanceContainer
siftContainer elementInteractif =
    case elementInteractif of
        SubstanceInteractiveElement substanceInteractive ->
            Nothing

        InterfaceElement interfaceInteractive ->
            Nothing

        SubstanceInactiveElement subInactive ->
            Nothing

        Container subContainer ->
            Just subContainer


addPlayState : PlayApp appMsg -> Maybe (List AppInfo) -> PlayApp appMsg
addPlayState appMsgPlayApp appInfoList =
    { appMsgPlayApp | activeAppList = appInfoList }


setChosenApp : PlayApp appMsg -> AppInfo -> PlayApp appMsg
setChosenApp appMsgPlayApp appInfo =
    { appMsgPlayApp | chosenApp = Just appInfo }


idInterSubItem : SubstanceInteractive -> SubstanceInteractive -> Bool
idInterSubItem substanceInteractive substanceInteractive2 =
    substanceInteractive.gesteAssocie.idGeste == substanceInteractive2.gesteAssocie.idGeste


idInterface : InterfaceInteractive -> InterfaceInteractive -> Bool
idInterface interfaceInteractive interfaceInteractive2 =
    interfaceInteractive.gesteAssocie.idGeste == interfaceInteractive2.gesteAssocie.idGeste


deployContainer : PlayApp appMsg -> ElementGraphique -> PlayApp appMsg
deployContainer appMsgPlayApp elemGraph =
    { appMsgPlayApp | originElement = Just elemGraph }


resetPlayer : PlayApp appMsg -> PlayApp appMsg
resetPlayer appMsgPlayApp =
    { appMsgPlayApp | originElement = Nothing, deployOrigin = Nothing, subInactiveList = Nothing, shareState = NoStatus }


closePlayer : PlayApp appMsg -> PlayApp appMsg
closePlayer appMsgPlayApp =
    { appMsgPlayApp | originElement = Nothing, deployOrigin = Nothing, subInactiveList = Nothing, chosenApp = Nothing }


substanceClicked : PlayApp appMsg -> SubstanceInteractive -> String -> PlayApp appMsg
substanceClicked appMsgPlayApp interSubstance subId =
    case appMsgPlayApp.subInterList of
        Nothing ->
            appMsgPlayApp

        Just interSubList ->
            let
                filtreCourant =
                    interSubstance.gesteAssocie.filtre
            in
            case interSubstance.gesteAssocie.typeResultat of
                PotentielleSub ->
                    appMsgPlayApp

                DynamiqueSub ->
                    appMsgPlayApp

                RelationSub ->
                    appMsgPlayApp

                BinaryFile ->
                    appMsgPlayApp

                DataString ->
                    appMsgPlayApp

                DateTime ->
                    appMsgPlayApp

                Duree ->
                    appMsgPlayApp

                SubstanceElement ->
                    let
                        gesteActif =
                            interSubstance.gesteAssocie
                    in
                    { appMsgPlayApp
                        | subInterList = Just (List.setIf (idInterSubItem interSubstance) { interSubstance | gesteAssocie = { gesteActif | filtre = { filtreCourant | idSubstance = Just [ subId ] } } } interSubList)
                    }

                ListeSubstanceElement ->
                    let
                        gesteActif =
                            interSubstance.gesteAssocie
                    in
                    case filtreCourant.idSubstance of
                        Nothing ->
                            { appMsgPlayApp
                                | subInterList = Just (List.setIf (idInterSubItem interSubstance) { interSubstance | gesteAssocie = { gesteActif | filtre = { filtreCourant | idSubstance = Just [ subId ] } } } interSubList)
                            }

                        Just idList ->
                            { appMsgPlayApp
                                | subInterList = Just (List.setIf (idInterSubItem interSubstance) { interSubstance | gesteAssocie = { gesteActif | filtre = { filtreCourant | listeFiltres = Just [ FiltreIDSubstance ], idSubstance = Just (subId :: idList) } } } interSubList)
                            }


cancelSubstanceSelection : PlayApp appMsg -> SubstanceInteractive -> String -> PlayApp appMsg
cancelSubstanceSelection appMsgPlayApp interSubstance subId =
    case appMsgPlayApp.subInterList of
        Nothing ->
            appMsgPlayApp

        Just interSubList ->
            let
                filtreCourant =
                    interSubstance.gesteAssocie.filtre
            in
            case interSubstance.gesteAssocie.typeResultat of
                PotentielleSub ->
                    appMsgPlayApp

                DynamiqueSub ->
                    appMsgPlayApp

                RelationSub ->
                    appMsgPlayApp

                BinaryFile ->
                    appMsgPlayApp

                DataString ->
                    appMsgPlayApp

                DateTime ->
                    appMsgPlayApp

                Duree ->
                    appMsgPlayApp

                SubstanceElement ->
                    let
                        gesteActif =
                            interSubstance.gesteAssocie
                    in
                    { appMsgPlayApp
                        | subInterList = Just (List.setIf (idInterSubItem interSubstance) { interSubstance | gesteAssocie = { gesteActif | filtre = { filtreCourant | idSubstance = Nothing } } } interSubList)
                    }

                ListeSubstanceElement ->
                    let
                        gesteActif =
                            interSubstance.gesteAssocie
                    in
                    case filtreCourant.idSubstance of
                        Nothing ->
                            appMsgPlayApp

                        Just idList ->
                            { appMsgPlayApp
                                | subInterList = Just (List.setIf (idInterSubItem interSubstance) { interSubstance | gesteAssocie = { gesteActif | filtre = { filtreCourant | listeFiltres = Just [ FiltreIDSubstance ], idSubstance = Just (List.remove subId idList) } } } interSubList)
                            }


addDataToGeste : PlayApp appMsg -> String -> InterfaceInteractive -> PlayApp appMsg
addDataToGeste appMsgPlayApp data inputList =
    let
        gesteActif =
            inputList.gesteAssocie
    in
    case appMsgPlayApp.interfaceList of
        Just interList ->
            let
                filtreCourant =
                    inputList.gesteAssocie.filtre
            in
            { appMsgPlayApp | interfaceList = Just (List.setIf (idInterface inputList) { inputList | gesteAssocie = { gesteActif | filtre = { filtreCourant | idSubstance = Just [ data ] } } } interList) }

        Nothing ->
            appMsgPlayApp


addMenu2App : PlayApp appMsg -> AppInfo -> Maybe ( String, List (L.Attribute appMsg) ) -> PlayApp appMsg
addMenu2App appMsgPlayApp appInfo appMenu =
    case appMenu of
        Just newMenu ->
            { appMsgPlayApp | appMenu = Just newMenu, shareState = appInfo.status, selectedAppId = first newMenu }

        Nothing ->
            { appMsgPlayApp | appMenu = Nothing, shareState = NoStatus, selectedAppId = "" }


addContainer : PlayApp appMsg -> SubstanceContainer -> ( String, List (L.Attribute appMsg) ) -> PlayApp appMsg
addContainer appMsgPlayApp substanceContainer menuList =
    { appMsgPlayApp | selectedElementMenu = Just menuList, selectedSubstanceMenu = Nothing }


resetMenu : PlayApp appMsg -> PlayApp appMsg
resetMenu appMsgPlayApp =
    { appMsgPlayApp | selectedElementMenu = Nothing, selectedSubstanceMenu = Nothing, appMenu = Nothing }


recordZoomedSubstance : PlayApp appMsg -> PlayApp appMsg
recordZoomedSubstance appMsgPlayApp =
    { appMsgPlayApp | recordZoom = not appMsgPlayApp.recordZoom }


startSavingMime : PlayApp appMsg -> PlayApp appMsg
startSavingMime appMsgPlayApp =
    { appMsgPlayApp | record2File = not appMsgPlayApp.record2File }


resetDeployment : PlayApp appMsg -> PlayApp appMsg
resetDeployment appMsgPlayApp =
    { appMsgPlayApp | deployedContainer = Nothing, deployedSubstance = Nothing, deploymentList = Nothing, deployOrigin = Nothing }


addApplicationMenu : PlayApp appMsg -> AppInfo -> AppShareStatus -> PlayApp appMsg
addApplicationMenu appMsgPlayApp appInfo appShareStatus =
    { appMsgPlayApp | shareState = appShareStatus }


updateAppState : PlayApp appMsg -> Bool -> PlayApp appMsg
updateAppState appMsgPlayApp check4All =
    { appMsgPlayApp | shareState = Global }


sendAppState : PlayApp appMsg -> Bool -> (Result Http.Error () -> appMsg) -> Cmd appMsg
sendAppState appMsgPlayApp isGlobalChecked sentWhatev =
    let
        appStatusPath =
            Builder.absolute [ "setApplicationStatus" ]
                [ Builder.string "appId" appMsgPlayApp.selectedAppId
                , Builder.string "global"
                    (if isGlobalChecked then
                        "true"

                     else
                        "false"
                    )
                ]
    in
    Http.get
        { url = appStatusPath
        , expect = Http.expectWhatever sentWhatev
        }


addSubstance : PlayApp appMsg -> SubstanceInactive -> ( String, List (L.Attribute appMsg) ) -> PlayApp appMsg
addSubstance appMsgPlayApp substanceInactive menuList =
    case appMsgPlayApp.originElement of
        Just subContainer ->
            case appMsgPlayApp.deployOrigin of
                Just substance ->
                    case appMsgPlayApp.deploymentList of
                        Just deployList ->
                            let
                                appDeploy =
                                    { appMsgPlayApp
                                        | selectedSubstanceMenu = Just menuList
                                        , deployedSubstance =
                                            Just (Sub.xplodSubWithChild deployList (Maybe.withDefault [] substanceInactive.childrenSubstance) appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList)
                                    }
                            in
                            { appMsgPlayApp
                                | selectedSubstanceMenu = Just menuList
                                , selectedElementMenu = Nothing
                                , deployedSubstance =
                                    Just (Sub.xplodSubWithChild deployList (Maybe.withDefault [] substanceInactive.childrenSubstance) appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList)
                                , deployedContainer =
                                    Just
                                        { subId = subContainer.valeur
                                        , deployment =
                                            row
                                                (childrenContainer
                                                    ++ [ onRight
                                                            (button closerAttribute { onPress = Just appMsgPlayApp.unDeploy, label = L.text "X" })
                                                       ]
                                                )
                                                [ displayInactiveSubElement
                                                    appDeploy
                                                    substanceInactive
                                                ]
                                        }
                            }

                        Nothing ->
                            let
                                appList =
                                    { appMsgPlayApp
                                        | selectedSubstanceMenu = Just menuList
                                        , deployedSubstance =
                                            Just (Sub.xplodSub (Maybe.withDefault [] substanceInactive.childrenSubstance) substance (appMsgPlayApp.sendSubSelected substanceInactive) (Just menuList))
                                    }
                            in
                            { appMsgPlayApp
                                | selectedSubstanceMenu = Just menuList
                                , selectedElementMenu = Nothing
                                , deployedSubstance =
                                    Just (Sub.xplodSub (Maybe.withDefault [] substanceInactive.childrenSubstance) substance (appMsgPlayApp.sendSubSelected substanceInactive) (Just menuList))
                                , deployedContainer =
                                    Just
                                        { subId = subContainer.valeur
                                        , deployment =
                                            row
                                                (childrenContainer
                                                    ++ [ onRight
                                                            (button closerAttribute { onPress = Just appMsgPlayApp.unDeploy, label = L.text "X" })
                                                       ]
                                                )
                                                [ displayInactiveSubElement
                                                    appList
                                                    substanceInactive
                                                ]
                                        }
                            }

                Nothing ->
                    let
                        appPlay =
                            { appMsgPlayApp | selectedSubstanceMenu = Just menuList }
                    in
                    { appMsgPlayApp
                        | selectedSubstanceMenu = Just menuList
                        , selectedElementMenu = Nothing
                        , deployedContainer =
                            Just
                                { subId = subContainer.valeur
                                , deployment =
                                    row
                                        (childrenContainer
                                            ++ [ onRight
                                                    (button closerAttribute { onPress = Just appMsgPlayApp.unDeploy, label = L.text "X" })
                                               ]
                                        )
                                        [ displayInactiveSubElement
                                            appPlay
                                            substanceInactive
                                        ]
                                }
                    }

        Nothing ->
            case appMsgPlayApp.deployOrigin of
                Just substance ->
                    case appMsgPlayApp.deploymentList of
                        Just deployList ->
                            { appMsgPlayApp
                                | selectedSubstanceMenu = Just menuList
                                , selectedElementMenu = Nothing
                                , deployedSubstance =
                                    Just (Sub.xplodSubWithChild deployList (Maybe.withDefault [] substanceInactive.childrenSubstance) appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList)
                            }

                        Nothing ->
                            { appMsgPlayApp
                                | selectedSubstanceMenu = Just menuList
                                , selectedElementMenu = Nothing
                                , deployedSubstance =
                                    Just (Sub.xplodSub (Maybe.withDefault [] substanceInactive.childrenSubstance) substance (appMsgPlayApp.sendSubSelected substanceInactive) (Just menuList))
                            }

                Nothing ->
                    { appMsgPlayApp
                        | selectedSubstanceMenu = Just menuList
                        , selectedElementMenu = Nothing
                    }


zoomSubstance : PlayApp appMsg -> Sub.Substance -> PlayApp appMsg
zoomSubstance appMsgPlayApp substanceSub =
    { appMsgPlayApp | zoomedSubtance = Just substanceSub }


cancelZoom : PlayApp appMsg -> PlayApp appMsg
cancelZoom appMsgPlayApp =
    { appMsgPlayApp | zoomedSubtance = Nothing, recordZoom = False }


deploySubstance : PlayApp appMsg -> SubstanceInactive -> Substance -> ( String, List (L.Attribute appMsg) ) -> PlayApp appMsg
deploySubstance appMsgPlayApp substanceInactive substance menuList =
    case appMsgPlayApp.originElement of
        Just subContainer ->
            case substanceInactive.substanceDisplay of
                Just substanceList ->
                    case substanceInactive.childrenSubstance of
                        Just childrenList ->
                            let
                                newDeployment =
                                    Sub.setDeploymentList childrenList appMsgPlayApp.deploymentList [] appMsgPlayApp.deployOrigin (first menuList)
                            in
                            if List.member substance substanceList then
                                let
                                    appData =
                                        { appMsgPlayApp | deployedSubstance = Just (Sub.xplodSub childrenList substance (appMsgPlayApp.sendSubSelected substanceInactive) (Just menuList)), deployOrigin = Just substance }
                                in
                                { appMsgPlayApp
                                    | deployedSubstance = Just (Sub.xplodSubWithChild newDeployment childrenList appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList)
                                    , deploymentList = Just newDeployment
                                    , deployOrigin = Just substance
                                    , deployedContainer =
                                        Just
                                            { subId = subContainer.valeur
                                            , deployment =
                                                row
                                                    (childrenContainer
                                                        ++ [ onRight
                                                                (button closerAttribute { onPress = Just appMsgPlayApp.unDeploy, label = L.text "X" })
                                                           ]
                                                    )
                                                    [ displayInactiveSubElement
                                                        appData
                                                        substanceInactive
                                                    ]
                                            }
                                }

                            else if List.length newDeployment > 0 then
                                let
                                    appDetail =
                                        { appMsgPlayApp | deployedSubstance = Just (Sub.xplodSubWithChild newDeployment childrenList appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList), deploymentList = Just newDeployment }
                                in
                                { appMsgPlayApp
                                    | deployedSubstance = Just (Sub.xplodSubWithChild newDeployment childrenList appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList)
                                    , deploymentList = Just newDeployment
                                    , deployedContainer =
                                        Just
                                            { subId = subContainer.valeur
                                            , deployment =
                                                row
                                                    (childrenContainer
                                                        ++ [ onRight
                                                                (button closerAttribute { onPress = Just appMsgPlayApp.unDeploy, label = L.text "X" })
                                                           ]
                                                    )
                                                    [ displayInactiveSubElement
                                                        appDetail
                                                        substanceInactive
                                                    ]
                                            }
                                }

                            else
                                let
                                    appElem =
                                        { appMsgPlayApp | deployedSubstance = Just (Sub.xplodSubWithChild [ first menuList ] childrenList appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList), deploymentList = Just [ first menuList ] }
                                in
                                { appMsgPlayApp
                                    | deployedSubstance = Just (Sub.xplodSubWithChild [ first menuList ] childrenList appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList)
                                    , deploymentList = Just [ first menuList ]
                                    , deployedContainer =
                                        Just
                                            { subId = subContainer.valeur
                                            , deployment =
                                                row
                                                    (childrenContainer
                                                        ++ [ onRight
                                                                (button closerAttribute { onPress = Just appMsgPlayApp.unDeploy, label = L.text "X" })
                                                           ]
                                                    )
                                                    [ displayInactiveSubElement
                                                        appElem
                                                        substanceInactive
                                                    ]
                                            }
                                }

                        Nothing ->
                            appMsgPlayApp

                Nothing ->
                    appMsgPlayApp

        Nothing ->
            case substanceInactive.substanceDisplay of
                Just substanceList ->
                    case substanceInactive.childrenSubstance of
                        Just childrenList ->
                            let
                                newDeployment =
                                    Sub.setDeploymentList childrenList appMsgPlayApp.deploymentList [] appMsgPlayApp.deployOrigin (first menuList)
                            in
                            if List.member substance substanceList then
                                { appMsgPlayApp | deployedSubstance = Just (Sub.xplodSub childrenList substance (appMsgPlayApp.sendSubSelected substanceInactive) (Just menuList)), deployOrigin = Just substance }

                            else if List.length newDeployment > 0 then
                                { appMsgPlayApp | deployedSubstance = Just (Sub.xplodSubWithChild newDeployment childrenList appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList), deploymentList = Just newDeployment }

                            else
                                { appMsgPlayApp | deployedSubstance = Just (Sub.xplodSubWithChild [ first menuList ] childrenList appMsgPlayApp.deployOrigin (appMsgPlayApp.sendSubSelected substanceInactive) menuList), deploymentList = Just [ first menuList ] }

                        Nothing ->
                            appMsgPlayApp

                Nothing ->
                    appMsgPlayApp


afficherInterfaceSelection : String -> String -> eleMsg -> Element eleMsg
afficherInterfaceSelection url title onClickHandler =
    column [ L.width (px 400), L.height (px 400) ]
        [ button
            [ inFront
                (image [ alignTop, alignRight ]
                    { src = "img/Media/coin-folder.png"
                    , description = "Coin Image"
                    }
                )
            ]
            { label =
                image [ L.width (px 200), L.height (px 200) ]
                    { src = url
                    , description = title
                    }
            , onPress = Just onClickHandler
            }
        , L.text title
        ]


afficherApplicationWithMenu : String -> String -> eleMsg -> eleMsg -> Maybe ( String, List (L.Attribute eleMsg) ) -> eleMsg -> String -> Element eleMsg
afficherApplicationWithMenu url title onClickHandler onActivateMenu appMenu cancelMenu appId =
    case appMenu of
        Just menuList ->
            if appId == first menuList then
                column ([ L.width (px 400), L.height (px 400), onMouseLeave cancelMenu ] ++ second menuList)
                    [ button
                        [ inFront
                            (image [ alignTop, alignRight ]
                                { src = "img/Media/coin-folder.png"
                                , description = "Coin Image"
                                }
                            )
                        ]
                        { label =
                            image [ L.width (px 200), L.height (px 200) ]
                                { src = url
                                , description = title
                                }
                        , onPress = Just onClickHandler
                        }
                    , L.text title
                    ]

            else
                column [ L.width (px 400), L.height (px 400), onMouseEnter onActivateMenu ]
                    [ button
                        [ inFront
                            (image [ alignTop, alignRight ]
                                { src = "img/Media/coin-folder.png"
                                , description = "Coin Image"
                                }
                            )
                        ]
                        { label =
                            image [ L.width (px 200), L.height (px 200) ]
                                { src = url
                                , description = title
                                }
                        , onPress = Just onClickHandler
                        }
                    , L.text title
                    ]

        Nothing ->
            column [ L.width (px 400), L.height (px 400), onMouseEnter onActivateMenu ]
                [ button
                    [ inFront
                        (image [ alignTop, alignRight ]
                            { src = "img/Media/coin-folder.png"
                            , description = "Coin Image"
                            }
                        )
                    ]
                    { label =
                        image [ L.width (px 200), L.height (px 200) ]
                            { src = url
                            , description = title
                            }
                    , onPress = Just onClickHandler
                    }
                , L.text title
                ]


getAppAttribute : AppShareStatus -> (Bool -> appMsg) -> List (L.Attribute appMsg)
getAppAttribute appShareStatus checkHandler =
    case appShareStatus of
        NoStatus ->
            [ paddingXY 65 60
            , spacing 40
            , L.width fill
            , L.height fill
            , Border.rounded 20
            , Bg.color (rgb255 255 255 255)
            ]

        NotShared ->
            [ inFront
                (column [ padding 35, spacingXY 0 20 ]
                    [ row []
                        [ column [ alignLeft ]
                            [ paragraph [] [ L.text "Partage" ]
                            , paragraph [] [ L.text "APP TITLE" ]
                            ]
                        , image [ alignRight ]
                            { src = "img/Icons/share-icon2.png"
                            , description = "Partage Application"
                            }
                        ]
                    , checkbox [ alignRight ]
                        { onChange = checkHandler
                        , icon = defaultCheckbox
                        , checked = False
                        , label = labelLeft [] (L.text "Tous les utilisateurs")
                        }
                    ]
                )
            , paddingXY 65 60
            , spacing 40
            , L.width fill
            , L.height fill
            , Border.rounded 20
            , Bg.color (rgb255 255 255 255)
            ]

        Global ->
            [ inFront
                (column [ padding 35, spacingXY 0 20 ]
                    [ row []
                        [ column [ alignLeft ]
                            [ paragraph [] [ L.text "Partage" ]
                            , paragraph [] [ L.text "APP TITLE" ]
                            ]
                        , image [ alignRight ]
                            { src = "img/Icons/share-icon2.png"
                            , description = "Partage Application"
                            }
                        ]
                    , checkbox
                        [ alignRight ]
                        { onChange = checkHandler
                        , icon = defaultCheckbox
                        , checked = True
                        , label = labelLeft [] (L.text "Tous les utilisateurs")
                        }
                    ]
                )
            , paddingXY 65 60
            , spacing 40
            , L.width fill
            , L.height fill
            , Border.rounded 20
            , Bg.color (rgb255 255 255 255)
            ]

        Selected stringList ->
            []


displayAvailableApp : PlayApp appMsg -> Element appMsg
displayAvailableApp playMsg =
    case playMsg.activeAppList of
        Nothing ->
            L.text "Aucune application disponible"

        Just activatedList ->
            wrappedRow
                (getAppAttribute
                    playMsg.shareState
                    playMsg.shareAllUserChecked
                )
                (List.map (\a -> afficherPlayApp a playMsg) activatedList)


displayTitle : AppInfo -> Element appMsg
displayTitle appInfo =
    paragraph
        [ Font.color (rgb255 0 0 0)
        , Font.size 16
        , Font.bold
        , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
        , Font.center
        ]
        [ L.text appInfo.title
        ]


afficherPlayApp : AppInfo -> PlayApp appMsg -> Element appMsg
afficherPlayApp appInfo eleMsgAppEdited =
    case appInfo.appType of
        DidactiqueModule ->
            afficherApplicationWithMenu appInfo.iconUrl
                appInfo.title
                (eleMsgAppEdited.activateApp appInfo)
                (eleMsgAppEdited.deployAppMenu appInfo)
                eleMsgAppEdited.appMenu
                eleMsgAppEdited.deactivate
                appInfo.appId

        ProprietaireModule ->
            afficherInterfaceSelection appInfo.iconUrl
                "Exécuter l'Application Proprio"
                (eleMsgAppEdited.activateApp appInfo)

        LocataireModule ->
            afficherInterfaceSelection appInfo.iconUrl
                "Exécuter l'Application Locataire"
                (eleMsgAppEdited.activateApp appInfo)

        FournisseurModule ->
            afficherInterfaceSelection appInfo.iconUrl
                "Exécuter l'Application Fournisseur"
                (eleMsgAppEdited.activateApp appInfo)


displayInteractiveElement : PlayApp appMsg -> SubstanceInteractive -> Element appMsg
displayInteractiveElement appMsgPlayApp substanceInteractive =
    case substanceInteractive.substanceDisplay of
        Just substanceGraphElList ->
            column (mainContainerAttributes2 ++ [ onMouseLeave (appMsgPlayApp.sendGeste substanceInteractive.gesteAssocie) ])
                [ Sub.displayInteractiveSubstanceList substanceGraphElList (appMsgPlayApp.sendMsgAcquisition substanceInteractive) (appMsgPlayApp.cancelSelection substanceInteractive) substanceInteractive.gesteAssocie.filtre.idSubstance
                ]

        Nothing ->
            L.text ""


displayInactiveSubElement : PlayApp appMsg -> SubstanceInactive -> Element appMsg
displayInactiveSubElement appMsgPlayApp substanceInactive =
    case substanceInactive.substanceDisplay of
        Just substanceGraphElList ->
            column
                []
                [ Sub.displayInactiveSubstanceList
                    substanceGraphElList
                    (appMsgPlayApp.sendSubSelected substanceInactive)
                    appMsgPlayApp.selectedSubstanceMenu
                    appMsgPlayApp.deployedSubstance
                ]

        Nothing ->
            L.text ""


displayContainerElement : PlayApp appMsg -> SubstanceContainer -> Element appMsg
displayContainerElement appMsgPlayApp substanceContainer =
    case substanceContainer.interfaceElement of
        Just substanceGraphElList ->
            case appMsgPlayApp.chosenApp of
                Just activeApp ->
                    column
                        [ centerX ]
                        [ L.text substanceContainer.metaData
                        , displaySubstanceContainer
                            substanceGraphElList
                            activeApp
                            (appMsgPlayApp.sendElemSelected substanceContainer)
                            appMsgPlayApp.selectedElementMenu
                            appMsgPlayApp.deployedContainer
                            appMsgPlayApp.deactivate
                            substanceContainer.metaData
                        ]

                Nothing ->
                    L.text "no app"

        Nothing ->
            L.text ""


rowElementAttribute : List (L.Attribute eleMsg)
rowElementAttribute =
    [ spacingXY 30 0
    , centerX
    , Border.color (rgb255 229 229 229)
    ]


displaySubstanceContainer : List ElementGraphique -> AppInfo -> (ElementGraphique -> appMsg) -> Maybe ( String, List (L.Attribute appMsg) ) -> Maybe (DeployedSubstance appMsg) -> appMsg -> String -> Element appMsg
displaySubstanceContainer substanceList appInfo clickEventHandler selectedMenu deployedSubstance goneEvent titre =
    row rowElementAttribute
        (List.map (\a -> visualizeInterfaceWithMenu a appInfo clickEventHandler selectedMenu deployedSubstance goneEvent) substanceList)


sequenceVideo : String -> String -> ( Int, Int ) -> Element appMsg
sequenceVideo appId videoLink dimension =
    el
        [ centerX, centerY ]
        (L.html
            (video
                [ src ("https://storage.googleapis.com/lucascet-data/" ++ appId ++ "/" ++ videoLink ++ ".mp4")
                , controls True
                , H.width (first dimension)
                , H.height (second dimension)
                ]
                []
            )
        )


sequenceTextAttribute : List (L.Attribute appMsg)
sequenceTextAttribute =
    [ paddingXY 0 15
    , Font.color (rgb255 0 0 0)
    , Font.size 18
    , Font.bold
    , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
    , Font.center
    ]


selectedSequenceTextAttribute : List (L.Attribute appMsg)
selectedSequenceTextAttribute =
    [ paddingXY 0 15
    , Font.color (rgb255 226 89 55)
    , Font.size 18
    , Font.bold
    , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
    , Font.center
    ]


closerAttribute : List (L.Attribute appMsg)
closerAttribute =
    [ alignTop
    , centerX
    , Bg.color (rgb255 229 229 229)
    , Border.rounded 20
    , Font.size 28
    , Font.center
    , Font.color (rgb255 101 101 101)
    , moveLeft 5
    , moveUp 2
    , L.width (px 35)
    ]


visualizeInterfaceWithMenu : ElementGraphique -> AppInfo -> (ElementGraphique -> appMsg) -> Maybe ( String, List (L.Attribute appMsg) ) -> Maybe (DeployedSubstance appMsg) -> appMsg -> Element appMsg
visualizeInterfaceWithMenu elementGraphique appInfo clickEventHandler selectMenu deployedContainer goneEvent =
    case deployedContainer of
        Just visualContainer ->
            case selectMenu of
                Just menuOverlay ->
                    let
                        paraAttrib =
                            if elementGraphique.valeur == first menuOverlay then
                                selectedSequenceTextAttribute

                            else
                                sequenceTextAttribute
                    in
                    case elementGraphique.visuel of
                        Bouton ->
                            L.text "Error"

                        Image ->
                            L.text "Error"

                        Video ->
                            let
                                subAttribute =
                                    if elementGraphique.valeur == first menuOverlay then
                                        Sub.selectedSequenceAttribute ++ second menuOverlay ++ [ onMouseLeave goneEvent ]

                                    else
                                        Sub.sequenceAttribute
                            in
                            let
                                videoDimension =
                                    if elementGraphique.valeur == first menuOverlay then
                                        ( 200, 150 )

                                    else
                                        ( 185, 140 )
                            in
                            if elementGraphique.valeur == visualContainer.subId then
                                column [ centerX ]
                                    [ paragraph paraAttrib [ L.text elementGraphique.valeur ]
                                    , el
                                        (subAttribute
                                            ++ [ onMouseEnter (clickEventHandler elementGraphique) ]
                                        )
                                        (sequenceVideo appInfo.appId elementGraphique.valeur videoDimension)
                                    , image [ centerX ] { src = "img/Icons/triangle-relation.png", description = "Ouverture de Substance" }
                                    , visualContainer.deployment
                                    ]

                            else
                                column [ centerX, alignTop ]
                                    [ paragraph paraAttrib [ L.text elementGraphique.valeur ]
                                    , el
                                        (subAttribute
                                            ++ [ onMouseEnter (clickEventHandler elementGraphique) ]
                                        )
                                        (sequenceVideo appInfo.appId elementGraphique.valeur videoDimension)
                                    ]

                        _ ->
                            L.text "Error"

                Nothing ->
                    case elementGraphique.visuel of
                        Bouton ->
                            L.text "Error"

                        Image ->
                            L.text "Error"

                        Video ->
                            if elementGraphique.valeur == visualContainer.subId then
                                column [ centerX ]
                                    [ paragraph sequenceTextAttribute [ L.text elementGraphique.valeur ]
                                    , el
                                        (Sub.selectedSequenceAttribute
                                            ++ [ onMouseEnter (clickEventHandler elementGraphique) ]
                                            ++ [ onMouseLeave goneEvent ]
                                        )
                                        (sequenceVideo appInfo.appId elementGraphique.valeur ( 200, 150 ))
                                    , image [ centerX ] { src = "img/Icons/triangle-relation.png", description = "Ouverture de Substance" }
                                    , visualContainer.deployment
                                    ]

                            else
                                column
                                    (Sub.sequenceAttribute
                                        ++ [ onMouseEnter (clickEventHandler elementGraphique) ]
                                        ++ [ onMouseLeave goneEvent ]
                                    )
                                    [ paragraph sequenceTextAttribute [ L.text elementGraphique.valeur ]
                                    , sequenceVideo appInfo.appId elementGraphique.valeur ( 185, 140 )
                                    ]

                        _ ->
                            L.text "Error"

        Nothing ->
            case selectMenu of
                Just menuOverlay ->
                    case elementGraphique.visuel of
                        Bouton ->
                            L.text "Error"

                        Image ->
                            L.text "Error"

                        Video ->
                            if elementGraphique.valeur == first menuOverlay then
                                column [ centerX ]
                                    [ paragraph selectedSequenceTextAttribute [ L.text elementGraphique.valeur ]
                                    , el
                                        (Sub.selectedSequenceAttribute
                                            ++ second menuOverlay
                                            ++ [ onMouseLeave goneEvent ]
                                        )
                                        (sequenceVideo appInfo.appId elementGraphique.valeur ( 185, 140 ))
                                    ]

                            else
                                column (Sub.sequenceAttribute ++ [ onMouseEnter (clickEventHandler elementGraphique) ])
                                    [ paragraph sequenceTextAttribute [ L.text elementGraphique.valeur ]
                                    , sequenceVideo appInfo.appId elementGraphique.valeur ( 185, 140 )
                                    ]

                        _ ->
                            L.text "Error"

                Nothing ->
                    case elementGraphique.visuel of
                        Bouton ->
                            L.text "Error"

                        Image ->
                            L.text "Error"

                        Video ->
                            column (Sub.sequenceAttribute ++ [ onMouseEnter (clickEventHandler elementGraphique) ])
                                [ paragraph sequenceTextAttribute [ L.text elementGraphique.valeur ]
                                , sequenceVideo appInfo.appId elementGraphique.valeur ( 185, 140 )
                                ]

                        _ ->
                            L.text "Error"


displayHeaderElement : PlayApp appMsg -> InterfaceInteractive -> Element appMsg
displayHeaderElement appMsgPlayApp interfaceInteractive =
    case interfaceInteractive.interfaceElement of
        Just elementGraphiqueList ->
            row [ Bg.color (rgb255 51 51 51), L.width fill, Border.roundEach { topLeft = 20, topRight = 20, bottomLeft = 0, bottomRight = 0 }, spacing 60 ]
                ([ column []
                    [ paragraph
                        [ Font.color (rgb255 255 255 255)
                        , Font.size 31
                        , Font.bold
                        , Font.center
                        ]
                        [ L.text "Sélection"
                        ]
                    , paragraph
                        [ Font.color (rgb255 255 255 255)
                        , Font.size 31
                        , Font.bold
                        , Font.center
                        ]
                        [ L.text "Substances"
                        ]
                    ]
                 , image [ centerX, centerY ] { src = "img/Icons/carres-sequence.png", description = "Header icon" }
                 ]
                    ++ List.map
                        (\a -> visualizeInterface a interfaceInteractive appMsgPlayApp)
                        elementGraphiqueList
                    ++ [ button [ Border.rounded 15, Bg.color (rgb255 0 0 0), mouseOver [ Bg.color (rgb255 226 89 55) ] ]
                            { onPress = Just (appMsgPlayApp.sendGeste interfaceInteractive.gesteAssocie)
                            , label =
                                paragraph
                                    [ Font.color (rgb255 255 255 255)
                                    , Font.size 31
                                    , Font.center
                                    , centerX
                                    , centerY
                                    ]
                                    [ L.text "APPLIQUER" ]
                            }
                       ]
                )

        Nothing ->
            L.text "No Data"


displayInterfaceElement : PlayApp appMsg -> InterfaceInteractive -> Element appMsg
displayInterfaceElement appMsgPlayApp interfaceInteractive =
    case interfaceInteractive.interfaceElement of
        Just elementGraphiqueList ->
            row [ centerX ]
                (List.map
                    (\a -> visualizeInterface a interfaceInteractive appMsgPlayApp)
                    elementGraphiqueList
                )

        Nothing ->
            L.text "No Data"


visualizeInterface : ElementGraphique -> InterfaceInteractive -> PlayApp appMsg -> Element appMsg
visualizeInterface elementGraphique interfaceInteractive appMsgPlayApp =
    case elementGraphique.visuel of
        Bouton ->
            button
                [ Bg.color (rgb255 229 229 229)
                , L.height (px 140)
                , L.width (px 185)
                , moveDown 50
                , moveRight 30
                ]
                { onPress = Just (appMsgPlayApp.sendGeste interfaceInteractive.gesteAssocie)
                , label =
                    paragraph
                        [ Font.color (rgb255 185 185 185)
                        , Font.size 200
                        , Font.center
                        , centerX
                        , centerY
                        , moveUp 25
                        ]
                        [ L.text elementGraphique.valeur ]
                }

        Image ->
            L.text "Error"

        Video ->
            L.text "Error"

        Text ->
            case interfaceInteractive.gesteAssocie.filtre.idSubstance of
                Just listSub ->
                    Input.text inputInterfaceAttribute
                        { onChange = appMsgPlayApp.dataToSend interfaceInteractive
                        , text = Maybe.withDefault "" (List.head listSub)
                        , placeholder = Just (placeholder inputInterfaceTextAttribute (L.text elementGraphique.valeur))
                        , label = labelHidden elementGraphique.valeur
                        }

                Nothing ->
                    Input.text inputInterfaceAttribute
                        { onChange = appMsgPlayApp.dataToSend interfaceInteractive
                        , text = ""
                        , placeholder = Just (placeholder [] (L.text elementGraphique.valeur))
                        , label = labelHidden elementGraphique.valeur
                        }

        Date ->
            case interfaceInteractive.gesteAssocie.filtre.idSubstance of
                Just listSub ->
                    Input.text [ Border.innerGlow (L.rgb255 235 107 76) 2 ]
                        { onChange = appMsgPlayApp.dataToSend interfaceInteractive
                        , text = Maybe.withDefault "" (List.head listSub)
                        , placeholder = Just (placeholder [] (L.text elementGraphique.valeur))
                        , label = labelAbove [] (L.text elementGraphique.valeur)
                        }

                Nothing ->
                    Input.text [ Border.innerGlow (L.rgb255 235 107 76) 2 ]
                        { onChange = appMsgPlayApp.dataToSend interfaceInteractive
                        , text = ""
                        , placeholder = Just (placeholder [] (L.text elementGraphique.valeur))
                        , label = labelAbove [] (L.text elementGraphique.valeur)
                        }


zoomAttribute : List (L.Attribute appMsg)
zoomAttribute =
    [ L.width fill
    , L.height fill
    , Bg.color (rgb255 129 129 129)
    , scrollbarY
    , padding 30
    ]


updateViewport : PlayApp appMsg -> Viewport -> PlayApp appMsg
updateViewport appMsgPlayApp viewport =
    { appMsgPlayApp | viewPortInfo = Just viewport }


childrenContainer : List (L.Attribute appMsg)
childrenContainer =
    [ Bg.color (rgb255 229 229 229)
    , padding 20
    , Border.color (rgb255 229 229 229)
    , Border.width 2
    ]


mainContainerAttributes : List (L.Attribute appMsg)
mainContainerAttributes =
    [ L.width fill
    , L.height fill
    , spacingXY 30 0
    , padding 20
    , Bg.color (rgb255 255 255 255)
    , Border.rounded 15
    , Border.color (rgb255 229 229 229)
    , Border.width 1
    ]


mainContainerAttributes2 : List (L.Attribute appMsg)
mainContainerAttributes2 =
    [ L.width fill
    , L.height fill
    , spacingXY 30 0
    , padding 20
    , Bg.color (rgb255 255 255 255)
    , Border.roundEach { topLeft = 0, topRight = 0, bottomLeft = 15, bottomRight = 15 }
    , Border.color (rgb255 229 229 229)
    , Border.width 1
    , scrollbars
    ]


inputInterfaceAttribute : List (L.Attribute appMsg)
inputInterfaceAttribute =
    [ Border.widthEach { bottom = 4, left = 0, right = 0, top = 0 }
    , Border.color (rgb255 225 225 225)
    , Bg.color (rgb255 51 51 51)
    , paddingEach { top = 0, right = 0, bottom = 10, left = 0 }
    , Font.size 25
    , Font.color (rgb255 179 179 179)
    ]


inputInterfaceTextAttribute : List (L.Attribute appMsg)
inputInterfaceTextAttribute =
    [ Font.size 25
    , Font.color (rgb255 179 179 179)
    ]


appPlayAttribute : PlayApp appMsg -> List (L.Attribute appMsg)
appPlayAttribute appMsgPlayApp =
    case appMsgPlayApp.zoomedSubtance of
        Just _ ->
            zoomAttribute

        Nothing ->
            [ Bg.color (rgb255 229 229 229)
            , L.width fill
            , L.height fill
            , scrollbars
            , centerX
            , paddingEach
                { top = 35
                , bottom = 0
                , right = 0
                , left = 0
                }
            ]


displayChosenApp : PlayApp appMsg -> AppInfo -> Element appMsg
displayChosenApp appMsgPlayApp appInfo =
    case appMsgPlayApp.zoomedSubtance of
        Just substanceZoomed ->
            case appMsgPlayApp.viewPortInfo of
                Just viewInfo ->
                    el [ L.width fill, L.height fill ]
                        (Sub.displaySubstanceZoomed substanceZoomed
                            appMsgPlayApp.cancelZoom
                            appMsgPlayApp.recordChosen
                            appMsgPlayApp.startSavingMime
                            ( viewInfo.viewport.width - 240, viewInfo.viewport.height - 310 )
                            appMsgPlayApp.recordZoom
                            appMsgPlayApp.record2File
                        )

                Nothing ->
                    el [ L.width fill, L.height fill ]
                        (button
                            [ alignRight, alignBottom ]
                            { onPress = Just appMsgPlayApp.cancelZoom
                            , label =
                                paragraph
                                    [ Font.color (rgb255 107 107 107)
                                    , Font.size 30
                                    , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
                                    , Font.center
                                    , mouseOver [ Font.color (rgb255 255 255 255) ]
                                    ]
                                    [ L.text "X" ]
                            }
                        )

        Nothing ->
            case appMsgPlayApp.subContainerList of
                Just contList ->
                    case appMsgPlayApp.interfaceList of
                        Nothing ->
                            el [ L.width fill, L.height fill, padding 50 ]
                                (row mainContainerAttributes
                                    (List.map (\a -> displayContainerElement appMsgPlayApp a) contList)
                                )

                        Just interList ->
                            el [ L.width fill, L.height fill, padding 50 ]
                                (el mainContainerAttributes
                                    (row
                                        [ centerX
                                        , onRight
                                            (row [ centerX, alignTop, L.height (px 140) ]
                                                (List.map (\a -> displayInterfaceElement appMsgPlayApp a) interList)
                                            )
                                        ]
                                        (List.map (\a -> displayContainerElement appMsgPlayApp a) contList)
                                    )
                                )

                Nothing ->
                    case appMsgPlayApp.subInterList of
                        Nothing ->
                            case appMsgPlayApp.interfaceList of
                                Nothing ->
                                    L.text "No data to display"

                                Just interList ->
                                    column [ spacing 30, padding 75 ]
                                        (List.map (\a -> displayInterfaceElement appMsgPlayApp a) interList)

                        Just subInterList ->
                            case appMsgPlayApp.interfaceList of
                                Nothing ->
                                    column mainContainerAttributes
                                        (List.map (\a -> displayInteractiveElement appMsgPlayApp a) subInterList)

                                Just interList ->
                                    column [ L.width fill, L.height fill, padding 50 ]
                                        (List.map (\a -> displayHeaderElement appMsgPlayApp a) interList
                                            ++ List.map (\a -> displayInteractiveElement appMsgPlayApp a) subInterList
                                        )
