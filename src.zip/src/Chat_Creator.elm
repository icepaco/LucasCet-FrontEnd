module Chat_Creator exposing
    ( ChatData
    , Coordinate
    , GroupWidget
    , Model
    , Msg(..)
    , ToolWidget
    , VisualWidget
    , WidgetNature(..)
    , WidgetStatus(..)
    , initialize
    , update
    , view
    )

import Animation
import Browser exposing (Document)
import Browser.Dom as DOM exposing (Element, Error, getElement)
import Browser.Events exposing (onAnimationFrame)
import Element as L exposing (..)
import Element.Background as Bg exposing (color, gradient)
import Element.Border as Border exposing (..)
import Element.Events as Events exposing (..)
import Element.Input exposing (Option, OptionState(..), button, labelAbove, labelBelow, optionWith, radio)
import Graphic_Downloader as GraphicList exposing (..)
import Html exposing (video)
import Html.Attributes as H exposing (autoplay, controls, height, id, src, width)
import Html.Events exposing (custom, on)
import Http exposing (header)
import Json.Decode as Decode
import Json.Encode as Encode
import List.Extra as List
import Task exposing (attempt)
import Time exposing (Posix, millisToPosix, now)
import Url.Builder as Builder



-- MODEL


type alias Coordinate =
    { clientX : Float
    , clientY : Float
    }


type alias Rect =
    { point1 : Coordinate
    , point2 : Coordinate
    }


type alias Widget =
    { widgetIcon : String
    , displayUrl : String
    , widgetId : String
    , category : WidgetType
    }


type alias VisualWidget =
    { displayUrl : String
    , tools : List ToolWidget
    , position : Coordinate
    , widgetId : Int
    , category : WidgetNature
    }


type alias ToolWidget =
    { displayUrl : String
    , position : Coordinate
    , widgetId : Int
    , parentId : Int
    }


type alias GroupWidget =
    { displayUrl : String
    , widgetId : Int
    , position : Coordinate
    , constituant : List VisualWidget
    , answer : Int
    }


type WidgetType
    = Visual
    | Tool Coordinate
    | Group (Maybe GroupWidget)


type WidgetNature
    = Image
    | Video


type WidgetStatus
    = SubstanceSearch Coordinate
    | NothingSoFar


type RadioWidget
    = RadioVideo Int
    | RadioImage Int


type alias ChatData =
    { completedWidgets : List VisualWidget
    , groupWidgets : List GroupWidget
    , contactId : String
    }


type alias Model =
    { widgetBlueprints : List Widget
    , imgChoices : GraphicList.GraphicData Msg
    , videoChoices : GraphicList.GraphicData Msg
    , draggedWidget : Maybe Widget
    , dragStatus : WidgetStatus
    , selectedWidget : Maybe (List VisualWidget)
    , chatInfo : ChatData
    , nbAdjustment : Float
    , userId : String
    }


decodeWidgets : Decode.Decoder (List Widget)
decodeWidgets =
    Decode.list
        (Decode.map4
            Widget
            (Decode.field "widgetIcon" Decode.string)
            (Decode.field "displayUrl" Decode.string)
            (Decode.field "widgetId" Decode.string)
            (Decode.field "category" Decode.string
                |> Decode.andThen directionFromString
            )
        )


directionFromString : String -> Decode.Decoder WidgetType
directionFromString string =
    case string of
        "Visual" ->
            Decode.succeed Visual

        "Tool" ->
            Decode.succeed (Tool (Coordinate 0 0))

        _ ->
            Decode.fail ("Invalid direction: " ++ string)



-- INIT


initialize : String -> ChatData -> Model
initialize userIdValue messageChat =
    { widgetBlueprints =
        [ Widget "/../img/Icons/video.png" "rien" "idVideo" Visual
        , Widget "/../img/Icons/tool.jpg"
            "/../img/Tools/encercle.jpg"
            "idCercle"
            (Tool
                (Coordinate 0 0)
            )
        , Widget "/../img/Icons/question.jpg"
            "/../img/Tools/question_dessin.jpg"
            "idQuestion"
            (Tool (Coordinate 0 0))
        , Widget "/../img/Icons/radio.png" "/../img/Icons/radio.png" "idGroup" (Group Maybe.Nothing)
        ]
    , imgChoices = GraphicList.initGraphic userIdValue "image" ImagePicked LoadNextImgSet LoadPreviousImgSet
    , videoChoices = GraphicList.initGraphic userIdValue "video" VideoPicked LoadNextVideoSet LoadPreviousVideoSet
    , draggedWidget = Maybe.Nothing
    , dragStatus = NothingSoFar
    , selectedWidget = Maybe.Nothing
    , chatInfo = messageChat
    , nbAdjustment = -1
    , userId = userIdValue
    }



-- Update


showWidgets : Cmd Msg
showWidgets =
    let
        url =
            "/widgetBlueprints"
    in
    Http.get
        { url = url
        , expect = Http.expectJson ShowWidgets decodeWidgets
        }


saveChat : ChatData -> String -> Cmd Msg
saveChat recipient myId =
    let
        chatUpload =
            Builder.absolute [ "uploadChatMsg" ]
                [ Builder.string "recipientId"
                    recipient.contactId
                , Builder.string
                    "userId"
                    myId
                ]
    in
    Http.request
        { method = "POST"
        , headers =
            [ header "Accept" "*/*"
            , header "Accept-Encoding" "gzip, deflate, br"
            ]
        , url = chatUpload
        , body = Http.jsonBody (encodeChat { recipient | contactId = myId })
        , expect = Http.expectWhatever PostDone
        , timeout = Nothing
        , tracker = Nothing
        }


encodeChat : ChatData -> Encode.Value
encodeChat data =
    Encode.object
        [ ( "completedWidgets"
          , Encode.list
                (\vWidget ->
                    Encode.object
                        [ ( "displayUrl", Encode.string vWidget.displayUrl )
                        , ( "tools"
                          , Encode.list
                                (\v ->
                                    Encode.object
                                        [ ( "displayUrl", Encode.string v.displayUrl )
                                        , ( "position"
                                          , Encode.object
                                                [ ( "clientX", Encode.float v.position.clientX )
                                                , ( "clientY", Encode.float v.position.clientY )
                                                ]
                                          )
                                        , ( "widgetId", Encode.int v.widgetId )
                                        , ( "parentId", Encode.int v.parentId )
                                        ]
                                )
                                vWidget.tools
                          )
                        , ( "position"
                          , Encode.object
                                [ ( "clientX", Encode.float vWidget.position.clientX )
                                , ( "clientY", Encode.float vWidget.position.clientY )
                                ]
                          )
                        , ( "widgetId", Encode.int vWidget.widgetId )
                        , ( "category"
                          , case vWidget.category of
                                Image ->
                                    Encode.string "Image"

                                Video ->
                                    Encode.string "Video"
                          )
                        ]
                )
                data.completedWidgets
          )
        , ( "groupWidgets"
          , Encode.list
                (\group ->
                    Encode.object
                        [ ( "displayUrl", Encode.string group.displayUrl )
                        , ( "widgetId", Encode.int group.widgetId )
                        , ( "position"
                          , Encode.object
                                [ ( "clientX", Encode.float group.position.clientX )
                                , ( "clientY", Encode.float group.position.clientY )
                                ]
                          )
                        , ( "constituant"
                          , Encode.list
                                (\widget ->
                                    Encode.object
                                        [ ( "displayUrl", Encode.string widget.displayUrl )
                                        , ( "tools"
                                          , Encode.list
                                                (\v ->
                                                    Encode.object
                                                        [ ( "displayUrl", Encode.string v.displayUrl )
                                                        , ( "position"
                                                          , Encode.object
                                                                [ ( "clientX", Encode.float v.position.clientX )
                                                                , ( "clientY", Encode.float v.position.clientY )
                                                                ]
                                                          )
                                                        , ( "widgetId", Encode.int v.widgetId )
                                                        , ( "parentId", Encode.int v.parentId )
                                                        ]
                                                )
                                                widget.tools
                                          )
                                        , ( "position"
                                          , Encode.object
                                                [ ( "clientX", Encode.float widget.position.clientX )
                                                , ( "clientY", Encode.float widget.position.clientY )
                                                ]
                                          )
                                        , ( "widgetId", Encode.int widget.widgetId )
                                        , ( "category"
                                          , case widget.category of
                                                Image ->
                                                    Encode.string "Image"

                                                Video ->
                                                    Encode.string "Video"
                                          )
                                        ]
                                )
                                group.constituant
                          )
                        , ( "answer", Encode.int group.answer )
                        ]
                )
                data.groupWidgets
          )
        , ( "contactId", Encode.string data.contactId )
        ]


type Msg
    = ShowWidgets (Result Http.Error (List Widget))
    | StartDrag Widget
    | DropWidgetOnWidget VisualWidget Coordinate
    | DropWidgetOnCanvas Coordinate
    | ImagePicked String
    | VideoPicked String
    | RienFaire
    | UpdateSelection VisualWidget
    | ToggleGroup Widget
    | GotAnswer GroupWidget Int
    | GotElement (Result Error DOM.Element)
    | GotElementContainer (Result Error DOM.Element)
    | GotImageList (Result Http.Error GraphicList)
    | GotVideoList (Result Http.Error GraphicList)
    | LoadNextImgSet
    | LoadNextVideoSet
    | LoadPreviousImgSet
    | LoadPreviousVideoSet
    | SaveChatInfo
    | PostDone (Result Http.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        LoadNextImgSet ->
            case model.imgChoices.graphicPages of
                Maybe.Just pages ->
                    let
                        choices =
                            model.imgChoices
                    in
                    if model.imgChoices.currentPage + 2 > List.length pages then
                        ( { model | imgChoices = { choices | currentPage = choices.currentPage + 1 } }
                        , GraphicList.obtainGraphicList model.imgChoices GotImageList
                        )

                    else
                        ( { model | imgChoices = GraphicList.updateGraphicData { choices | currentPage = choices.currentPage + 1 } }
                        , Cmd.none
                        )

                Maybe.Nothing ->
                    ( model, Cmd.none )

        LoadNextVideoSet ->
            case model.videoChoices.graphicPages of
                Maybe.Just pages ->
                    let
                        choices =
                            model.videoChoices
                    in
                    if model.videoChoices.currentPage + 2 > List.length pages then
                        ( { model | videoChoices = { choices | currentPage = choices.currentPage + 1 } }
                        , GraphicList.nextGraphicList model.videoChoices GotVideoList
                        )

                    else
                        ( { model | videoChoices = GraphicList.updateGraphicData { choices | currentPage = choices.currentPage + 1 } }
                        , Cmd.none
                        )

                Maybe.Nothing ->
                    ( model, Cmd.none )

        LoadPreviousImgSet ->
            let
                choices =
                    model.imgChoices
            in
            ( { model | imgChoices = GraphicList.updateGraphicData { choices | currentPage = choices.currentPage - 1 } }
            , Cmd.none
            )

        LoadPreviousVideoSet ->
            let
                choices =
                    model.videoChoices
            in
            ( { model | videoChoices = GraphicList.updateGraphicData { choices | currentPage = choices.currentPage - 1 } }
            , Cmd.none
            )

        GotImageList (Result.Ok imagesPackage) ->
            ( { model
                | imgChoices =
                    GraphicList.addNewPage imagesPackage model.imgChoices
                        |> GraphicList.updateGraphicData
              }
            , GraphicList.obtainGraphicList model.videoChoices GotVideoList
            )

        GotImageList (Result.Err _) ->
            ( model, Cmd.none )

        GotVideoList (Result.Ok videoPackage) ->
            ( { model
                | videoChoices =
                    GraphicList.addNewPage videoPackage model.videoChoices
                        |> GraphicList.updateGraphicData
              }
            , Cmd.none
            )

        GotVideoList (Result.Err _) ->
            ( model, Cmd.none )

        ShowWidgets (Result.Ok lstWidgets) ->
            ( { model | widgetBlueprints = lstWidgets }, Cmd.none )

        ShowWidgets (Result.Err _) ->
            ( model, Cmd.none )

        StartDrag widget ->
            case widget.category of
                Tool _ ->
                    ( { model | draggedWidget = Maybe.Just widget }, attempt GotElement <| getElement widget.widgetId )

                _ ->
                    if model.nbAdjustment >= 0 then
                        ( { model | draggedWidget = Maybe.Just widget }, Cmd.none )

                    else
                        ( { model | draggedWidget = Maybe.Just widget }
                        , attempt GotElementContainer <| getElement "mainContainer"
                        )

        DropWidgetOnWidget parentWidget clientPoint ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    let
                        minfo =
                            model.chatInfo
                    in
                    case widget.category of
                        Tool elem ->
                            ( { model
                                | draggedWidget = Maybe.Nothing
                                , dragStatus = NothingSoFar
                                , chatInfo =
                                    { minfo
                                        | completedWidgets =
                                            List.updateAt parentWidget.widgetId
                                                (\a -> createToolWidget widget.displayUrl (Coordinate clientPoint.clientX (clientPoint.clientY - model.nbAdjustment)) elem a)
                                                model.chatInfo.completedWidgets
                                    }
                              }
                            , Cmd.none
                            )

                        _ ->
                            ( model, Cmd.none )

        DropWidgetOnCanvas clientPoint ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    case widget.category of
                        Visual ->
                            ( { model | dragStatus = SubstanceSearch clientPoint }
                            , GraphicList.obtainGraphicList model.imgChoices GotImageList
                            )

                        Group value ->
                            let
                                minfo =
                                    model.chatInfo
                            in
                            case value of
                                Maybe.Just gridget ->
                                    ( { model
                                        | chatInfo =
                                            { minfo
                                                | groupWidgets =
                                                    { gridget | position = Coordinate clientPoint.clientX (clientPoint.clientY - model.nbAdjustment) }
                                                        :: model.chatInfo.groupWidgets
                                            }
                                        , draggedWidget = Maybe.Nothing
                                      }
                                    , Cmd.none
                                    )

                                Maybe.Nothing ->
                                    ( model, Cmd.none )

                        _ ->
                            ( model, Cmd.none )

        ImagePicked src ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    let
                        minfo =
                            model.chatInfo
                    in
                    case model.dragStatus of
                        SubstanceSearch clientPoint ->
                            ( { model
                                | chatInfo =
                                    { minfo
                                        | completedWidgets =
                                            createSubstanceWidget (Coordinate clientPoint.clientX (clientPoint.clientY - model.nbAdjustment)) src (List.length model.chatInfo.completedWidgets) Image
                                                :: model.chatInfo.completedWidgets
                                    }
                                , draggedWidget = Maybe.Nothing
                                , dragStatus = NothingSoFar
                              }
                            , Cmd.none
                            )

                        NothingSoFar ->
                            ( model, Cmd.none )

        VideoPicked src ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    let
                        minfo =
                            model.chatInfo
                    in
                    case model.dragStatus of
                        SubstanceSearch clientPoint ->
                            ( { model
                                | chatInfo =
                                    { minfo
                                        | completedWidgets =
                                            createSubstanceWidget (Coordinate clientPoint.clientX (clientPoint.clientY - model.nbAdjustment)) src (List.length model.chatInfo.completedWidgets) Video
                                                :: model.chatInfo.completedWidgets
                                    }
                                , draggedWidget = Maybe.Nothing
                                , dragStatus = NothingSoFar
                              }
                            , Cmd.none
                            )

                        NothingSoFar ->
                            ( model, Cmd.none )

        RienFaire ->
            ( model, Cmd.none )

        UpdateSelection widget2Add ->
            case model.selectedWidget of
                Maybe.Just selection ->
                    ( { model | selectedWidget = Maybe.Just (widget2Add :: selection) }, Cmd.none )

                Maybe.Nothing ->
                    ( { model | selectedWidget = Maybe.Just [ widget2Add ] }, Cmd.none )

        ToggleGroup widget ->
            case widget.category of
                Visual ->
                    ( model, Cmd.none )

                Tool _ ->
                    ( model, Cmd.none )

                Group _ ->
                    let
                        minfo =
                            model.chatInfo
                    in
                    case model.selectedWidget of
                        Maybe.Nothing ->
                            ( model, Cmd.none )

                        Maybe.Just selectedWidgets ->
                            ( { model
                                | selectedWidget = Maybe.Nothing
                                , draggedWidget =
                                    Maybe.Just
                                        { widget
                                            | category = Group (Maybe.Just (createGroupWidget widget selectedWidgets (List.length model.chatInfo.groupWidgets)))
                                        }
                                , chatInfo =
                                    { minfo
                                        | completedWidgets =
                                            List.filter (\a -> List.notMember a selectedWidgets)
                                                model.chatInfo.completedWidgets
                                    }
                              }
                            , Cmd.none
                            )

        GotElement (Result.Err _) ->
            ( model, Cmd.none )

        GotElement (Result.Ok elem) ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    case widget.category of
                        Tool _ ->
                            ( { model | draggedWidget = Maybe.Just { widget | category = Tool (Coordinate elem.element.width elem.element.height) } }
                            , Cmd.none
                            )

                        _ ->
                            ( model, Cmd.none )

        GotElementContainer (Result.Err _) ->
            ( model, Cmd.none )

        GotElementContainer (Result.Ok elem) ->
            ( { model | nbAdjustment = elem.element.y }, Cmd.none )

        GotAnswer widget val ->
            let
                minfo =
                    model.chatInfo
            in
            ( { model
                | chatInfo =
                    { minfo
                        | groupWidgets =
                            List.updateAt widget.widgetId
                                (always
                                    { widget | answer = val }
                                )
                                model.chatInfo.groupWidgets
                    }
              }
            , Cmd.none
            )

        SaveChatInfo ->
            ( model, saveChat model.chatInfo model.userId )

        PostDone (Result.Err _) ->
            ( model, Cmd.none )

        PostDone (Result.Ok _) ->
            ( model, Cmd.none )


selectedVisual : ( Rect, VisualWidget ) -> Bool
selectedVisual ( bound, widget ) =
    widget.position.clientX
        > bound.point1.clientX
        && widget.position.clientY
        > bound.point1.clientY
        && widget.position.clientX
        < bound.point2.clientX
        && widget.position.clientY
        < bound.point2.clientY


decorateVideo : String -> L.Element Msg
decorateVideo videoLink =
    el
        [ Bg.color (rgb255 0 0 0), padding 10, L.width fill, L.height fill ]
        (el [ centerX, centerY ] (L.html (video [ H.width 200, H.height 200, src videoLink, controls True ] [])))


empowerVideo : String -> Msg -> L.Element Msg
empowerVideo videoLink clickCmd =
    el
        [ Bg.color (rgb255 0 0 0), padding 10, L.width fill, L.height fill, onClick clickCmd ]
        (el [ centerX, centerY ] (L.html (video [ src videoLink, controls True ] [])))


plansWidget : ( Model, Widget ) -> L.Element Msg
plansWidget ( model, widget ) =
    case widget.category of
        Visual ->
            image [ onDrag (StartDrag widget) ] { src = widget.widgetIcon, description = widget.widgetIcon }

        Tool _ ->
            if not (List.isEmpty model.chatInfo.completedWidgets) then
                image [ onDrag (StartDrag widget), htmlAttribute (id widget.widgetId) ] { src = widget.widgetIcon, description = widget.widgetIcon }

            else
                text ""

        Group _ ->
            case model.selectedWidget of
                Maybe.Nothing ->
                    text ""

                Maybe.Just _ ->
                    image [ onDrag (ToggleGroup widget) ] { src = widget.widgetIcon, description = widget.widgetIcon }


affiche : VisualWidget -> L.Element Msg
affiche widget =
    case widget.category of
        Image ->
            image
                ([ htmlAttribute (id (String.fromInt widget.widgetId))
                 , L.width (px 900)
                 , L.height (px 300)
                 ]
                    ++ List.map outille widget.tools
                )
                { src = widget.displayUrl, description = "Visual widget" }

        Video ->
            el
                ([ htmlAttribute (id (String.fromInt widget.widgetId))
                 ]
                    ++ List.map outille widget.tools
                )
                (decorateVideo widget.displayUrl)


afficheEnFace : VisualWidget -> L.Attribute Msg
afficheEnFace widget =
    case widget.category of
        Image ->
            inFront
                (image
                    ([ moveRight widget.position.clientX
                     , moveDown widget.position.clientY
                     , htmlAttribute (id (String.fromInt widget.widgetId))
                     , L.width (px 900)
                     , L.height (px 300)
                     , onClick (UpdateSelection widget)
                     ]
                        ++ List.map outille widget.tools
                    )
                    { src = widget.displayUrl, description = "Visual widget" }
                )

        Video ->
            inFront
                (el
                    ([ moveRight widget.position.clientX
                     , moveDown widget.position.clientY
                     , htmlAttribute (id (String.fromInt widget.widgetId))
                     , onClick (UpdateSelection widget)
                     ]
                        ++ List.map outille widget.tools
                    )
                    (decorateVideo widget.displayUrl)
                )


outille : ToolWidget -> L.Attribute Msg
outille tool =
    inFront
        (image
            [ alpha 0.2
            , moveRight tool.position.clientX
            , moveDown tool.position.clientY
            ]
            { src = tool.displayUrl, description = tool.displayUrl }
        )


prepareWidget : VisualWidget -> L.Attribute Msg
prepareWidget widget =
    case widget.category of
        Image ->
            inFront
                (image
                    ([ moveRight widget.position.clientX
                     , moveDown widget.position.clientY
                     , Bg.color (rgb255 105 105 105)
                     , L.width (px 900)
                     , L.height (px 300)
                     , onDrop (DropWidgetOnWidget widget)
                     , htmlAttribute (id (String.fromInt widget.widgetId))
                     , htmlAttribute (custom "dragover" (Decode.succeed { message = RienFaire, stopPropagation = True, preventDefault = True }))
                     ]
                        ++ List.map
                            outille
                            widget.tools
                    )
                    { src = widget.displayUrl, description = widget.displayUrl }
                )

        Video ->
            inFront
                (el
                    ([ moveRight widget.position.clientX
                     , moveDown widget.position.clientY
                     , Bg.color (rgb255 105 105 105)
                     , onDrop (DropWidgetOnWidget widget)
                     , htmlAttribute (id (String.fromInt widget.widgetId))
                     , htmlAttribute (custom "dragover" (Decode.succeed { message = RienFaire, stopPropagation = True, preventDefault = True }))
                     ]
                        ++ List.map
                            outille
                            widget.tools
                    )
                    (decorateVideo widget.displayUrl)
                )


illumine : VisualWidget -> L.Element Msg
illumine widget =
    case widget.category of
        Image ->
            image
                [ Bg.color (rgb255 55 55 55), Border.width 2, L.width (px 200), L.height (px 200) ]
                { src = widget.displayUrl, description = widget.displayUrl }

        Video ->
            L.el [ Bg.color (rgb255 55 55 55), Border.width 2 ]
                (decorateVideo widget.displayUrl)


illumineEnFace : VisualWidget -> L.Attribute Msg
illumineEnFace widget =
    case widget.category of
        Image ->
            inFront
                (image
                    [ Bg.color (rgb255 55 55 55), Border.width 2, moveRight widget.position.clientX, moveDown widget.position.clientY, L.width (px 900), L.height (px 300) ]
                    { src = widget.displayUrl, description = widget.displayUrl }
                )

        Video ->
            inFront
                (L.el [ Bg.color (rgb255 55 55 55), Border.width 2, moveRight widget.position.clientX, moveDown widget.position.clientY ]
                    (decorateVideo widget.displayUrl)
                )


askQuestion : GroupWidget -> L.Attribute Msg
askQuestion widget =
    inFront
        (radio
            [ padding 5
            , spaceEvenly
            , Border.innerGlow (L.rgb255 150 150 55) 5
            , moveRight widget.position.clientX
            , moveDown widget.position.clientY
            , scrollbars
            ]
            { onChange = GotAnswer widget
            , selected = Just widget.answer
            , options = List.indexedMap displayChoice widget.constituant
            , label = labelAbove [] (text "Questionnaire:")
            }
        )


displayChoice : Int -> VisualWidget -> Option Int Msg
displayChoice value widget =
    case widget.category of
        Image ->
            optionWith value <|
                \state ->
                    case state of
                        Selected ->
                            illumine widget

                        _ ->
                            affiche widget

        Video ->
            optionWith value <|
                \state ->
                    case state of
                        Selected ->
                            illumine widget

                        _ ->
                            affiche widget


onDrag : msg -> Attribute msg
onDrag msg =
    htmlAttribute <| on "dragstart" (Decode.succeed msg)


onDrop : (Coordinate -> msg) -> Attribute msg
onDrop msg =
    htmlAttribute <|
        on "drop"
            (Decode.map2 Coordinate (Decode.field "clientX" Decode.float) (Decode.field "clientY" Decode.float)
                |> Decode.map msg
            )


onMouseDown : (Coordinate -> msg) -> Attribute msg
onMouseDown msg =
    htmlAttribute <|
        on "mousedown"
            (Decode.map2 Coordinate (Decode.field "clientX" Decode.float) (Decode.field "clientY" Decode.float)
                |> Decode.map msg
            )


onMouseMove : (Coordinate -> msg) -> Attribute msg
onMouseMove msg =
    htmlAttribute <|
        on "mousemove"
            (Decode.map2 Coordinate (Decode.field "clientX" Decode.float) (Decode.field "clientY" Decode.float)
                |> Decode.map msg
            )


onMouseUp : (Coordinate -> msg) -> Attribute msg
onMouseUp msg =
    htmlAttribute <|
        on "mouseup"
            (Decode.map2 Coordinate (Decode.field "clientX" Decode.float) (Decode.field "clientY" Decode.float)
                |> Decode.map msg
            )


createToolWidget : String -> Coordinate -> Coordinate -> VisualWidget -> VisualWidget
createToolWidget src point elem widget =
    { widget
        | tools =
            ToolWidget src
                { point
                    | clientX = (point.clientX - widget.position.clientX) - elem.clientX / 2
                    , clientY = (point.clientY - widget.position.clientY) - elem.clientY / 2
                }
                (List.length widget.tools)
                widget.widgetId
                :: widget.tools
    }


createSubstanceWidget : Coordinate -> String -> Int -> WidgetNature -> VisualWidget
createSubstanceWidget point src widgetId nature =
    VisualWidget src [] point widgetId nature


createGroupWidget : Widget -> List VisualWidget -> Int -> GroupWidget
createGroupWidget widget selectedWidgets widgetId =
    GroupWidget widget.displayUrl widgetId (Coordinate 0 0) selectedWidgets 0


mainContainerAttributes : List (L.Attribute msg) -> List (L.Attribute msg)
mainContainerAttributes events =
    events
        ++ [ L.height (fillPortion 4)
           , L.width fill
           , Border.innerGlow (L.rgb255 105 55 200) 5
           , htmlAttribute (id "mainContainer")
           ]


secondContainerAttributes : List (L.Attribute msg) -> List (L.Attribute msg)
secondContainerAttributes events =
    events
        ++ [ L.height (fillPortion 4), L.width fill, htmlAttribute (id "mainContainer") ]


view : Model -> Document Msg
view model =
    case model.dragStatus of
        SubstanceSearch coor ->
            { title = "LUCAS CHAT"
            , body =
                [ layout [ L.height fill ]
                    (column [ L.height fill ]
                        [ row [ L.height (fillPortion 1) ]
                            (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                        , GraphicList.showImageList [ L.height (fillPortion 4), L.width fill ] model.imgChoices
                        , GraphicList.showVideoList [ L.height (fillPortion 4), L.width fill ] model.videoChoices
                        ]
                    )
                ]
            }

        NothingSoFar ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    case model.selectedWidget of
                        Maybe.Nothing ->
                            { title = "LUCAS CHAT"
                            , body =
                                [ layout
                                    [ L.height fill, L.width fill, alignTop ]
                                    (column [ L.height fill, L.width fill, alignTop ]
                                        [ row [ L.height (fillPortion 1), L.width fill ]
                                            (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints
                                                ++ [ button [ Border.innerGlow (L.rgb255 15 5 20) 2 ]
                                                        { onPress = Maybe.Just SaveChatInfo
                                                        , label = text "Send message"
                                                        }
                                                   ]
                                            )
                                        , text "Select a Widget or create a selection"
                                        , row
                                            (secondContainerAttributes
                                                (List.map afficheEnFace model.chatInfo.completedWidgets
                                                    ++ List.map askQuestion
                                                        model.chatInfo.groupWidgets
                                                )
                                            )
                                            []
                                        ]
                                    )
                                ]
                            }

                        Maybe.Just selWidgets ->
                            { title = "LUCAS CHAT"
                            , body =
                                [ layout
                                    [ L.height fill, L.width fill, alignTop ]
                                    (column [ L.height fill, L.width fill, alignTop ]
                                        [ row [ L.height (fillPortion 1), L.width fill ] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                        , text "Selection confirmed"
                                        , row
                                            (secondContainerAttributes
                                                (List.map
                                                    afficheEnFace
                                                    (List.filter (\a -> List.notMember a selWidgets) model.chatInfo.completedWidgets)
                                                    ++ List.map illumineEnFace selWidgets
                                                )
                                                ++ List.map askQuestion model.chatInfo.groupWidgets
                                            )
                                            []
                                        ]
                                    )
                                ]
                            }

                Maybe.Just widget ->
                    case widget.category of
                        Visual ->
                            { title = "LUCAS CHAT"
                            , body =
                                [ layout
                                    [ L.height fill, L.width fill ]
                                    (column [ L.height fill, L.width fill ]
                                        [ row [ L.height (fillPortion 1), L.width fill ] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                        , row
                                            (mainContainerAttributes
                                                [ onDrop DropWidgetOnCanvas
                                                , htmlAttribute (custom "dragover" (Decode.succeed { message = RienFaire, stopPropagation = True, preventDefault = True }))
                                                ]
                                                ++ List.map afficheEnFace model.chatInfo.completedWidgets
                                                ++ List.map askQuestion model.chatInfo.groupWidgets
                                            )
                                            []
                                        ]
                                    )
                                ]
                            }

                        Tool _ ->
                            { title = "LUCAS CHAT"
                            , body =
                                [ layout
                                    [ L.height fill, L.width fill ]
                                    (column [ L.height fill, L.width fill ]
                                        [ row [ L.height (fillPortion 1), L.width fill ] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                        , row
                                            (mainContainerAttributes
                                                (List.map
                                                    prepareWidget
                                                    model.chatInfo.completedWidgets
                                                    ++ List.map askQuestion model.chatInfo.groupWidgets
                                                )
                                            )
                                            []
                                        ]
                                    )
                                ]
                            }

                        Group _ ->
                            { title = "LUCAS CHAT"
                            , body =
                                [ layout
                                    [ L.height fill, L.width fill ]
                                    (column [ L.height fill, L.width fill ]
                                        [ row [ L.height (fillPortion 1), L.width fill ] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                        , text "Place group widget"
                                        , row
                                            (mainContainerAttributes
                                                [ onDrop DropWidgetOnCanvas
                                                , htmlAttribute (custom "dragover" (Decode.succeed { message = RienFaire, stopPropagation = True, preventDefault = True }))
                                                ]
                                                ++ List.map afficheEnFace model.chatInfo.completedWidgets
                                                ++ List.map askQuestion model.chatInfo.groupWidgets
                                            )
                                            []
                                        ]
                                    )
                                ]
                            }
