module ChatTest exposing
    ( GroupWidget
    , Model(..)
    , Msg(..)
    , VisualWidget
    , affiche
    , displayChoice
    , illumine
    , onChange
    , outille
    , view
    )

import Css as Colors
import Html
import Html.Styled exposing (..)
import Html.Styled.Attributes exposing (..)
import Html.Styled.Events exposing (..)
import Http
import Json.Decode as Decode
import List.Extra as List



-- MODEL


type alias Coordinate =
    { clientX : Float
    , clientY : Float
    }


type alias Rect =
    { point1 : Coordinate
    , point2 : Coordinate
    }


type TypeAnswer
    = Single (Maybe String)
    | Multi (Maybe (List String))


type alias Widget =
    { widgetIcon : String
    , displayUrl : String
    , category : WidgetType
    }


type alias VisualWidget =
    { displayUrl : String
    , tools : List ToolWidget
    , position : Coordinate
    , widgetId : Int
    , category : WidgetNature
    }


type alias ToolWidget =
    { displayUrl : String
    , position : Coordinate
    , widgetId : Int
    , parentId : Int
    }


type alias GroupWidget =
    { displayUrl : String
    , widgetId : Int
    , constituant : List VisualWidget
    , answer : TypeAnswer
    }


type WidgetType
    = Visual
    | Tool Coordinate
    | Group TypeAnswer


type WidgetNature
    = Image
    | Video


type WidgetStatus
    = SubstanceSearch Coordinate
    | NothingSoFar


type alias Model =
    { widgetBlueprints : List Widget
    , draggedWidget : Maybe Widget
    , dragStatus : WidgetStatus
    , rectSelect : Maybe Rect
    , selectedWidget : Maybe (List VisualWidget)
    , completedWidgets : List VisualWidget
    , groupWidgets : List GroupWidget
    }


decodeWidgets : Decode.Decoder (List Widget)
decodeWidgets =
    Decode.list
        (Decode.map3
            Widget
            (Decode.field "widgetIcon" Decode.string)
            (Decode.field "displayUrl" Decode.string)
            (Decode.field "category" Decode.string
                |> Decode.andThen directionFromString
            )
        )


directionFromString : String -> Decode.Decoder WidgetType
directionFromString string =
    case string of
        "Visual" ->
            Decode.succeed Visual

        "Tool" ->
            Decode.succeed (Tool (Coordinate 0 0))

        _ ->
            Decode.fail ("Invalid direction: " ++ string)



-- INIT


initialize : ( Model, Cmd Msg )
initialize =
    ( { widgetBlueprints =
            [ Widget "img/Icons/video.png" "rien" Visual
            , Widget "img/Icons/tool.jpg"
                "img/Tools/encercle.svg"
                (Tool (Coordinate 0 0))
            , Widget "img/Icons/question.jpg"
                "img/Tools/question_dessin.svg"
                (Tool (Coordinate 0 0))
            , Widget "img/Icons/radio.png" "img/Icons/radio.png" (Group (Single Maybe.Nothing))
            ]
      , draggedWidget = Maybe.Nothing
      , dragStatus = NothingSoFar
      , rectSelect = Maybe.Nothing
      , selectedWidget = Maybe.Nothing
      , completedWidgets = []
      , groupWidgets = []
      }
    , Cmd.none
    )


showWidgets : Cmd Msg
showWidgets =
    let
        url =
            "/widgetBlueprints"
    in
    Http.send ShowWidgets (Http.get url decodeWidgets)



-- Update


type Msg
    = ShowWidgets (Result Http.Error (List Widget))
    | StartDrag Widget
    | DropWidgetOnWidget VisualWidget Coordinate
    | DropWidgetOnCanvas Coordinate
    | SustancePicked Coordinate String WidgetNature
    | RienFaire
    | UpdatePosition Coordinate
    | StartSelection Coordinate
    | UpdateSelection Coordinate
    | ConfirmSelection Coordinate
    | ToggleGroup Widget
    | GotAnswer GroupWidget String


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ShowWidgets (Result.Ok lstWidgets) ->
            ( { model | widgetBlueprints = lstWidgets }, Cmd.none )

        ShowWidgets (Result.Err _) ->
            ( model, Cmd.none )

        StartDrag widget ->
            ( { model | draggedWidget = Maybe.Just widget }, Cmd.none )

        DropWidgetOnWidget parentWidget clientPoint ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    case widget.category of
                        Visual ->
                            ( model, Cmd.none )

                        Group _ ->
                            ( model, Cmd.none )

                        Tool delta ->
                            ( { model
                                | completedWidgets =
                                    List.updateAt parentWidget.widgetId
                                        (\a -> createToolWidget (widget.displayUrl clientPoint delta a))
                                        model.completedWidgets
                                , draggedWidget = Maybe.Nothing
                                , dragStatus = NothingSoFar
                              }
                            , Cmd.none
                            )

        DropWidgetOnCanvas clientPoint ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    ( { model | dragStatus = SubstanceSearch clientPoint }, Cmd.none )

        SustancePicked clientPoint source nature ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    ( { model
                        | completedWidgets =
                            createSubstanceWidget (clientPoint source List.length model.completedWidgets nature)
                                :: model.completedWidgets
                        , draggedWidget = Maybe.Nothing
                        , dragStatus = NothingSoFar
                      }
                    , Cmd.none
                    )

        RienFaire ->
            ( model, Cmd.none )

        UpdatePosition delta ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just widget ->
                    case widget.category of
                        Visual ->
                            ( model, Cmd.none )

                        Group _ ->
                            ( model, Cmd.none )

                        Tool _ ->
                            ( { model | draggedWidget = Maybe.Just { widget | category = Tool delta } }, Cmd.none )

        StartSelection depart ->
            ( { model | rectSelect = Maybe.Just (Rect depart depart) }, Cmd.none )

        UpdateSelection terminus ->
            case model.rectSelect of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just rect ->
                    ( { model | rectSelect = Maybe.Just { rect | point2 = terminus } }, Cmd.none )

        ConfirmSelection terminus ->
            case model.rectSelect of
                Maybe.Nothing ->
                    ( model, Cmd.none )

                Maybe.Just rect ->
                    let
                        listSelection =
                            List.filter (\a -> selectedVisual ( rect, a )) model.completedWidgets
                    in
                    if List.isEmpty listSelection then
                        ( { model
                            | rectSelect = Maybe.Nothing
                            , selectedWidget = Maybe.Nothing
                          }
                        , Cmd.none
                        )

                    else
                        ( { model
                            | rectSelect = Maybe.Nothing
                            , selectedWidget = Maybe.Just listSelection
                          }
                        , Cmd.none
                        )

        ToggleGroup widget ->
            case widget.category of
                Visual ->
                    ( model, Cmd.none )

                Tool _ ->
                    ( model, Cmd.none )

                Group answerType ->
                    case model.selectedWidget of
                        Maybe.Nothing ->
                            ( model, Cmd.none )

                        Maybe.Just selectedWidgets ->
                            ( { model
                                | selectedWidget = Maybe.Nothing
                                , completedWidgets =
                                    List.filter (\a -> List.notMember a selectedWidgets)
                                        model.completedWidgets
                                , groupWidgets = createGroupWidget (widget answerType selectedWidgets List.length model.groupWidgets) :: model.groupWidgets
                              }
                            , Cmd.none
                            )

        GotAnswer widget val ->
            case widget.answer of
                Single _ ->
                    ( { model
                        | groupWidgets =
                            List.updateAt widget.widgetId
                                (always
                                    { widget | answer = Single (Maybe.Just val) }
                                )
                                model.groupWidgets
                      }
                    , Cmd.none
                    )

                Multi answers ->
                    case answers of
                        Maybe.Nothing ->
                            ( model, Cmd.none )

                        Maybe.Just reponses ->
                            if List.member val reponses then
                                ( { model
                                    | groupWidgets =
                                        List.updateAt widget.widgetId
                                            (always { widget | answer = Multi (Maybe.Just (List.remove val reponses)) })
                                            model.groupWidgets
                                  }
                                , Cmd.none
                                )

                            else
                                ( { model
                                    | groupWidgets =
                                        List.updateAt widget.widgetId
                                            (always { widget | answer = Multi (Maybe.Just (val :: reponses)) })
                                            model.groupWidgets
                                  }
                                , Cmd.none
                                )


selectedVisual : ( Rect, VisualWidget ) -> Bool
selectedVisual ( bound, widget ) =
    widget.position.clientX
        > bound.point1.clientX
        && widget.position.clientY
        > bound.point1.clientY
        && widget.position.clientX
        < bound.point2.clientX
        && widget.position.clientY
        < bound.point2.clientY


plansWidget : ( Model, Widget ) -> Html Msg
plansWidget ( model, widget ) =
    case widget.category of
        Visual ->
            img [ src widget.widgetIcon, onDrag (StartDrag widget) ] []

        Tool _ ->
            if not (List.isEmpty model.completedWidgets) then
                img [ src widget.widgetIcon, onDrag (StartDrag widget) ] []

            else
                text ""

        Group _ ->
            case model.selectedWidget of
                Maybe.Nothing ->
                    text ""

                Maybe.Just _ ->
                    img [ src widget.widgetIcon, onClick (ToggleGroup widget) ] []


affiche : VisualWidget -> Html Msg
affiche widget =
    Html.Styled.div
        [ Html.Styled.Attributes.css
            [ Css.position Css.fixed
            , Css.left (Css.px widget.position.clientX)
            , Css.top (Css.px widget.position.clientY)
            ]
        ]
        (List.append
            [ case widget.category of
                Image ->
                    img
                        [ src widget.displayUrl
                        , Html.Styled.Attributes.css
                            [ Css.position Css.relative
                            ]
                        ]
                        []

                Video ->
                    video
                        [ src widget.displayUrl
                        , Html.Styled.Attributes.controls True
                        , Html.Styled.Attributes.css
                            [ Css.position Css.relative
                            ]
                        ]
                        []
            ]
            (List.map
                outille
                widget.tools
            )
        )


outille : ToolWidget -> Html Msg
outille tool =
    Html.Styled.img
        [ src tool.displayUrl
        , Html.Styled.Attributes.css
            [ Css.opacity (Css.num 0.2)
            , Css.position Css.absolute
            , Css.left (Css.px tool.position.clientX)
            , Css.top (Css.px tool.position.clientY)
            , Css.zIndex (Css.int 2)
            ]
        ]
        []


prepareWidget : VisualWidget -> Html Msg
prepareWidget widget =
    Html.Styled.div
        [ Html.Styled.Attributes.css
            [ Css.position Css.fixed
            , Css.left (Css.px widget.position.clientX)
            , Css.top (Css.px widget.position.clientY)
            , Css.backgroundColor Colors.blue
            ]
        , onDrop (DropWidgetOnWidget widget)
        , onWithOptions "dragover" { stopPropagation = True, preventDefault = True } (Decode.succeed RienFaire)
        ]
        (List.append
            [ case widget.category of
                Image ->
                    img
                        [ src widget.displayUrl
                        , Html.Styled.Attributes.css
                            [ Css.position Css.relative
                            ]
                        ]
                        []

                Video ->
                    video
                        [ src widget.displayUrl
                        , Html.Styled.Attributes.controls True
                        , Html.Styled.Attributes.css
                            [ Css.position Css.relative
                            ]
                        ]
                        []
            ]
            (List.map
                outille
                widget.tools
            )
        )


illumine : VisualWidget -> Html Msg
illumine widget =
    Html.Styled.div
        [ Html.Styled.Attributes.css
            [ Css.position Css.fixed
            , Css.left (Css.px widget.position.clientX)
            , Css.top (Css.px widget.position.clientY)
            , Css.backgroundColor Colors.purple
            , Css.borderWidth (Css.em 2)
            ]
        ]
        (List.append
            [ case widget.category of
                Image ->
                    img
                        [ src widget.displayUrl
                        ]
                        []

                Video ->
                    video
                        [ src widget.displayUrl
                        , Html.Styled.Attributes.controls True
                        ]
                        []
            ]
            (List.map
                outille
                widget.tools
            )
        )


askQuestion : GroupWidget -> List (Html Msg)
askQuestion widget =
    List.indexedMap (\i a -> displayChoice ( widget, i, a )) widget.constituant


displayChoice : ( GroupWidget, Int, VisualWidget ) -> Html Msg
displayChoice ( group, val, widget ) =
    case group.answer of
        Single valeur ->
            Html.Styled.label
                [ Html.Styled.Attributes.css
                    [ Css.position Css.fixed
                    , Css.left (Css.px widget.position.clientX)
                    , Css.top (Css.px widget.position.clientY)
                    ]
                ]
                [ Html.Styled.input
                    [ Html.Styled.Attributes.type_ "radio"
                    , Html.Styled.Attributes.name (toString group.widgetId)
                    , Html.Styled.Attributes.id (toString val)
                    , Html.Styled.Attributes.value (toString val)
                    , onChange (GotAnswer group)
                    , Html.Styled.Attributes.css
                        [ Css.position Css.absolute, Css.zIndex (Css.int 2) ]
                    ]
                    []
                , case valeur of
                    Maybe.Nothing ->
                        affiche widget

                    Maybe.Just reponse ->
                        if toString val == reponse then
                            illumine widget

                        else
                            affiche widget
                ]

        Multi valeur ->
            Html.Styled.label
                [ Html.Styled.Attributes.css
                    [ Css.position Css.fixed
                    , Css.left (Css.px widget.position.clientX)
                    , Css.top (Css.px widget.position.clientY)
                    ]
                ]
                [ Html.Styled.input
                    [ Html.Styled.Attributes.type_ "radio"
                    , Html.Styled.Attributes.name (toString group.widgetId)
                    , Html.Styled.Attributes.id (toString val)
                    , Html.Styled.Attributes.value (toString val)
                    , onChange (GotAnswer group)
                    , Html.Styled.Attributes.css
                        [ Css.position Css.absolute, Css.zIndex (Css.int 2) ]
                    ]
                    []
                , case valeur of
                    Maybe.Nothing ->
                        affiche widget

                    Maybe.Just reponses ->
                        if List.member (toString val) reponses then
                            illumine widget

                        else
                            affiche widget
                ]


onChange : (String -> msg) -> Attribute msg
onChange msg =
    on "change" (Html.Styled.Events.targetValue |> Decode.map msg)


onDrag : msg -> Attribute msg
onDrag msg =
    on "dragstart" (Decode.succeed msg)


onDrop : (Coordinate -> msg) -> Attribute msg
onDrop msg =
    on "drop"
        (Decode.map2 Coordinate (Decode.field "clientX" Decode.float) (Decode.field "clientY" Decode.float)
            |> Decode.map msg
        )


onMouseDown : (Coordinate -> msg) -> Attribute msg
onMouseDown msg =
    on "mousedown"
        (Decode.map2 Coordinate (Decode.field "clientX" Decode.float) (Decode.field "clientY" Decode.float)
            |> Decode.map msg
        )


onMouseMove : (Coordinate -> msg) -> Attribute msg
onMouseMove msg =
    on "mousemove"
        (Decode.map2 Coordinate (Decode.field "clientX" Decode.float) (Decode.field "clientY" Decode.float)
            |> Decode.map msg
        )


onMouseUp : (Coordinate -> msg) -> Attribute msg
onMouseUp msg =
    on "mouseup"
        (Decode.map2 Coordinate (Decode.field "clientX" Decode.float) (Decode.field "clientY" Decode.float)
            |> Decode.map msg
        )


onDragOver : msg -> Attribute msg
onDragOver msg =
    onWithOptions "dragenter" { stopPropagation = True, preventDefault = True } (Decode.succeed msg)


onLoad : (Coordinate -> msg) -> Attribute msg
onLoad msg =
    on "load" (Decode.map2 Coordinate (DOM.target offsetWidth) (DOM.target offsetHeight) |> Decode.map msg)


createToolWidget : ( String, Coordinate, Coordinate, VisualWidget ) -> VisualWidget
createToolWidget ( source, point, delta, widget ) =
    { widget
        | tools =
            ToolWidget source
                { point
                    | clientX = point.clientX - widget.position.clientX - delta.clientX / 2
                    , clientY = point.clientY - widget.position.clientY - delta.clientY / 2
                }
                (List.length widget.tools)
                widget.widgetId
                :: widget.tools
    }


createSubstanceWidget : ( Coordinate, String, Int, WidgetNature ) -> VisualWidget
createSubstanceWidget ( point, source, widgetId, nature ) =
    VisualWidget source [] point widgetId nature


createGroupWidget : ( Widget, TypeAnswer, List VisualWidget, Int ) -> GroupWidget
createGroupWidget ( widget, answerType, selectedWidgets, widgetId ) =
    GroupWidget widget.displayUrl widgetId selectedWidgets answerType


view : Model -> Html Msg
view model =
    case model.dragStatus of
        SubstanceSearch coor ->
            Html.Styled.div
                []
                [ section [] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                , section [ Html.Styled.Attributes.css [ Css.height (Css.vh 80.0), Css.width (Css.vw 100.0) ] ]
                    [ Html.Styled.img
                        [ src "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/solucycle-bornes.png"
                        , Html.Styled.Events.onClick
                            (SustancePicked coor
                                "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/solucycle-bornes.png"
                                Image
                            )
                        ]
                        []
                    , Html.Styled.video
                        [ src "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/vid1.mp4"
                        , Html.Styled.Events.onClick
                            (SustancePicked coor
                                "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/vid1.mp4"
                                Video
                            )
                        , Html.Styled.Attributes.controls True
                        ]
                        []
                    , Html.Styled.video
                        [ src "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/Scenario2.mp4"
                        , Html.Styled.Events.onClick
                            (SustancePicked coor
                                "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/Scenario2.mp4"
                                Video
                            )
                        , Html.Styled.Attributes.controls True
                        ]
                        []
                    , Html.Styled.video
                        [ src "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/Scenario1.mp4"
                        , Html.Styled.Events.onClick
                            (SustancePicked coor
                                "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/Scenario1.mp4"
                                Video
                            )
                        , Html.Styled.Attributes.controls True
                        ]
                        []
                    , Html.Styled.video
                        [ src "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/Scenario2.mp4"
                        , Html.Styled.Events.onClick
                            (SustancePicked coor
                                "https://s3.ca-central-1.amazonaws.com/unimasoft-web/LucasDidactique/img/media/Scenario2.mp4"
                                Video
                            )
                        , Html.Styled.Attributes.controls True
                        ]
                        []
                    ]
                ]

        NothingSoFar ->
            case model.draggedWidget of
                Maybe.Nothing ->
                    case model.selectedWidget of
                        Maybe.Nothing ->
                            case model.rectSelect of
                                Maybe.Nothing ->
                                    Html.Styled.div []
                                        [ section [] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                        , text "Select a Widget or create a selection"
                                        , Html.Styled.section
                                            [ onMouseDown StartSelection
                                            , Html.Styled.Attributes.css
                                                [ Css.height (Css.vh 80.0)
                                                , Css.width (Css.vw 100.0)
                                                ]
                                            ]
                                            (List.map affiche model.completedWidgets
                                                ++ List.concatMap askQuestion model.groupWidgets
                                            )
                                        ]

                                Maybe.Just rect ->
                                    Html.Styled.div []
                                        [ section [] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                        , text "Move to create a selection"
                                        , section
                                            [ onMouseMove UpdateSelection
                                            , onMouseUp ConfirmSelection
                                            , Html.Styled.Attributes.css
                                                [ Css.height (Css.vh 80.0)
                                                , Css.width (Css.vw 100.0)
                                                , Css.position Css.relative
                                                , Css.zIndex (Css.int 3)
                                                ]
                                            ]
                                            (let
                                                ( selected, notSelected ) =
                                                    model.completedWidgets |> List.partition (\a -> selectedVisual ( rect, a ))
                                             in
                                             List.map affiche notSelected
                                                ++ List.map illumine selected
                                                ++ List.concatMap askQuestion model.groupWidgets
                                            )
                                        , Html.Styled.div
                                            [ Html.Styled.Attributes.css
                                                [ Css.borderWidth (Css.em 2)
                                                , Css.backgroundColor Colors.orange
                                                , Css.position Css.fixed
                                                , Css.top (Css.px rect.point1.clientY)
                                                , Css.left (Css.px rect.point1.clientX)
                                                , Css.width (Css.px (rect.point2.clientX - rect.point1.clientX))
                                                , Css.height (Css.px (rect.point2.clientY - rect.point1.clientY))
                                                , Css.opacity (Css.num 0.2)
                                                , Css.zIndex (Css.int 0)
                                                ]
                                            ]
                                            []
                                        ]

                        Maybe.Just selWidgets ->
                            Html.Styled.div []
                                [ section [] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                , text "Selection confirmed"
                                , section
                                    [ onMouseDown StartSelection
                                    , Html.Styled.Attributes.css [ Css.height (Css.vh 80.0), Css.width (Css.vw 100.0) ]
                                    ]
                                    (List.map
                                        affiche
                                        (List.filter (\a -> List.notMember a selWidgets) model.completedWidgets)
                                        ++ List.map illumine selWidgets
                                        ++ List.concatMap askQuestion model.groupWidgets
                                    )
                                ]

                Maybe.Just widget ->
                    case widget.category of
                        Visual ->
                            Html.Styled.div []
                                [ section [] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                , Html.Styled.section
                                    [ onDrop DropWidgetOnCanvas
                                    , onWithOptions "dragover"
                                        { stopPropagation = True, preventDefault = True }
                                        (Decode.succeed RienFaire)
                                    , Html.Styled.Attributes.css
                                        [ Css.height (Css.vh 80.0), Css.width (Css.vw 100.0), Css.backgroundColor Colors.blue ]
                                    ]
                                    (List.map affiche model.completedWidgets
                                        ++ List.concatMap askQuestion model.groupWidgets
                                        ++ [ text "Test Widget" ]
                                    )
                                , text "deposer ici"
                                ]

                        Tool _ ->
                            Html.Styled.div []
                                [ section [] (List.map (\a -> plansWidget ( model, a )) model.widgetBlueprints)
                                , Html.Styled.section
                                    [ Html.Styled.Attributes.css
                                        [ Css.height (Css.vh 80.0), Css.width (Css.vw 100.0) ]
                                    ]
                                    (List.map prepareWidget model.completedWidgets
                                        ++ List.concatMap askQuestion model.groupWidgets
                                        ++ [ text "Test Widget" ]
                                    )
                                , Html.Styled.img
                                    [ onLoad UpdatePosition
                                    , src widget.displayUrl
                                    , Html.Styled.Attributes.css
                                        [ Css.opacity (Css.num 0) ]
                                    ]
                                    []
                                ]

                        Group _ ->
                            text ""
