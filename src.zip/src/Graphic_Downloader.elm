module Graphic_Downloader exposing (GraphicData, GraphicList, Page, addNewPage, changeClickAction, decodeGraphicList, initGraphic, nextGraphicList, obtainGraphicList, showImage, showImageList, showVideo, showVideoList, updateGraphicData)

import Element as L exposing (..)
import Element.Background as Bg exposing (..)
import Element.Border as Border
import Element.Events exposing (onClick)
import Element.Input as L
import Html exposing (video)
import Html.Attributes as H exposing (controls, height, src, width)
import Http
import Json.Decode as Decode
import List.Extra as List
import Url.Builder as Builder exposing (..)


type alias GraphicData dataMsg =
    { suiteToken : Maybe String
    , graphicPages : Maybe (List Page)
    , chooseNextPage : Maybe dataMsg
    , currentPage : Int
    , choosePreviousPage : Maybe dataMsg
    , selectGraphicAction : String -> dataMsg
    , nextMsg : dataMsg
    , prevMsg : dataMsg
    , userId : String
    , graphicType : String
    , filePrefix : String
    }


initGraphic : String -> String -> (String -> dataMsg) -> dataMsg -> dataMsg -> GraphicData dataMsg
initGraphic userInfo graphicInfo clickAction nextPage prevPage =
    { suiteToken = Nothing
    , graphicPages = Nothing
    , chooseNextPage = Nothing
    , currentPage = 0
    , choosePreviousPage = Nothing
    , selectGraphicAction = clickAction
    , nextMsg = nextPage
    , prevMsg = prevPage
    , userId = userInfo
    , graphicType = graphicInfo
    , filePrefix = ""
    }


type alias GraphicList =
    { prefix : String
    , suiteToken : Maybe String
    , graphics : Page
    }


type alias Page =
    List String


decodeGraphicList : Decode.Decoder GraphicList
decodeGraphicList =
    Decode.map3 GraphicList
        (Decode.field "bucketName" Decode.string)
        (Decode.field "nextContinuationToken" (Decode.nullable Decode.string))
        (Decode.field "objectSummaries" (Decode.list (Decode.field "key" Decode.string)))


changeClickAction : GraphicData dataMsg -> (String -> dataMsg) -> GraphicData dataMsg
changeClickAction dataMsgGraphicData clickAction =
    { dataMsgGraphicData | selectGraphicAction = clickAction }


obtainGraphicList : GraphicData dataMsg -> (Result Http.Error GraphicList -> dataMsg) -> Cmd dataMsg
obtainGraphicList graphicData msgGet =
    let
        pagePath =
            Builder.absolute [ "downloadGraphicPage" ]
                [ Builder.string "keyName" (graphicData.userId ++ "/" ++ graphicData.graphicType) ]
    in
    Http.get
        { url = pagePath
        , expect = Http.expectJson msgGet decodeGraphicList
        }


nextGraphicList : GraphicData dataMsg -> (Result Http.Error GraphicList -> dataMsg) -> Cmd dataMsg
nextGraphicList graphicData msgFun =
    case graphicData.suiteToken of
        Maybe.Just token ->
            let
                pagePath =
                    Builder.absolute [ "downloadGraphicPage" ]
                        [ Builder.string "keyName"
                            (graphicData.userId
                                ++ "/"
                                ++ graphicData.graphicType
                            )
                        , Builder.string
                            "tokenSuite"
                            token
                        ]
            in
            Http.get
                { url = pagePath
                , expect = Http.expectJson msgFun decodeGraphicList
                }

        Maybe.Nothing ->
            let
                pagePath =
                    Builder.absolute [ "downloadGraphicPage" ]
                        [ Builder.string "keyName"
                            (graphicData.userId
                                ++ "/"
                                ++ graphicData.graphicType
                            )
                        ]
            in
            Http.get
                { url = pagePath
                , expect = Http.expectJson msgFun decodeGraphicList
                }


showImageList : List (L.Attribute dataMsg) -> GraphicData dataMsg -> Element dataMsg
showImageList msgAttributeLList graphicData =
    case graphicData.graphicPages of
        Maybe.Just pages ->
            case List.getAt graphicData.currentPage pages of
                Maybe.Just graphPages ->
                    column [ spacing 10 ]
                        [ wrappedRow ([ padding 10, spacing 5 ] ++ msgAttributeLList)
                            (List.map
                                (\a ->
                                    showImage (graphicData.filePrefix ++ a) graphicData.selectGraphicAction
                                )
                                graphPages
                            )
                        , row
                            [ spaceEvenly, L.width fill ]
                            [ L.button [ alignLeft ]
                                { onPress = graphicData.choosePreviousPage, label = text "Previous Page" }
                            , L.button
                                [ alignRight ]
                                { onPress = graphicData.chooseNextPage, label = text "Next Page" }
                            ]
                        ]

                Maybe.Nothing ->
                    text ("Error : Wrong page #" ++ String.fromInt graphicData.currentPage)

        Maybe.Nothing ->
            text "Error : No pages"


showImage : String -> (String -> dataMsg) -> Element dataMsg
showImage imgUrl clickAction =
    L.image
        [ Bg.color (rgb255 55 55 55), Border.width 2, L.width (px 200), L.height (px 200), onClick (clickAction imgUrl) ]
        { src = imgUrl, description = "Image unavailable" }


showVideoList : List (L.Attribute dataMsg) -> GraphicData dataMsg -> Element dataMsg
showVideoList msgAttributeLList graphicData =
    case graphicData.graphicPages of
        Maybe.Just pages ->
            case List.getAt graphicData.currentPage pages of
                Maybe.Just graphPages ->
                    column [ spacing 10 ]
                        [ wrappedRow ([ padding 10, spacing 5 ] ++ msgAttributeLList)
                            (List.map
                                (\a ->
                                    showVideo (graphicData.filePrefix ++ a) graphicData.selectGraphicAction
                                )
                                graphPages
                            )
                        , row
                            [ spaceEvenly, L.width fill ]
                            [ L.button [ alignLeft ]
                                { onPress = graphicData.choosePreviousPage, label = text "Previous Page" }
                            , L.button
                                [ alignRight ]
                                { onPress = graphicData.chooseNextPage, label = text "Next Page" }
                            ]
                        ]

                Maybe.Nothing ->
                    text ("Error : Wrong page #" ++ String.fromInt graphicData.currentPage)

        Maybe.Nothing ->
            text "Error : No pages"


showVideo : String -> (String -> dataMsg) -> Element dataMsg
showVideo videoLink msgAction =
    el [ onClick (msgAction videoLink) ] (L.html (video [ H.width 200, H.height 200, src videoLink, controls True ] []))


updateGraphicData : GraphicData dataMsg -> GraphicData dataMsg
updateGraphicData graphicData =
    case graphicData.graphicPages of
        Maybe.Just lesPages ->
            case graphicData.suiteToken of
                Maybe.Nothing ->
                    { graphicData
                        | chooseNextPage =
                            if graphicData.currentPage < List.length lesPages then
                                Maybe.Just graphicData.nextMsg

                            else
                                Maybe.Nothing
                        , choosePreviousPage =
                            if graphicData.currentPage > 0 then
                                Maybe.Just graphicData.prevMsg

                            else
                                Maybe.Nothing
                    }

                Maybe.Just _ ->
                    { graphicData
                        | chooseNextPage =
                            Maybe.Just graphicData.nextMsg
                        , choosePreviousPage =
                            if graphicData.currentPage > 0 then
                                Maybe.Just graphicData.prevMsg

                            else
                                Maybe.Nothing
                    }

        Maybe.Nothing ->
            graphicData


addNewPage : GraphicList -> GraphicData dataMsg -> GraphicData dataMsg
addNewPage graphicList graphicData =
    case graphicData.graphicPages of
        Maybe.Just lesPages ->
            { graphicData
                | graphicPages = Maybe.Just (lesPages ++ [ graphicList.graphics ])
                , suiteToken = graphicList.suiteToken
                , filePrefix = graphicList.prefix
            }

        Maybe.Nothing ->
            { graphicData
                | graphicPages = Maybe.Just [ graphicList.graphics ]
                , suiteToken = graphicList.suiteToken
                , filePrefix = graphicList.prefix
            }
