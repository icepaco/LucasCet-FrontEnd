module Main exposing (Model(..), Msg(..), MsgInfo, UserInfo, UserMsg, bouton, decodeMsgs, decodeUserId, getMsgContent, getMsgs, init, loginAndGetUser, main, subscriptions, update, view, viewMsgs)

import ChatCreator as CMess
import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (..)
import Http
import Json.Decode as Decode


main : Program Never Model Msg
main =
    Html.program
        { init = init
        , view = view
        , update = update
        , subscriptions = subscriptions
        }



-- Model


type alias UserInfo =
    { userId : String
    , login : String
    }


type alias UserMsg =
    { userId : String
    , msgUrl : String
    , msgId : String
    }


type alias MsgInfo =
    { info : UserInfo
    , lstMsgs : List UserMsg
    , selection : UserMsg
    , display : String
    }


type Model
    = InitMsg
    | MsgUI MsgInfo


decodeMsgs : Decode.Decoder (List UserMsg)
decodeMsgs =
    Decode.list
        (Decode.map3
            UserMsg
            (Decode.field "userId" Decode.string)
            (Decode.field "userUrl" Decode.string)
            (Decode.field "msgId" Decode.string)
        )



-- Init


init : ( Model, Cmd Msg )
init =
    ( InitMsg
    , loginAndGetUser
    )


decodeUserId : Decode.Decoder UserInfo
decodeUserId =
    Decode.map2 UserInfo (Decode.field "userId" Decode.string) (Decode.field "login" Decode.string)


loginAndGetUser : Cmd Msg
loginAndGetUser =
    let
        url =
            "/user"
    in
    Http.send LoginAndGetUser (Http.get url decodeUserId)



-- Update


type Msg
    = LoginAndGetUser (Result Http.Error UserInfo)
    | GetUserMsgs (Result Http.Error (List UserMsg))
    | MsgSelection UserMsg
    | GetMsgContent (Result Http.Error String)


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        LoginAndGetUser (Result.Ok userInfo) ->
            case model of
                InitMsg ->
                    ( model, Cmd.none )

                MsgUI msgInfo ->
                    ( MsgUI { msgInfo | info = userInfo }, getMsgs userInfo.userId )

        LoginAndGetUser (Result.Err _) ->
            ( model, Cmd.none )

        GetUserMsgs (Result.Ok userMsgs) ->
            case model of
                InitMsg ->
                    ( model, Cmd.none )

                MsgUI msgInfo ->
                    ( MsgUI { msgInfo | lstMsgs = userMsgs }, Cmd.none )

        GetUserMsgs (Result.Err _) ->
            ( model, Cmd.none )

        MsgSelection userMsg ->
            case model of
                InitMsg ->
                    ( model, Cmd.none )

                MsgUI msgInfo ->
                    ( MsgUI { msgInfo | selection = userMsg }, Cmd.none )

        GetMsgContent (Result.Ok content) ->
            case model of
                InitMsg ->
                    ( model, Cmd.none )

                MsgUI msgInfo ->
                    ( MsgUI { msgInfo | display = content }, Cmd.none )

        GetMsgContent (Result.Err _) ->
            ( model, Cmd.none )


getMsgs : String -> Cmd Msg
getMsgs userId =
    let
        url =
            "/downloadMsgs" ++ "?userId=" ++ userId
    in
    Http.send GetUserMsgs (Http.get url decodeMsgs)


getMsgContent : String -> Cmd Msg
getMsgContent msgId =
    let
        url =
            "/downloadMsgContent" ++ "?msgId=" ++ msgId
    in
    Http.send GetMsgContent (Http.get url Decode.string)



-- view


view : Model -> Html Msg
view model =
    div []
        [ case model of
            InitMsg ->
                div [ id "authentification" ]
                    [ h2 [] [ text "Logging" ]
                    , a [ href "/login/facebook" ] [ text "Click for facebook" ]
                    , br [] []
                    ]

            MsgUI info ->
                div []
                    [ section [ id info.info.userId, class "userDisplay" ]
                        [ text info.info.login ]
                    , section
                        [ class "msgList" ]
                        [ viewMsgs info.lstMsgs
                        ]
                    , div
                        [ class "msgHeader" ]
                        [ img [ src info.selection.msgUrl ] []
                        ]
                    , section
                        [ class "msgContent" ]
                        [ iframe [ class "msgContent_frame", src info.display ] [] ]
                    ]
        ]


viewMsgs : List UserMsg -> Html Msg
viewMsgs userMsgs =
    fieldset [] (List.map bouton userMsgs)


bouton : UserMsg -> Html Msg
bouton userMsg =
    button [ src userMsg.msgUrl, onClick (MsgSelection userMsg) ] []



-- Subscription


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.none
