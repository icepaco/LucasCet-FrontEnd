module Graphic_Element exposing (CanvasSubstance(..), ElementEdited, addSubstance, ajouterTitre, createSubstancePotentielle, creerSubstanceMotrice, creerSubstanceRelation, definirMedia, displayCanvas, displayCanvasImage, displayCanvasSubstance, expedieSubstance, initElement, resetSubstance)

import Browser exposing (Document)
import Browser.Dom as DOM exposing (Error, Viewport, getViewport)
import Dict exposing (Dict)
import Element as L exposing (..)
import Element.Background as Bg exposing (color, gradient)
import Element.Border as Border exposing (..)
import Element.Events as Events exposing (..)
import Element.Input as Input exposing (..)
import Graphic_Downloader exposing (GraphicList)
import Html exposing (video)
import Html.Attributes as H exposing (autoplay, controls, height, id, src, width)
import Http
import Json.Decode as Decode
import Json.Encode as Encode
import List.Extra as List
import Maybe.Extra as Maybe
import SubstancePlayer as Sub exposing (..)
import Task exposing (attempt)
import Tuple exposing (first, second)
import Url exposing (..)
import Url.Builder as Builder



-- eleMsgAppReader


type alias CanvasPotentiel =
    { userId : String
    , imageUrl : Maybe String
    , title : Maybe String
    }


type alias CanvasMotrice =
    { userId : String
    , videoUrl : Maybe String
    , title : Maybe String
    , principale : Maybe Substance
    }


type alias CanvasRelation =
    { userId : String
    , videoUrl : Maybe String
    , title : Maybe String
    , premiere : Maybe Substance
    , seconde : Maybe Substance
    }


type CanvasSubstance
    = Vide
    | Potentiel CanvasPotentiel
    | Motrice CanvasMotrice
    | Relationnelle CanvasRelation


type alias ElementEdited eleMsg =
    { activeCanvas : CanvasSubstance
    , createPotential : eleMsg
    , createMotrice : eleMsg
    , createRelation : eleMsg
    , selectImage : eleMsg
    , selectVideo : eleMsg
    , enterTitle : String -> eleMsg
    , selectSubstance : eleMsg
    , deploySubstance : CanvasSubstance -> eleMsg
    , recordSubstance : eleMsg
    , userId : String
    }



-- Processing


initElement : eleMsg -> eleMsg -> eleMsg -> eleMsg -> eleMsg -> (String -> eleMsg) -> eleMsg -> (CanvasSubstance -> eleMsg) -> eleMsg -> String -> ElementEdited eleMsg
initElement createPotMsg createMotMsg createRelMsg chooseImg chooseVid setTitle chooseSubstance deploySelectedSubstance sendSubstance userIdValue =
    { activeCanvas = Vide
    , createPotential = createPotMsg
    , createMotrice = createMotMsg
    , createRelation = createRelMsg
    , selectImage = chooseImg
    , selectVideo = chooseVid
    , enterTitle = setTitle
    , selectSubstance = chooseSubstance
    , deploySubstance = deploySelectedSubstance
    , recordSubstance = sendSubstance
    , userId = userIdValue
    }



-- BACKEND CALLS


expedieSubstance : ElementEdited eleMsg -> (Result Http.Error () -> eleMsg) -> Cmd eleMsg
expedieSubstance eleMsgElementEdited retourAppel =
    case eleMsgElementEdited.activeCanvas of
        Vide ->
            Cmd.none

        Potentiel potSub ->
            Http.post
                { url = "createPotentielle"
                , body = Http.jsonBody (encodePotentielle potSub)
                , expect = Http.expectWhatever retourAppel
                }

        Motrice motSub ->
            Http.post
                { url = "createMotrice"
                , body = Http.jsonBody (encodeMotrice motSub)
                , expect = Http.expectWhatever retourAppel
                }

        Relationnelle relSub ->
            Http.post
                { url = "createRelation"
                , body = Http.jsonBody (encodeRelation relSub)
                , expect = Http.expectWhatever retourAppel
                }



-- updateViewport : AppReader eleMsg -> Viewport -> AppReader eleMsg
-- updateViewport eleMsgAppReader viewPort =
--     { eleMsgAppReader | dimension = ( viewPort.viewport.width, viewPort.viewport.height ) }


encodePotentielle : CanvasPotentiel -> Encode.Value
encodePotentielle v =
    Encode.object
        [ ( "UserID", Encode.string v.userId )
        , ( "Image"
          , case v.imageUrl of
                Just img ->
                    Encode.string img

                Nothing ->
                    Encode.null
          )
        , ( "Name"
          , case v.title of
                Just title ->
                    Encode.string title

                Nothing ->
                    Encode.null
          )
        ]


encodeMotrice : CanvasMotrice -> Encode.Value
encodeMotrice v =
    Encode.object
        [ ( "UserID", Encode.string v.userId )
        , ( "Video"
          , case v.videoUrl of
                Just vid ->
                    Encode.string vid

                Nothing ->
                    Encode.null
          )
        , ( "Name"
          , case v.title of
                Just titre ->
                    Encode.string titre

                Nothing ->
                    Encode.null
          )
        , ( "Principale"
          , case v.principale of
                Just princ ->
                    case princ of
                        Relation rel ->
                            Encode.string rel.subId

                        Dynamic dyna ->
                            Encode.string dyna.subId

                        Potential pot ->
                            Encode.string pot.subId

                Nothing ->
                    Encode.null
          )
        ]


encodeRelation : CanvasRelation -> Encode.Value
encodeRelation v =
    Encode.object
        [ ( "UserId", Encode.string v.userId )
        , ( "Video"
          , case v.videoUrl of
                Just url ->
                    Encode.string url

                Nothing ->
                    Encode.null
          )
        , ( "Name"
          , case v.title of
                Just title ->
                    Encode.string title

                Nothing ->
                    Encode.null
          )
        , ( "Premiere"
          , case v.premiere of
                Just substance ->
                    case substance of
                        Relation rel ->
                            Encode.string rel.subId

                        Dynamic dyna ->
                            Encode.string dyna.subId

                        Potential pot ->
                            Encode.string pot.subId

                Nothing ->
                    Encode.null
          )
        , ( "Seconde"
          , case v.seconde of
                Just secondeSubstance ->
                    case secondeSubstance of
                        Relation rel ->
                            Encode.string rel.subId

                        Dynamic dyna ->
                            Encode.string dyna.subId

                        Potential pot ->
                            Encode.string pot.subId

                Nothing ->
                    Encode.null
          )
        ]


encodeListSubstance : List Substance -> Encode.Value
encodeListSubstance v =
    Encode.list
        (\substance ->
            case substance of
                Relation rel ->
                    Encode.string rel.subId

                Dynamic dyna ->
                    Encode.string dyna.subId

                Potential pot ->
                    Encode.string pot.subId
        )
        v


resetSubstance : ElementEdited eleMsg -> ElementEdited eleMsg
resetSubstance eleMsgElementEdited =
    { eleMsgElementEdited | activeCanvas = Vide }


createSubstancePotentielle : ElementEdited eleMsg -> ElementEdited eleMsg
createSubstancePotentielle eleMsgElementEdited =
    { eleMsgElementEdited
        | activeCanvas =
            Potentiel
                { userId = eleMsgElementEdited.userId
                , imageUrl = Nothing
                , title = Nothing
                }
    }


creerSubstanceMotrice : ElementEdited eleMsg -> ElementEdited eleMsg
creerSubstanceMotrice eleMsgElementEdited =
    { eleMsgElementEdited
        | activeCanvas =
            Motrice
                { userId = eleMsgElementEdited.userId
                , videoUrl = Nothing
                , title = Nothing
                , principale = Nothing
                }
    }


creerSubstanceRelation : ElementEdited eleMsg -> ElementEdited eleMsg
creerSubstanceRelation eleMsgElementEdited =
    { eleMsgElementEdited
        | activeCanvas =
            Relationnelle
                { userId = eleMsgElementEdited.userId
                , videoUrl = Nothing
                , title = Nothing
                , premiere = Nothing
                , seconde = Nothing
                }
    }


ajouterTitre : ElementEdited eleMsg -> String -> ElementEdited eleMsg
ajouterTitre eleMsgElementEdited titre =
    case eleMsgElementEdited.activeCanvas of
        Vide ->
            eleMsgElementEdited

        Potentiel potCan ->
            { eleMsgElementEdited
                | activeCanvas =
                    Potentiel
                        { userId = eleMsgElementEdited.userId
                        , imageUrl = potCan.imageUrl
                        , title =
                            Maybe.Just
                                titre
                        }
            }

        Motrice motCan ->
            { eleMsgElementEdited
                | activeCanvas =
                    Motrice
                        { motCan | title = Maybe.Just titre }
            }

        Relationnelle relCan ->
            { eleMsgElementEdited
                | activeCanvas =
                    Relationnelle
                        { relCan | title = Maybe.Just titre }
            }


definirMedia : ElementEdited eleMsg -> String -> ElementEdited eleMsg
definirMedia eleMsgElementEdited mediaUrl =
    case eleMsgElementEdited.activeCanvas of
        Vide ->
            eleMsgElementEdited

        Potentiel potCan ->
            { eleMsgElementEdited
                | activeCanvas =
                    Potentiel
                        { userId = eleMsgElementEdited.userId
                        , imageUrl =
                            Maybe.Just
                                mediaUrl
                        , title = potCan.title
                        }
            }

        Motrice motCan ->
            { eleMsgElementEdited | activeCanvas = Motrice { motCan | videoUrl = Maybe.Just mediaUrl } }

        Relationnelle relCan ->
            { eleMsgElementEdited | activeCanvas = Relationnelle { relCan | videoUrl = Maybe.Just mediaUrl } }


addSubstance : ElementEdited eleMsg -> Substance -> ElementEdited eleMsg
addSubstance eleMsgElementEdited substance =
    case eleMsgElementEdited.activeCanvas of
        Vide ->
            eleMsgElementEdited

        Potentiel _ ->
            eleMsgElementEdited

        Motrice motCan ->
            { eleMsgElementEdited | activeCanvas = Motrice { motCan | principale = Maybe.Just substance } }

        Relationnelle relCan ->
            if Maybe.isNothing relCan.premiere then
                { eleMsgElementEdited | activeCanvas = Relationnelle { relCan | premiere = Maybe.Just substance } }

            else
                { eleMsgElementEdited | activeCanvas = Relationnelle { relCan | seconde = Maybe.Just substance } }


afficherCrumb : (SubstanceDisplay -> eleMsg) -> SubstanceDisplay -> Element eleMsg
afficherCrumb subSel substance =
    case substance of
        RelationDisplay substanceRelation ->
            paragraph [ onClick (subSel substance) ] [ L.text (substanceRelation.name ++ "->") ]

        DynamicDisplay substanceDynamic ->
            paragraph [ onClick (subSel substance) ] [ L.text (substanceDynamic.name ++ "->") ]

        PotentialDisplay substancePotential ->
            paragraph [ onClick (subSel substance) ] [ L.text (substancePotential.name ++ "->") ]

        Practice _ ->
            paragraph [] [ L.text "Practice" ]

        Erreur txtErr ->
            paragraph [] [ L.text txtErr ]


displayCanvasVideo : String -> eleMsg -> Element eleMsg
displayCanvasVideo vidUrl selectNewVideo =
    el
        [ Bg.color (rgb255 0 0 0)
        , padding 1
        , centerX
        , centerY
        , onClick selectNewVideo
        ]
        (el
            [ centerX
            , centerY
            ]
            (L.html
                (video
                    [ src vidUrl
                    , controls True
                    , H.width 120
                    , H.height 120
                    ]
                    []
                )
            )
        )


displayCanvasSubstance : Substance -> eleMsg -> ( Float, Float ) -> Element eleMsg
displayCanvasSubstance substance subClicker dimension =
    case substance of
        Relation substanceRelation ->
            column
                (Sub.columnAttribute
                    ++ [ onClick subClicker, centerX, centerY ]
                )
                [ Sub.decorateVideo substanceRelation.media (round (first dimension * 0.6)) (round (second dimension * 0.6))
                , paragraph [] [ L.text substanceRelation.name ]
                ]

        Dynamic substanceDynamic ->
            column
                (Sub.columnAttribute
                    ++ [ onClick subClicker, centerX, centerY ]
                )
                [ Sub.decorateVideo substanceDynamic.video (round (first dimension * 0.6)) (round (second dimension * 0.6))
                , paragraph [] [ L.text substanceDynamic.name ]
                ]

        Potential substancePotential ->
            displayCanvasImage substancePotential.image subClicker


displayInertCanvasSubstance : Substance -> ( Float, Float ) -> Element eleMsg
displayInertCanvasSubstance substance dimension =
    case substance of
        Relation substanceRelation ->
            column
                (Sub.columnAttribute
                    ++ [ centerX, centerY ]
                )
                [ Sub.decorateVideo substanceRelation.media (round (first dimension * 0.6)) (round (second dimension * 0.6))
                , paragraph [] [ L.text substanceRelation.name ]
                ]

        Dynamic substanceDynamic ->
            column
                (Sub.columnAttribute
                    ++ [ centerX, centerY ]
                )
                [ Sub.decorateVideo substanceDynamic.video (round (first dimension * 0.6)) (round (second dimension * 0.6))
                , paragraph [] [ L.text substanceDynamic.name ]
                ]

        Potential substancePotential ->
            image [ centerX, centerY ] { src = substancePotential.image, description = "Potential" }


displayCanvasImage : String -> eleMsg -> Element eleMsg
displayCanvasImage url inputImg =
    image
        [ onClick inputImg
        , centerX
        , centerY
        , L.height (fill |> maximum 400)
        , L.width (fill |> maximum 400)
        ]
        { src = url
        , description = "Une image"
        }


displayCanvasElement : Maybe eleMsg -> String -> (String -> eleMsg) -> Element eleMsg -> Maybe Substance -> Maybe Substance -> eleMsg -> Element eleMsg
displayCanvasElement canvasRdy title inputTitle displayMedia substance1 substance2 inputSubstance =
    case canvasRdy of
        Just eleMsg ->
            case substance1 of
                Maybe.Nothing ->
                    column [ Border.innerGlow (L.rgb255 105 55 200) 5, L.width fill, L.height fill, padding 25, spaceEvenly ]
                        [ Input.text [ centerX, centerY ]
                            { onChange = inputTitle
                            , text = title
                            , placeholder = Maybe.Just (placeholder [] (L.text "Titre Substance:"))
                            , label = Input.labelAbove [] (L.text title)
                            }
                        , L.text "Selectionner un élément média"
                        , displayMedia
                        , button [ Border.innerGlow (L.rgb255 225 155 2) 2, centerX, centerY ]
                            { onPress = canvasRdy
                            , label = L.text "Appuyer pour enregistrer"
                            }
                        ]

                Maybe.Just sub2Display ->
                    case substance2 of
                        Maybe.Just secondSub2Display ->
                            column [ Border.innerGlow (L.rgb255 105 55 200) 5, L.width fill, L.height fill, padding 25, spaceEvenly ]
                                [ Input.text [ centerX, centerY ]
                                    { onChange = inputTitle
                                    , text = title
                                    , placeholder = Maybe.Just (placeholder [] (L.text "Titre Substance:"))
                                    , label = Input.labelAbove [] (L.text title)
                                    }
                                , L.text "Selectionner un élément média"
                                , displayMedia
                                , L.text "Choisir une substance"
                                , displayCanvasSubstance sub2Display inputSubstance ( 200, 200 )
                                , L.text "Choisir une substance"
                                , displayCanvasSubstance secondSub2Display inputSubstance ( 200, 200 )
                                , button [ Border.innerGlow (L.rgb255 225 155 2) 2, centerX, centerY ]
                                    { onPress = canvasRdy
                                    , label = L.text "Appuyer pour enregistrer"
                                    }
                                ]

                        Maybe.Nothing ->
                            column [ Border.innerGlow (L.rgb255 105 55 200) 5, L.width fill, L.height fill, padding 25, spaceEvenly ]
                                [ Input.text [ centerX, centerY ]
                                    { onChange = inputTitle
                                    , text = title
                                    , placeholder = Maybe.Just (placeholder [] (L.text "Titre Substance:"))
                                    , label = Input.labelAbove [] (L.text title)
                                    }
                                , L.text "Selectionner un élément média"
                                , displayMedia
                                , L.text "Choisir une substance"
                                , displayCanvasSubstance sub2Display inputSubstance ( 200, 200 )
                                , button [ Border.innerGlow (L.rgb255 225 155 2) 2, centerX, centerY ]
                                    { onPress = canvasRdy
                                    , label = L.text "Appuyer pour enregistrer"
                                    }
                                ]

        Maybe.Nothing ->
            case substance1 of
                Maybe.Nothing ->
                    column [ L.width fill, L.height fill, padding 25, spaceEvenly ]
                        [ Input.text [ centerX, centerY ]
                            { onChange = inputTitle
                            , text = title
                            , placeholder = Maybe.Just (placeholder [] (L.text "Titre Substance:"))
                            , label = Input.labelAbove [] (L.text title)
                            }
                        , L.text "Selectionner un élément média"
                        , displayMedia
                        ]

                Maybe.Just sub2Display ->
                    case substance2 of
                        Maybe.Just secondSub2Display ->
                            column [ L.width fill, L.height fill, padding 25, spaceEvenly ]
                                [ Input.text [ centerX, centerY ]
                                    { onChange = inputTitle
                                    , text = title
                                    , placeholder = Maybe.Just (placeholder [] (L.text "Titre Substance:"))
                                    , label = Input.labelAbove [] (L.text title)
                                    }
                                , L.text "Selectionner un élément média"
                                , displayMedia
                                , L.text "Choisir une substance"
                                , displayCanvasSubstance sub2Display inputSubstance ( 200, 200 )
                                , L.text "Choisir une substance"
                                , displayCanvasSubstance secondSub2Display inputSubstance ( 200, 200 )
                                ]

                        Maybe.Nothing ->
                            column [ L.width fill, L.height fill, padding 25, spaceEvenly ]
                                [ Input.text [ centerX, centerY ]
                                    { onChange = inputTitle
                                    , text = title
                                    , placeholder = Maybe.Just (placeholder [] (L.text "Titre Substance:"))
                                    , label = Input.labelAbove [] (L.text title)
                                    }
                                , L.text "Selectionner un élément média"
                                , displayMedia
                                , L.text "Choisir une substance"
                                , displayCanvasSubstance sub2Display inputSubstance ( 200, 200 )
                                ]


displayCanvas : ElementEdited eleMsg -> Element eleMsg
displayCanvas elmMsgElementEdited =
    case elmMsgElementEdited.activeCanvas of
        Vide ->
            row [ padding 25, spaceEvenly, L.width fill, L.height fill ]
                [ button
                    [ innerGlow (rgb255 255 200 150) 1
                    ]
                    { label =
                        column []
                            [ image []
                                { src = "/img/potentielle.jpg"
                                , description = "Créer uneSub.SubstancePotentielle"
                                }
                            , L.text "Créer uneSub.SubstancePotentielle"
                            ]
                    , onPress = Just elmMsgElementEdited.createPotential
                    }
                , button
                    [ innerGlow (rgb255 255 200 150) 1
                    ]
                    { label =
                        column []
                            [ image []
                                { src = "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRj9FIn2dMmiEtweLMJu0oF2JgEkunxGFELLc3upkVAB3Y_alzn"
                                , description = "Créer uneSub.SubstanceMotrice"
                                }
                            , L.text "Créer uneSub.SubstanceMotrice"
                            ]
                    , onPress = Just elmMsgElementEdited.createMotrice
                    }
                , button
                    [ innerGlow (rgb255 255 200 150) 1
                    ]
                    { label =
                        column []
                            [ image []
                                { src = "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                , description = "Créer uneSub.SubstanceRelation"
                                }
                            , L.text "Créer uneSub.SubstanceRelation"
                            ]
                    , onPress = Just elmMsgElementEdited.createRelation
                    }
                ]

        Potentiel potCan ->
            if Maybe.isJust potCan.title && Maybe.isJust potCan.imageUrl then
                displayCanvasElement
                    (Maybe.Just
                        elmMsgElementEdited.recordSubstance
                    )
                    (Maybe.withDefault
                        "Substance Potentielle"
                        potCan.title
                    )
                    elmMsgElementEdited.enterTitle
                    (displayCanvasImage
                        (Maybe.withDefault
                            "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                            potCan.imageUrl
                        )
                        elmMsgElementEdited.selectImage
                    )
                    Maybe.Nothing
                    Maybe.Nothing
                    elmMsgElementEdited.selectSubstance

            else
                displayCanvasElement Maybe.Nothing
                    (Maybe.withDefault
                        "Substance Potentielle"
                        potCan.title
                    )
                    elmMsgElementEdited.enterTitle
                    (displayCanvasImage
                        (Maybe.withDefault
                            "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                            potCan.imageUrl
                        )
                        elmMsgElementEdited.selectImage
                    )
                    Maybe.Nothing
                    Maybe.Nothing
                    elmMsgElementEdited.selectSubstance

        Motrice motCan ->
            if Maybe.isJust motCan.videoUrl && Maybe.isJust motCan.title && Maybe.isJust motCan.principale then
                displayCanvasElement
                    (Maybe.Just
                        elmMsgElementEdited.recordSubstance
                    )
                    (Maybe.withDefault
                        "Substance Motrice"
                        motCan.title
                    )
                    elmMsgElementEdited.enterTitle
                    (displayCanvasVideo
                        (Maybe.withDefault
                            "img/vidClick.mp4"
                            motCan.videoUrl
                        )
                        elmMsgElementEdited.selectVideo
                    )
                    (Maybe.Just
                        (Maybe.withDefault
                            (Potential
                                (SubstancePotential
                                    "0"
                                    "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                    "Nouvelle Substance"
                                )
                            )
                            motCan.principale
                        )
                    )
                    Maybe.Nothing
                    elmMsgElementEdited.selectSubstance

            else
                displayCanvasElement Maybe.Nothing
                    (Maybe.withDefault
                        "Substance Motrice"
                        motCan.title
                    )
                    elmMsgElementEdited.enterTitle
                    (displayCanvasVideo
                        (Maybe.withDefault
                            "img/vidClick.mp4"
                            motCan.videoUrl
                        )
                        elmMsgElementEdited.selectVideo
                    )
                    (Maybe.Just
                        (Maybe.withDefault
                            (Potential
                                (SubstancePotential
                                    "0"
                                    "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                    "Nouvelle Substance"
                                )
                            )
                            motCan.principale
                        )
                    )
                    Maybe.Nothing
                    elmMsgElementEdited.selectSubstance

        Relationnelle relCan ->
            if
                Maybe.isJust relCan.videoUrl
                    && Maybe.isJust relCan.title
                    && Maybe.isJust relCan.premiere
                    && Maybe.isJust relCan.seconde
            then
                displayCanvasElement
                    (Maybe.Just
                        elmMsgElementEdited.recordSubstance
                    )
                    (Maybe.withDefault
                        "Substance Relation"
                        relCan.title
                    )
                    elmMsgElementEdited.enterTitle
                    (displayCanvasVideo
                        (Maybe.withDefault
                            "img/vidClick.mp4"
                            relCan.videoUrl
                        )
                        elmMsgElementEdited.selectVideo
                    )
                    (Maybe.Just
                        (Maybe.withDefault
                            (Potential
                                (SubstancePotential
                                    "0"
                                    "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                    "Nouvelle Substance"
                                )
                            )
                            relCan.premiere
                        )
                    )
                    (Maybe.Just
                        (Maybe.withDefault
                            (Potential
                                (SubstancePotential
                                    "0"
                                    "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                    "Nouvelle Substance"
                                )
                            )
                            relCan.seconde
                        )
                    )
                    elmMsgElementEdited.selectSubstance

            else
                displayCanvasElement
                    Maybe.Nothing
                    (Maybe.withDefault
                        "Substance Relation"
                        relCan.title
                    )
                    elmMsgElementEdited.enterTitle
                    (displayCanvasVideo
                        (Maybe.withDefault
                            "img/vidClick.mp4"
                            relCan.videoUrl
                        )
                        elmMsgElementEdited.selectVideo
                    )
                    (Maybe.Just
                        (Maybe.withDefault
                            (Potential
                                (SubstancePotential
                                    "0"
                                    "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                    "Nouvelle Substance"
                                )
                            )
                            relCan.premiere
                        )
                    )
                    (Maybe.Just
                        (Maybe.withDefault
                            (Potential
                                (SubstancePotential
                                    "0"
                                    "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                    "Nouvelle Substance"
                                )
                            )
                            relCan.seconde
                        )
                    )
                    elmMsgElementEdited.selectSubstance
