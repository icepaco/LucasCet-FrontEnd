module ApplicationCreator exposing (AppEdited, Application, CanvasApplication, ListeAppInfo, addAppState, addAppSubstance, addMetaSubstance, creerApplication, decodeAppState, displayModule, editSelectedApplication, initApp, initializeApplicationModule, obtainMetaSearchResult, resetApplication, setTitle)

import ApplicationPlayer exposing (..)
import Browser exposing (Document)
import Browser.Dom as DOM exposing (Error, Viewport, getViewport)
import Dict exposing (Dict)
import Element as L exposing (..)
import Element.Background as Bg exposing (color, gradient)
import Element.Border as Border exposing (..)
import Element.Events as Events exposing (..)
import Element.Input as Input exposing (..)
import Graphic_Downloader exposing (GraphicList)
import Graphic_Element as GraphEl exposing (..)
import Html exposing (video)
import Html.Attributes as H exposing (autoplay, controls, height, id, src, width)
import Http
import Json.Decode as Decode
import Json.Encode as Encode
import List.Extra as List
import Maybe.Extra as Maybe
import SubstancePlayer as Sub exposing (..)
import Task exposing (attempt)
import Tuple exposing (first, second)
import Url exposing (..)
import Url.Builder as Builder


type alias CanvasMeta =
    { metaData : String
    , appId : String
    , metaSubstances : Maybe (List Sub.Substance)
    }


type CanvasApplication
    = Absent
    | Didactique (Maybe Sub.Substance)
    | Proprietaire (Maybe Sub.Substance)
    | Locataire (Maybe Sub.Substance)


type alias Application =
    { name : String
    , icone : String
    , seqList : Dict String String
    }


type alias ListeAppInfo =
    { activeApplication : Maybe (List AppInfo)
    , remainingApplication : Maybe (List AppType)
    }


type alias AppEdited eleMsg =
    { activeModule : CanvasApplication
    , createNewApp : CanvasApplication -> eleMsg
    , editNewApp : CanvasApplication -> AppInfo -> eleMsg
    , initializeApp : CanvasApplication -> eleMsg
    , selectImage : eleMsg
    , enterTitle : String -> eleMsg
    , selectSequence : String -> String -> eleMsg
    , activeApplicationId : String
    , appState : ListeAppInfo
    , userId : String
    , title : Maybe String
    }


initApp : (CanvasApplication -> eleMsg) -> eleMsg -> (String -> eleMsg) -> (String -> String -> eleMsg) -> String -> (CanvasApplication -> AppInfo -> eleMsg) -> (CanvasApplication -> eleMsg) -> AppEdited eleMsg
initApp createApplication chooseImg declareTitle chooseSequence userIdValue editApplication appStarter =
    { activeModule = Absent
    , createNewApp = createApplication
    , editNewApp = editApplication
    , initializeApp = appStarter
    , selectImage = chooseImg
    , enterTitle = declareTitle
    , selectSequence = chooseSequence
    , activeApplicationId = ""
    , appState =
        { remainingApplication = Nothing
        , activeApplication = Nothing
        }
    , userId = userIdValue
    , title = Nothing
    }


addMetaSubstance : AppEdited eleMsg -> Sub.Substance -> (Result Http.Error () -> eleMsg) -> Cmd eleMsg
addMetaSubstance eleMsgAppEdited substance pingResult =
    case eleMsgAppEdited.activeModule of
        Absent ->
            Cmd.none

        Didactique _ ->
            Cmd.none

        Proprietaire _ ->
            Cmd.none

        Locataire _ ->
            Cmd.none


obtainMetaSearchResult : SelectElement eleMsg -> String -> String -> (Result Http.Error SubstanceList -> eleMsg) -> String -> Cmd eleMsg
obtainMetaSearchResult graphicData meta appId msgGet backendCall =
    let
        pagePath =
            if meta /= "" then
                if appId /= "" then
                    Builder.absolute [ backendCall ]
                        [ Builder.string "UserID"
                            graphicData.userId
                        , Builder.string "metaData" meta
                        , Builder.string "appId" appId
                        ]

                else
                    Builder.absolute [ backendCall ]
                        [ Builder.string "UserID"
                            graphicData.userId
                        , Builder.string "metaData" meta
                        ]

            else if appId /= "" then
                Builder.absolute [ backendCall ]
                    [ Builder.string "UserID"
                        graphicData.userId
                    , Builder.string "appId" appId
                    ]

            else
                Builder.absolute [ backendCall ]
                    [ Builder.string "UserID"
                        graphicData.userId
                    ]
    in
    Http.get
        { url = pagePath
        , expect = Http.expectJson msgGet Sub.decodeSubstanceList
        }


initializeApplicationModule : AppEdited eleMsg -> CanvasApplication -> (Result Http.Error () -> eleMsg) -> Cmd eleMsg
initializeApplicationModule eleMsgAppEdited canvasApplication pingResult =
    case canvasApplication of
        Absent ->
            Cmd.none

        Didactique dida ->
            case dida of
                Nothing ->
                    Cmd.none

                Just substance ->
                    case substance of
                        Relation substanceRelation ->
                            Cmd.none

                        Dynamic substanceDynamic ->
                            Cmd.none

                        Potential substancePotential ->
                            let
                                metaPath =
                                    Builder.absolute [ "createNewApp" ]
                                        [ Builder.string "userId" eleMsgAppEdited.userId
                                        , Builder.string "subId" substancePotential.subId
                                        , Builder.string "appType" "didactique"
                                        , Builder.string "appId" substancePotential.subId
                                        , Builder.string "title" (Maybe.withDefault "Application Didactique" eleMsgAppEdited.title)
                                        ]
                            in
                            Http.get
                                { url = metaPath
                                , expect = Http.expectWhatever pingResult
                                }

        Proprietaire maySub ->
            case maySub of
                Nothing ->
                    Cmd.none

                Just substance ->
                    case substance of
                        Relation substanceRelation ->
                            Cmd.none

                        Dynamic substanceDynamic ->
                            Cmd.none

                        Potential substancePotential ->
                            let
                                metaPath =
                                    Builder.absolute [ "createNewApp" ]
                                        [ Builder.string "userId" eleMsgAppEdited.userId
                                        , Builder.string "subId" substancePotential.subId
                                        , Builder.string "appType" "proprietaire"
                                        , Builder.string "appId" substancePotential.subId
                                        ]
                            in
                            Http.get
                                { url = metaPath
                                , expect = Http.expectWhatever pingResult
                                }

        Locataire maySub ->
            case maySub of
                Nothing ->
                    Cmd.none

                Just substance ->
                    case substance of
                        Relation substanceRelation ->
                            Cmd.none

                        Dynamic substanceDynamic ->
                            Cmd.none

                        Potential substancePotential ->
                            let
                                metaPath =
                                    Builder.absolute [ "createNewApp" ]
                                        [ Builder.string "userId" eleMsgAppEdited.userId
                                        , Builder.string "subId" substancePotential.subId
                                        , Builder.string "appType" "locataire"
                                        , Builder.string "appId" substancePotential.subId
                                        ]
                            in
                            Http.get
                                { url = metaPath
                                , expect = Http.expectWhatever pingResult
                                }


decodeAppState : Decode.Decoder ListeAppInfo
decodeAppState =
    Decode.map2 ListeAppInfo
        (Decode.field "activeApplication"
            (Decode.maybe
                (Decode.list
                    decodeAppInfo
                )
            )
        )
        (Decode.field "remainingApplication"
            (Decode.maybe
                (Decode.list
                    decodeAppType
                )
            )
        )


resetApplication : AppEdited eleMsg -> AppEdited eleMsg
resetApplication eleMsgAppEdited =
    { eleMsgAppEdited | activeModule = Absent }


creerApplication : AppEdited eleMsg -> CanvasApplication -> AppEdited eleMsg
creerApplication eleMsgAppEdited canvasApplication =
    { eleMsgAppEdited
        | activeModule = canvasApplication
    }


editSelectedApplication : AppEdited eleMsg -> CanvasApplication -> AppInfo -> AppEdited eleMsg
editSelectedApplication eleMsgAppEdited canvasApplication appInfo =
    { eleMsgAppEdited | activeModule = canvasApplication, activeApplicationId = appInfo.appId }


setTitle : AppEdited eleMsg -> String -> AppEdited eleMsg
setTitle eleMsgAppEdited title =
    { eleMsgAppEdited | title = Just title }


addAppSubstance : AppEdited eleMsg -> Sub.Substance -> AppEdited eleMsg
addAppSubstance eleMsgAppEdited substance =
    case eleMsgAppEdited.activeModule of
        Absent ->
            eleMsgAppEdited

        Didactique dida ->
            { eleMsgAppEdited | activeModule = Didactique (Just substance) }

        Proprietaire _ ->
            { eleMsgAppEdited | activeModule = Proprietaire (Just substance) }

        Locataire _ ->
            { eleMsgAppEdited | activeModule = Locataire (Just substance) }


addAppState : AppEdited eleMsg -> ListeAppInfo -> AppEdited eleMsg
addAppState eleMsgAppEdited listeAppInfo =
    { eleMsgAppEdited | appState = listeAppInfo }


viewApp : Application -> (Application -> eleMsg) -> Element eleMsg
viewApp app deployApplication =
    column []
        [ GraphEl.displayCanvasImage app.icone (deployApplication app)
        , L.text app.name
        ]


developperAppCreer : AppType -> AppEdited eleMsg -> Element eleMsg
developperAppCreer appType elmMsgElementEdited =
    case appType of
        DidactiqueModule ->
            afficherInterfaceSelection "https://storage.googleapis.com/lucascet-data/LucasPlateforme/Application/dictionnaire.png"
                "Créer une Application Didactique"
                (elmMsgElementEdited.createNewApp
                    (Didactique Nothing)
                )

        ProprietaireModule ->
            afficherInterfaceSelection "https://storage.googleapis.com/lucascet-data/LucasPlateforme/Application/proprietaire.jfif"
                "Créer une App Proprio"
                (elmMsgElementEdited.createNewApp
                    (Proprietaire Nothing)
                )

        LocataireModule ->
            afficherInterfaceSelection "https://storage.googleapis.com/lucascet-data/LucasPlateforme/Application/Locataire.png"
                "Créer une App Locataire"
                (elmMsgElementEdited.createNewApp
                    (Locataire Nothing)
                )

        FournisseurModule ->
            afficherInterfaceSelection "/img/potentielle.jpg"
                "Créer une App Proprio"
                (elmMsgElementEdited.createNewApp
                    Absent
                )


displayModule : AppEdited eleMsg -> Element eleMsg
displayModule elmMsgElementEdited =
    case elmMsgElementEdited.activeModule of
        Absent ->
            case elmMsgElementEdited.appState.remainingApplication of
                Nothing ->
                    case elmMsgElementEdited.appState.activeApplication of
                        Nothing ->
                            L.text "Aucune application disponible"

                        Just activeList ->
                            L.text "Aucune application disponible"

                Just remainList ->
                    case elmMsgElementEdited.appState.activeApplication of
                        Nothing ->
                            row [ padding 25, spaceEvenly, L.width fill, L.height fill ]
                                (List.map (\a -> developperAppCreer a elmMsgElementEdited) remainList)

                        Just activeList ->
                            row [ padding 25, spaceEvenly, L.width fill, L.height fill ]
                                (List.map (\a -> developperAppCreer a elmMsgElementEdited) remainList)

        Didactique didCan ->
            if Maybe.isJust didCan then
                displayProprioElement
                    (Just (elmMsgElementEdited.initializeApp (Didactique didCan)))
                    (Maybe.withDefault
                        (Potential
                            (SubstancePotential
                                "0"
                                "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                "Nouvelle Substance"
                            )
                        )
                        didCan
                    )
                    (elmMsgElementEdited.selectSequence "" "")
                    (Maybe.withDefault
                        "Application Didactique"
                        elmMsgElementEdited.title
                    )
                    elmMsgElementEdited.enterTitle

            else
                displayProprioElement
                    Nothing
                    (Maybe.withDefault
                        (Potential
                            (SubstancePotential
                                "0"
                                "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                "Nouvelle Substance"
                            )
                        )
                        didCan
                    )
                    (elmMsgElementEdited.selectSequence "" "")
                    (Maybe.withDefault
                        "Substance Potentielle"
                        elmMsgElementEdited.title
                    )
                    elmMsgElementEdited.enterTitle

        Proprietaire prop ->
            if Maybe.isJust prop then
                displayProprioElement
                    (Just (elmMsgElementEdited.initializeApp (Proprietaire prop)))
                    (Maybe.withDefault
                        (Potential
                            (SubstancePotential
                                "0"
                                "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                "Nouvelle Substance"
                            )
                        )
                        prop
                    )
                    (elmMsgElementEdited.selectSequence "" "")
                    (Maybe.withDefault
                        "Substance Potentielle"
                        elmMsgElementEdited.title
                    )
                    elmMsgElementEdited.enterTitle

            else
                displayProprioElement
                    Nothing
                    (Maybe.withDefault
                        (Potential
                            (SubstancePotential
                                "0"
                                "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                "Nouvelle Substance"
                            )
                        )
                        prop
                    )
                    (elmMsgElementEdited.selectSequence "" "")
                    (Maybe.withDefault
                        "Substance Potentielle"
                        elmMsgElementEdited.title
                    )
                    elmMsgElementEdited.enterTitle

        Locataire prop ->
            if Maybe.isJust prop then
                displayProprioElement
                    (Just (elmMsgElementEdited.initializeApp (Locataire prop)))
                    (Maybe.withDefault
                        (Potential
                            (SubstancePotential
                                "0"
                                "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                "Nouvelle Substance"
                            )
                        )
                        prop
                    )
                    (elmMsgElementEdited.selectSequence "" "")
                    (Maybe.withDefault
                        "Substance Potentielle"
                        elmMsgElementEdited.title
                    )
                    elmMsgElementEdited.enterTitle

            else
                displayProprioElement
                    Nothing
                    (Maybe.withDefault
                        (Potential
                            (SubstancePotential
                                "0"
                                "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                                "Nouvelle Substance"
                            )
                        )
                        prop
                    )
                    (elmMsgElementEdited.selectSequence "" "")
                    (Maybe.withDefault
                        "Substance Potentielle"
                        elmMsgElementEdited.title
                    )
                    elmMsgElementEdited.enterTitle


displayDidacticElement : Maybe eleMsg -> String -> (String -> eleMsg) -> Element eleMsg -> Element eleMsg
displayDidacticElement canvasRdy title inputTitle displayMedia =
    let
        subHolder =
            Potential
                (SubstancePotential
                    "0"
                    "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQP_VWIAoqTmrTVq0R-BCKUVQ-ew77YO4bT5cTypTTRya84feMs"
                    "Nouvelle Séquence"
                )
    in
    case canvasRdy of
        Just eleMsg ->
            column [ Border.innerGlow (L.rgb255 105 55 200) 5, L.width fill, L.height fill, padding 25, spaceEvenly ]
                [ Input.text [ centerX, centerY ]
                    { onChange = inputTitle
                    , text = title
                    , placeholder = Maybe.Just (placeholder [] (L.text "Titre du Module didactique:"))
                    , label = Input.labelAbove [] (L.text title)
                    }
                , L.text "Selectionner une icône pour ce module"
                , displayMedia
                , button [ Border.innerGlow (L.rgb255 225 155 2) 2, centerX, centerY ]
                    { onPress = canvasRdy
                    , label = L.text "Appuyer pour enregistrer"
                    }
                ]

        Maybe.Nothing ->
            column [ L.width fill, L.height fill, padding 25, spaceEvenly ]
                [ Input.text [ centerX, centerY ]
                    { onChange = inputTitle
                    , text = title
                    , placeholder = Maybe.Just (placeholder [] (L.text "Titre Module:"))
                    , label = Input.labelAbove [] (L.text title)
                    }
                , L.text "Selectionner une icône pour ce module"
                , displayMedia
                ]


displayProprioElement : Maybe eleMsg -> Sub.Substance -> eleMsg -> String -> (String -> eleMsg) -> Element eleMsg
displayProprioElement canvasRdy substance inputSubstance title inputTitle =
    case canvasRdy of
        Just eleMsg ->
            column [ Border.innerGlow (L.rgb255 105 55 200) 5, L.width fill, L.height fill, padding 25, spaceEvenly ]
                [ Input.text [ centerX, centerY ]
                    { onChange = inputTitle
                    , text = title
                    , placeholder = Maybe.Just (placeholder [] (L.text "Titre Substance:"))
                    , label = Input.labelAbove [] (L.text title)
                    }
                , displayCanvasSubstance substance inputSubstance ( 800, 800 )
                , button [ Border.innerGlow (L.rgb255 225 155 2) 2, centerX, centerY ]
                    { onPress = canvasRdy
                    , label = L.text "Appuyer pour enregistrer"
                    }
                ]

        Maybe.Nothing ->
            column [ L.width fill, L.height fill, padding 25, spaceEvenly ]
                [ Input.text [ centerX, centerY ]
                    { onChange = inputTitle
                    , text = title
                    , placeholder = Maybe.Just (placeholder [] (L.text "Titre Substance:"))
                    , label = Input.labelAbove [] (L.text title)
                    }
                , GraphEl.displayCanvasSubstance substance inputSubstance ( 800, 800 )
                ]
