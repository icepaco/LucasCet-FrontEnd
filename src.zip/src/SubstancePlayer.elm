module SubstancePlayer exposing (DeployedSubstance, Page(..), SelectElement, Substance(..), SubstanceDisplay(..), SubstanceDynamic, SubstanceLiee(..), SubstanceList, SubstancePotential, SubstanceRelation, addNewPage, columnAttribute, decodeSubstance, decodeSubstanceList, decorateVideo, displayErrorMsg, displayInactiveSubstanceList, displayInteractiveSubstanceList, displaySubstancePlain, displaySubstanceZoomed, displayTable, initSelectElement, modifySubstanceMedia, nextGraphicList, obtainGraphicList, recordSubstance, resetPaging, selectedSequenceAttribute, selectedSubstanceAttribute, sequenceAttribute, setDeploymentList, showSubstanceList, substanceAttribute, updateGraphicData, xplodSub, xplodSubWithChild)

import Browser exposing (Document)
import Browser.Dom as DOM exposing (Error, Viewport, getViewport)
import Dict exposing (Dict)
import Element as L exposing (..)
import Element.Background as Bg exposing (color, gradient)
import Element.Border as Border exposing (..)
import Element.Events as Events exposing (..)
import Element.Font as Font
import Element.Input as Input exposing (..)
import Graphic_Downloader exposing (GraphicList)
import Html exposing (video)
import Html.Attributes as H exposing (autoplay, controls, height, id, src, width)
import Http
import Json.Decode as Decode
import Json.Encode as Encode
import List.Extra as List
import Maybe.Extra as Maybe
import Task exposing (attempt)
import Tuple exposing (first, second)
import Url exposing (..)
import Url.Builder as Builder


type alias SubstancePotential =
    { subId : String
    , image : String
    , name : String
    }


type alias SubstanceDynamic =
    { subId : String
    , video : String
    , name : String
    , principal : SubstanceLiee
    }


type SubstanceLiee
    = Lien String
    | SubLiee Substance
    | Error String


type alias SubstanceRelation =
    { subId : String
    , media : String
    , name : String
    , substance1 : SubstanceLiee
    , substance2 : SubstanceLiee
    }


type Substance
    = Relation SubstanceRelation
    | Dynamic SubstanceDynamic
    | Potential SubstancePotential


type alias DeployedSubstance eleMsg =
    { subId : String
    , deployment : Element eleMsg
    }


type SubstanceDisplay
    = RelationDisplay SubstanceRelation
    | DynamicDisplay SubstanceDynamic
    | PotentialDisplay SubstancePotential
    | Practice SubstanceDisplay
    | Erreur String


type alias SubstanceList =
    { suiteToken : Maybe String
    , substances : Page
    }


type Page
    = SubPage (List Substance)
    | SeqPage (List Substance)


type alias SelectElement eleMsg =
    { suiteToken : Maybe String
    , elementPages : Maybe (List Page)
    , chooseNextPage : Maybe eleMsg
    , currentPage : Int
    , choosePreviousPage : Maybe eleMsg
    , selectElementAction : Substance -> eleMsg
    , selectAppSubstanceAction : Substance -> eleMsg
    , chosenSubstance : Substance -> eleMsg
    , nextMsg : eleMsg
    , prevMsg : eleMsg
    , deleteAll : eleMsg
    , backendCall : String
    , userId : String
    , selectedSubstanceId : String
    }


initSelectElement : String -> (Substance -> eleMsg) -> (Substance -> eleMsg) -> (Substance -> eleMsg) -> eleMsg -> eleMsg -> eleMsg -> SelectElement eleMsg
initSelectElement userIdValue substancePicked substanceChosen sequencePicked prevPage nextPage efface =
    { suiteToken = Nothing
    , elementPages = Nothing
    , chooseNextPage = Nothing
    , currentPage = 0
    , choosePreviousPage = Nothing
    , selectElementAction = substancePicked
    , selectAppSubstanceAction = sequencePicked
    , chosenSubstance = substanceChosen
    , nextMsg = nextPage
    , prevMsg = prevPage
    , backendCall = ""
    , selectedSubstanceId = ""
    , userId = userIdValue
    , deleteAll = efface
    }


obtainGraphicList : SelectElement eleMsg -> (Result Http.Error SubstanceList -> eleMsg) -> String -> Cmd eleMsg
obtainGraphicList graphicData msgGet backendCall =
    let
        pagePath =
            Builder.absolute [ backendCall ]
                [ Builder.string "UserID"
                    graphicData.userId
                ]
    in
    Http.get
        { url = pagePath
        , expect = Http.expectJson msgGet decodeSubstanceList
        }


nextGraphicList : SelectElement eleMsg -> (Result Http.Error SubstanceList -> eleMsg) -> String -> Cmd eleMsg
nextGraphicList graphicData msgFun backendCall =
    case graphicData.suiteToken of
        Maybe.Just token ->
            let
                pagePath =
                    Builder.absolute [ backendCall ]
                        [ Builder.string "UserID"
                            graphicData.userId
                        , Builder.string
                            "tokenSuite"
                            token
                        ]
            in
            Http.get
                { url = pagePath
                , expect = Http.expectJson msgFun decodeSubstanceList
                }

        Maybe.Nothing ->
            case graphicData.elementPages of
                Nothing ->
                    let
                        pagePath =
                            Builder.absolute [ backendCall ]
                                [ Builder.string "UserID"
                                    graphicData.userId
                                ]
                    in
                    Http.get
                        { url = pagePath
                        , expect = Http.expectJson msgFun decodeSubstanceList
                        }

                Just _ ->
                    Cmd.none


modifySubstanceMedia : SelectElement eleMsg -> String -> (Result Http.Error () -> eleMsg) -> Cmd eleMsg
modifySubstanceMedia eleMsgSelectElement mediaUrl secondaireSubs =
    let
        urlPath =
            Builder.absolute [ "updateSubstanceMedia" ]
                [ Builder.string "subId" eleMsgSelectElement.selectedSubstanceId
                , Builder.string "mediaUrl" mediaUrl
                , Builder.string "userId" eleMsgSelectElement.userId
                ]
    in
    Http.get
        { url = urlPath
        , expect = Http.expectWhatever secondaireSubs
        }


decodeRelation : Decode.Decoder SubstanceRelation
decodeRelation =
    Decode.map5 SubstanceRelation
        (Decode.field "subId" Decode.string)
        (Decode.field "media" Decode.string)
        (Decode.field "title" Decode.string)
        (Decode.map Lien (Decode.field "firstSubstance" Decode.string))
        (Decode.map Lien (Decode.field "secondSubstance" Decode.string))


decodeDynamic : Decode.Decoder SubstanceDynamic
decodeDynamic =
    Decode.map4 SubstanceDynamic
        (Decode.field "subId" Decode.string)
        (Decode.field "media" Decode.string)
        (Decode.field "title" Decode.string)
        (Decode.map Lien (Decode.field "principale" Decode.string))


decodePotential : Decode.Decoder SubstancePotential
decodePotential =
    Decode.map3 SubstancePotential (Decode.field "subId" Decode.string) (Decode.field "media" Decode.string) (Decode.field "title" Decode.string)


decodeSubstance : Decode.Decoder Substance
decodeSubstance =
    Decode.field "subType" Decode.string
        |> Decode.andThen
            (\str ->
                case str of
                    "relation" ->
                        Decode.map Relation decodeRelation

                    "dynamic" ->
                        Decode.map Dynamic decodeDynamic

                    "potential" ->
                        Decode.map Potential decodePotential

                    somethingElse ->
                        Decode.fail <| "Unknown media type" ++ somethingElse
            )


decodeSubstanceList : Decode.Decoder SubstanceList
decodeSubstanceList =
    Decode.field
        "pageType"
        Decode.string
        |> Decode.andThen
            (\string ->
                case string of
                    "SubPage" ->
                        Decode.map2 SubstanceList
                            (Decode.maybe
                                (Decode.field
                                    "nextContinuationToken"
                                    Decode.string
                                )
                            )
                            (Decode.field "objectSummaries"
                                (Decode.map
                                    SubPage
                                    (Decode.list (Decode.field "key" decodeSubstance))
                                )
                            )

                    "SeqPage" ->
                        Decode.map2 SubstanceList
                            (Decode.maybe
                                (Decode.field
                                    "nextContinuationToken"
                                    Decode.string
                                )
                            )
                            (Decode.field "objectSummaries"
                                (Decode.map
                                    SeqPage
                                    (Decode.list (Decode.field "key" decodeSubstance))
                                )
                            )

                    _ ->
                        Decode.fail "Invalid Page"
            )


updateGraphicData : SelectElement eleMsg -> SelectElement eleMsg
updateGraphicData subData =
    case subData.elementPages of
        Maybe.Just lesPages ->
            case subData.suiteToken of
                Maybe.Nothing ->
                    { subData
                        | chooseNextPage =
                            if subData.currentPage + 1 < List.length lesPages then
                                Maybe.Just subData.nextMsg

                            else
                                Maybe.Nothing
                        , choosePreviousPage =
                            if subData.currentPage > 0 then
                                Maybe.Just subData.prevMsg

                            else
                                Maybe.Nothing
                    }

                Maybe.Just _ ->
                    { subData
                        | chooseNextPage =
                            Maybe.Just subData.nextMsg
                        , choosePreviousPage =
                            if subData.currentPage > 0 then
                                Maybe.Just subData.prevMsg

                            else
                                Maybe.Nothing
                    }

        Maybe.Nothing ->
            subData


addNewPage : SubstanceList -> SelectElement eleMsg -> SelectElement eleMsg
addNewPage subList subData =
    case subData.elementPages of
        Maybe.Just lesPages ->
            { subData
                | elementPages = Maybe.Just (lesPages ++ [ subList.substances ])
                , suiteToken = subList.suiteToken
            }

        Maybe.Nothing ->
            { subData
                | elementPages = Maybe.Just [ subList.substances ]
                , suiteToken = subList.suiteToken
            }



-- Logic


resetPaging : SelectElement eleMsg -> SelectElement eleMsg
resetPaging eleMsgSelectElement =
    { eleMsgSelectElement | elementPages = Nothing, currentPage = 0 }


testSubstance : Substance -> String -> Bool
testSubstance substance idSub =
    case substance of
        Relation substanceRelation ->
            substanceRelation.subId == idSub

        Dynamic substanceDynamic ->
            substanceDynamic.subId == idSub

        Potential substancePotential ->
            substancePotential.subId == idSub


testSubstanceDisplay : SubstanceDisplay -> String -> Bool
testSubstanceDisplay substance idSub =
    case substance of
        RelationDisplay substanceRelation ->
            substanceRelation.subId == idSub

        DynamicDisplay substanceDynamic ->
            substanceDynamic.subId == idSub

        PotentialDisplay substancePotential ->
            substancePotential.subId == idSub

        Practice _ ->
            False

        Erreur _ ->
            False


findSubstance : SubstanceLiee -> List Substance -> SubstanceLiee
findSubstance substanceLiee substanceList =
    case substanceLiee of
        Lien idSub ->
            let
                substanceRes =
                    List.head (List.filter (\sub -> testSubstance sub idSub) substanceList)
            in
            case substanceRes of
                Maybe.Just value ->
                    SubLiee value

                Maybe.Nothing ->
                    Error ("Error LCA-1D ecode error in finding:" ++ idSub)

        SubLiee substance ->
            SubLiee substance

        Error msg ->
            Error msg


refineSubstance : SubstanceLiee -> List Substance -> SubstanceLiee
refineSubstance substanceLiee subList =
    case substanceLiee of
        Lien string ->
            Error ("Error LCA-2D ecode error in finding:" ++ string)

        SubLiee substance ->
            SubLiee (extractPlainSubstance substance subList)

        Error err ->
            Error err


extractPlainSubstance : Substance -> List Substance -> Substance
extractPlainSubstance sub substanceList =
    case sub of
        Relation substanceRelation ->
            Relation
                { substanceRelation
                    | substance1 = refineSubstance (findSubstance substanceRelation.substance1 substanceList) substanceList
                    , substance2 = refineSubstance (findSubstance substanceRelation.substance2 substanceList) substanceList
                }

        Dynamic substanceDynamic ->
            Dynamic { substanceDynamic | principal = refineSubstance (findSubstance substanceDynamic.principal substanceList) substanceList }

        Potential substancePotential ->
            Potential substancePotential


extractSubstance : Substance -> List Substance -> SubstanceDisplay
extractSubstance sub substanceList =
    case sub of
        Relation substanceRelation ->
            RelationDisplay
                { substanceRelation
                    | substance1 = refineSubstance (findSubstance substanceRelation.substance1 substanceList) substanceList
                    , substance2 = refineSubstance (findSubstance substanceRelation.substance2 substanceList) substanceList
                }

        Dynamic substanceDynamic ->
            DynamicDisplay { substanceDynamic | principal = refineSubstance (findSubstance substanceDynamic.principal substanceList) substanceList }

        Potential substancePotential ->
            PotentialDisplay substancePotential


extractSubstanceLiee : SubstanceLiee -> List SubstanceDisplay -> SubstanceDisplay
extractSubstanceLiee substanceLiee substanceList =
    case substanceLiee of
        Lien idSub ->
            let
                substanceRes =
                    List.head (List.filter (\sub -> testSubstanceDisplay sub idSub) substanceList)
            in
            case substanceRes of
                Maybe.Just value ->
                    value

                Maybe.Nothing ->
                    Erreur ("Error LCA-1D ecode error in finding:" ++ idSub)

        SubLiee substance ->
            case substance of
                Relation substanceRelation ->
                    RelationDisplay substanceRelation

                Dynamic substanceDynamic ->
                    DynamicDisplay substanceDynamic

                Potential substancePotential ->
                    PotentialDisplay substancePotential

        Error msg ->
            Erreur msg


recordSubstance : SelectElement eleMsg -> Substance -> SelectElement eleMsg
recordSubstance eleMsgSelectElement substance =
    case substance of
        Relation substanceRelation ->
            { eleMsgSelectElement | selectedSubstanceId = substanceRelation.subId }

        Dynamic substanceDynamic ->
            { eleMsgSelectElement | selectedSubstanceId = substanceDynamic.subId }

        Potential substancePotential ->
            { eleMsgSelectElement | selectedSubstanceId = substancePotential.subId }


showSubstanceList : List (L.Attribute eleMsg) -> String -> SelectElement eleMsg -> Element eleMsg
showSubstanceList msgAttributeLList backendCall subData =
    case subData.elementPages of
        Maybe.Just pages ->
            case List.getAt subData.currentPage pages of
                Maybe.Just aPage ->
                    case aPage of
                        SubPage graphPages ->
                            if backendCall == "downloadAppSubstancePage" then
                                column [ spacing 10 ]
                                    [ wrappedRow ([ padding 10, spacing 5 ] ++ msgAttributeLList)
                                        (List.map
                                            (\a ->
                                                displaySubstanceStub a
                                                    subData.selectAppSubstanceAction
                                                    ( 60, 60 )
                                            )
                                            graphPages
                                        )
                                    , row
                                        [ spaceEvenly, L.width fill ]
                                        [ button [ alignLeft ]
                                            { onPress = subData.choosePreviousPage, label = L.text "Previous Page" }
                                        , button
                                            [ alignRight ]
                                            { onPress = subData.chooseNextPage, label = L.text "Next Page" }
                                        ]
                                    ]

                            else
                                column [ spacing 10 ]
                                    [ wrappedRow ([ padding 10, spacing 5 ] ++ msgAttributeLList)
                                        (List.map
                                            (\a ->
                                                displaySubstanceStub a
                                                    subData.selectElementAction
                                                    ( 60, 60 )
                                            )
                                            graphPages
                                        )
                                    , row
                                        [ spaceEvenly, L.width fill ]
                                        [ button [ alignLeft ]
                                            { onPress = subData.choosePreviousPage, label = L.text "Previous Page" }
                                        , button
                                            [ alignRight ]
                                            { onPress = subData.chooseNextPage, label = L.text "Next Page" }
                                        ]
                                    ]

                        SeqPage lstPages ->
                            column [ spacing 10 ]
                                [ wrappedRow ([ padding 10, spacing 5 ] ++ msgAttributeLList)
                                    (List.map
                                        (\a ->
                                            displaySubstanceStub a subData.selectAppSubstanceAction ( 60, 60 )
                                        )
                                        lstPages
                                    )
                                , row
                                    [ spaceEvenly, L.width fill ]
                                    [ button [ alignLeft ]
                                        { onPress = subData.choosePreviousPage, label = L.text "Previous Page" }
                                    , button
                                        [ alignRight ]
                                        { onPress = subData.chooseNextPage, label = L.text "Next Page" }
                                    ]
                                ]

                Maybe.Nothing ->
                    L.text ("Error : Wrong page #" ++ String.fromInt subData.currentPage)

        Maybe.Nothing ->
            L.text "Error : No pages"


displayTable : SelectElement eleMsg -> Element eleMsg
displayTable subData =
    case subData.elementPages of
        Maybe.Just pages ->
            case List.getAt subData.currentPage pages of
                Maybe.Just aPage ->
                    case aPage of
                        SubPage graphPages ->
                            table
                                [ Border.width 2
                                , solid
                                , innerGlow (rgb255 255 200 150) 1
                                ]
                                { data = graphPages
                                , columns =
                                    [ { header =
                                            column [ innerGlow (rgb255 125 25 150) 1 ]
                                                [ button [ Border.width 1, solid, rounded 2, innerGlow (rgb255 0 20 150) 0.5 ]
                                                    { onPress = Just subData.deleteAll, label = L.text "Effacer le dictionnaire" }
                                                , L.text "Media Substance"
                                                ]
                                      , width = fill
                                      , view = \substance -> displaySubstanceStub substance subData.chosenSubstance ( 60, 60 )
                                      }
                                    , { header = L.text "LienSub.Substance1"
                                      , width = fill
                                      , view = \substance -> displayPremierLienSubstance substance ( 60, 60 )
                                      }
                                    , { header = L.text "LienSub.Substance2"
                                      , width = fill
                                      , view = \substance -> displaySecondLienSubstance substance ( 60, 60 )
                                      }
                                    ]
                                }

                        _ ->
                            L.text "No Pages"

                _ ->
                    L.text "No Pages"

        _ ->
            L.text "No Pages"


displaySubstance : (SubstanceDisplay -> eleMsg) -> SubstanceDisplay -> ( Float, Float ) -> Element eleMsg
displaySubstance activateSubstance substance dimension =
    case substance of
        RelationDisplay substanceRelation ->
            case substanceRelation.substance1 of
                SubLiee substance1Liee ->
                    case substanceRelation.substance2 of
                        SubLiee substance2Liee ->
                            row rowAttribute
                                [ column columnAttribute
                                    [ decorateVideo substanceRelation.media (round (first dimension * 0.6)) (round (second dimension * 0.6))
                                    , paragraph [] [ L.text substanceRelation.name ]
                                    , button [ onClick (activateSubstance (Practice substance)) ] { label = L.text "Practice", onPress = Maybe.Nothing }
                                    ]
                                , column [ alignTop, L.width (fillPortion 1) ]
                                    [ column gradientEffect
                                        (List.map (\a -> displaySubstanceLink a (transformAppel activateSubstance) dimension)
                                            [ substance1Liee, substance2Liee ]
                                        )
                                    ]
                                ]

                        Error err ->
                            column []
                                [ el [] (L.html (video [ src substanceRelation.media ] []))
                                , paragraph [] [ L.text err ]
                                ]

                        Lien str ->
                            column []
                                [ el [] (L.html (video [ src substanceRelation.media ] []))
                                , paragraph [] [ L.text ("Error LCA-2S Can't link substance:" ++ str) ]
                                ]

                Error msg ->
                    column []
                        [ el [] (L.html (video [ src substanceRelation.media ] []))
                        , paragraph [] [ L.text msg ]
                        ]

                Lien path ->
                    column []
                        [ el [] (L.html (video [ src substanceRelation.media ] []))
                        , paragraph [] [ L.text ("Error LCA-3S Can't link substance:" ++ path) ]
                        ]

        DynamicDisplay substanceDynamic ->
            case substanceDynamic.principal of
                SubLiee principale ->
                    row rowAttribute
                        [ column columnAttribute
                            [ decorateVideo substanceDynamic.video (round (first dimension * 0.6)) (round (second dimension * 0.6))
                            , paragraph [] [ L.text substanceDynamic.name ]
                            , button [ onClick (activateSubstance (Practice substance)) ] { label = L.text "Practice", onPress = Maybe.Nothing }
                            ]
                        , column [ alignTop, L.width (fillPortion 1) ]
                            [ column gradientEffect [ displaySubstanceLink principale (transformAppel activateSubstance) dimension ]
                            ]
                        ]

                Error err ->
                    column []
                        [ el [] (L.html (video [ src substanceDynamic.video ] []))
                        , paragraph [] [ L.text err ]
                        ]

                Lien str ->
                    column []
                        [ el [] (L.html (video [ src substanceDynamic.video ] []))
                        , paragraph [] [ L.text ("Error LCA-4S Can't link substance:" ++ str) ]
                        ]

        PotentialDisplay substancePotential ->
            column []
                [ image [ L.height (fill |> maximum 400), L.width (fill |> maximum 400) ]
                    { src = substancePotential.image, description = "Potential" }
                ]

        Practice substance2Practice ->
            case substance2Practice of
                RelationDisplay subRel ->
                    row rowAttribute
                        [ el
                            []
                            (L.html
                                (video
                                    [ src subRel.media
                                    , controls True
                                    , H.width (round (first dimension * 0.6))
                                    , H.height (round (second dimension * 0.6))
                                    ]
                                    []
                                )
                            )
                        , el gradientEffect (L.html (video [ id "elmVid", autoplay True ] []))
                        ]

                DynamicDisplay subDyna ->
                    row rowAttribute
                        [ el
                            []
                            (L.html
                                (video
                                    [ src subDyna.video
                                    , controls True
                                    , H.width (round (first dimension * 0.6))
                                    , H.height (round (second dimension * 0.6))
                                    ]
                                    []
                                )
                            )
                        , el gradientEffect (L.html (video [ id "elmVid", autoplay True ] []))
                        ]

                PotentialDisplay subPoten ->
                    row rowAttribute
                        [ image [] { src = subPoten.image, description = "Potential" }
                        , el gradientEffect (L.html (video [ id "elmVid", autoplay True ] []))
                        ]

                Practice _ ->
                    el [] (paragraph [] [ L.text "error LCA-10S recursive practice" ])

                Erreur txtErr ->
                    el [] (paragraph [] [ L.text txtErr ])

        Erreur texteErreur ->
            el [] (paragraph [] [ L.text texteErreur ])


substanceAttribute : List (L.Attribute eleMsg)
substanceAttribute =
    [ centerX
    , Bg.color (rgb255 255 255 255)
    , alignTop
    , padding 10
    , mouseOver [ Bg.color (rgb255 229 229 229) ]
    ]


selectedSubstanceAttribute : List (L.Attribute eleMsg)
selectedSubstanceAttribute =
    [ Bg.color (rgb255 235 107 76)
    , centerX
    , alignTop
    , padding 10
    ]


substanceImageAttribute : ( Float, Float ) -> List (L.Attribute eleMsg)
substanceImageAttribute dimension =
    [ L.width (px (round (first dimension)))
    , L.height (px (round (second dimension)))
    , centerX
    , alignTop
    ]


menuSubstanceAttribute : eleMsg -> List (L.Attribute eleMsg)
menuSubstanceAttribute gonerEvent =
    [ L.width (px 185)
    , L.height (px 140)
    , centerX
    , alignTop
    , onMouseLeave gonerEvent
    ]


selectedSequenceAttribute : List (L.Attribute eleMsg)
selectedSequenceAttribute =
    [ Border.width 2
    , Border.color (rgb255 235 107 76)
    , Bg.color (rgb255 0 0 0)
    , centerX
    , alignTop
    , paddingEach { top = 10, right = 0, bottom = 0, left = 0 }
    ]


sequenceAttribute : List (L.Attribute eleMsgSelectElement)
sequenceAttribute =
    [ centerX
    , alignTop
    ]


substanceTextAttribute : List (L.Attribute appMsg)
substanceTextAttribute =
    [ paddingXY 0 10
    , Font.color (rgb255 0 0 0)
    , Font.size 14
    , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
    , Font.center
    ]


selectedSubstanceTextAttribute : List (L.Attribute appMsg)
selectedSubstanceTextAttribute =
    [ paddingXY 0 10
    , Font.color (rgb255 226 89 55)
    , Font.size 14
    , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
    , Font.center
    ]


zoomedSubstanceTextAttribute : List (L.Attribute appMsg)
zoomedSubstanceTextAttribute =
    [ Font.size 20
    , Font.color (rgb255 255 255 255)
    ]


displaySubstanceWithMenu : Substance -> (Substance -> eleMsg) -> Maybe ( String, List (L.Attribute eleMsg) ) -> Maybe (DeployedSubstance eleMsg) -> ( Float, Float ) -> Element eleMsg
displaySubstanceWithMenu substance subClicker selectedMenu deployedSubstanceDisplay dimension =
    case deployedSubstanceDisplay of
        Just eleMsgDeployedSubstance ->
            case selectedMenu of
                Just activeMenu ->
                    case substance of
                        Relation substanceRelation ->
                            if substanceRelation.subId == eleMsgDeployedSubstance.subId then
                                eleMsgDeployedSubstance.deployment

                            else if substanceRelation.subId == first activeMenu then
                                column
                                    (substanceAttribute
                                        ++ second activeMenu
                                    )
                                    [ decorateVideo substanceRelation.media 200 150
                                    , paragraph selectedSubstanceTextAttribute [ L.text substanceRelation.name ]
                                    ]

                            else
                                column
                                    (substanceAttribute
                                        ++ [ onMouseEnter (subClicker substance) ]
                                    )
                                    [ decorateVideo substanceRelation.media 185 140
                                    , paragraph substanceTextAttribute [ L.text substanceRelation.name ]
                                    ]

                        Dynamic substanceDynamic ->
                            if substanceDynamic.subId == eleMsgDeployedSubstance.subId then
                                eleMsgDeployedSubstance.deployment

                            else if substanceDynamic.subId == first activeMenu then
                                column
                                    (substanceAttribute
                                        ++ second activeMenu
                                    )
                                    [ decorateVideo substanceDynamic.video 200 150
                                    , paragraph selectedSubstanceTextAttribute [ L.text substanceDynamic.name ]
                                    ]

                            else
                                column
                                    (substanceAttribute
                                        ++ [ onMouseEnter (subClicker substance) ]
                                    )
                                    [ decorateVideo substanceDynamic.video 185 140
                                    , paragraph substanceTextAttribute [ L.text substanceDynamic.name ]
                                    ]

                        Potential substancePotential ->
                            if substancePotential.subId == first activeMenu then
                                image
                                    (substanceImageAttribute dimension
                                        ++ second activeMenu
                                    )
                                    { src = substancePotential.image, description = "Potential" }

                            else
                                image
                                    (substanceImageAttribute dimension
                                        ++ [ onMouseEnter (subClicker substance)
                                           ]
                                    )
                                    { src = substancePotential.image, description = "Potential" }

                Nothing ->
                    case substance of
                        Relation substanceRelation ->
                            if substanceRelation.subId == eleMsgDeployedSubstance.subId then
                                eleMsgDeployedSubstance.deployment

                            else
                                column
                                    (substanceAttribute
                                        ++ [ onMouseEnter (subClicker substance) ]
                                    )
                                    [ decorateVideo substanceRelation.media 185 140
                                    , paragraph substanceTextAttribute [ L.text substanceRelation.name ]
                                    ]

                        Dynamic substanceDynamic ->
                            if substanceDynamic.subId == eleMsgDeployedSubstance.subId then
                                eleMsgDeployedSubstance.deployment

                            else
                                column
                                    (substanceAttribute
                                        ++ [ onMouseEnter (subClicker substance) ]
                                    )
                                    [ decorateVideo substanceDynamic.video 185 140
                                    , paragraph substanceTextAttribute [ L.text substanceDynamic.name ]
                                    ]

                        Potential substancePotential ->
                            image
                                (substanceImageAttribute dimension
                                    ++ [ onMouseEnter (subClicker substance)
                                       ]
                                )
                                { src = substancePotential.image, description = "Potential" }

        Nothing ->
            case selectedMenu of
                Just activeMenu ->
                    case substance of
                        Relation substanceRelation ->
                            if substanceRelation.subId == first activeMenu then
                                column
                                    (substanceAttribute
                                        ++ second activeMenu
                                    )
                                    [ decorateVideo substanceRelation.media 200 150
                                    , paragraph selectedSubstanceTextAttribute [ L.text substanceRelation.name ]
                                    ]

                            else
                                column
                                    (substanceAttribute
                                        ++ [ onMouseEnter (subClicker substance) ]
                                    )
                                    [ decorateVideo substanceRelation.media 185 140
                                    , paragraph substanceTextAttribute [ L.text substanceRelation.name ]
                                    ]

                        Dynamic substanceDynamic ->
                            if substanceDynamic.subId == first activeMenu then
                                column
                                    (substanceAttribute
                                        ++ second activeMenu
                                    )
                                    [ decorateVideo substanceDynamic.video 200 150
                                    , paragraph selectedSubstanceTextAttribute [ L.text substanceDynamic.name ]
                                    ]

                            else
                                column
                                    (substanceAttribute
                                        ++ [ onMouseEnter (subClicker substance) ]
                                    )
                                    [ decorateVideo substanceDynamic.video 185 140
                                    , paragraph substanceTextAttribute [ L.text substanceDynamic.name ]
                                    ]

                        Potential substancePotential ->
                            if substancePotential.subId == first activeMenu then
                                image
                                    (substanceImageAttribute dimension
                                        ++ second activeMenu
                                    )
                                    { src = substancePotential.image, description = "Potential" }

                            else
                                image
                                    (substanceImageAttribute dimension
                                        ++ [ onMouseEnter (subClicker substance)
                                           ]
                                    )
                                    { src = substancePotential.image, description = "Potential" }

                Nothing ->
                    case substance of
                        Relation substanceRelation ->
                            column
                                (substanceAttribute
                                    ++ [ onMouseEnter (subClicker substance) ]
                                )
                                [ decorateVideo substanceRelation.media 185 140
                                , paragraph substanceTextAttribute [ L.text substanceRelation.name ]
                                ]

                        Dynamic substanceDynamic ->
                            column
                                (substanceAttribute
                                    ++ [ onMouseEnter (subClicker substance) ]
                                )
                                [ decorateVideo substanceDynamic.video 185 140
                                , paragraph substanceTextAttribute [ L.text substanceDynamic.name ]
                                ]

                        Potential substancePotential ->
                            image
                                (substanceImageAttribute dimension
                                    ++ [ onMouseEnter (subClicker substance)
                                       ]
                                )
                                { src = substancePotential.image, description = "Potential" }


setDeploymentList : List Substance -> Maybe (List String) -> List String -> Maybe Substance -> String -> List String
setDeploymentList childrenList originList resultList originSubtance idSubstance =
    case originList of
        Just deployedSubstanceList ->
            case originSubtance of
                Just substance ->
                    case substance of
                        Relation substanceRelation ->
                            if substanceRelation.subId == idSubstance then
                                idSubstance :: resultList

                            else
                                let
                                    firstList =
                                        extractIdList childrenList deployedSubstanceList (substanceRelation.subId :: resultList) substanceRelation.substance1 idSubstance
                                in
                                case firstList of
                                    [] ->
                                        extractIdList childrenList deployedSubstanceList (substanceRelation.subId :: resultList) substanceRelation.substance2 idSubstance

                                    x :: xs ->
                                        let
                                            secondList =
                                                extractIdList childrenList deployedSubstanceList (substanceRelation.subId :: resultList) substanceRelation.substance2 idSubstance
                                        in
                                        case secondList of
                                            [] ->
                                                firstList

                                            a :: ab ->
                                                if List.member idSubstance firstList then
                                                    firstList

                                                else
                                                    secondList

                        Dynamic substanceDynamic ->
                            if substanceDynamic.subId == idSubstance then
                                idSubstance :: resultList

                            else
                                extractIdList childrenList
                                    deployedSubstanceList
                                    (substanceDynamic.subId
                                        :: resultList
                                    )
                                    substanceDynamic.principal
                                    idSubstance
                                    ++ resultList

                        Potential subPot ->
                            []

                Nothing ->
                    []

        Nothing ->
            []


extractIdList : List Substance -> List String -> List String -> SubstanceLiee -> String -> List String
extractIdList childrenList originList rezList substanceLiee idSubstance =
    case substanceLiee of
        Lien idLien ->
            if idLien == idSubstance then
                idLien :: rezList

            else if List.member idLien originList then
                case List.head (List.filter (\sub -> testSubstance sub idLien) childrenList) of
                    Just subChild ->
                        setDeploymentList childrenList (Just originList) rezList (Just subChild) idSubstance

                    Nothing ->
                        []

            else
                []

        SubLiee substance ->
            setDeploymentList childrenList (Just originList) rezList (Just substance) idSubstance

        Error string ->
            rezList


xplodSub : List Substance -> Substance -> (Substance -> eleMsg) -> Maybe ( String, List (L.Attribute eleMsg) ) -> DeployedSubstance eleMsg
xplodSub substanceList substance subClicker subMenu =
    case substance of
        Relation substanceRelation ->
            { subId = substanceRelation.subId
            , deployment =
                column [ centerX, alignTop ]
                    [ displaySubstanceWithMenu substance subClicker subMenu Nothing ( 200, 150 )
                    , column [ centerX ]
                        [ image [ centerX ] { src = "img/Icons/triangle-relation.png", description = "Ouverture de Substance" }
                        , row []
                            [ activateLienSubstance (findSubstance substanceRelation.substance1 substanceList) subClicker subMenu ( 185, 140 )
                            , activateLienSubstance (findSubstance substanceRelation.substance2 substanceList) subClicker subMenu ( 185, 140 )
                            ]
                        ]
                    ]
            }

        Dynamic substanceDynamic ->
            { subId = substanceDynamic.subId
            , deployment =
                column [ centerX, alignTop ]
                    [ displaySubstanceWithMenu substance subClicker subMenu Nothing ( 200, 150 )
                    , column [ centerX ]
                        [ image [ centerX ] { src = "img/Icons/triangle-relation.png", description = "Ouverture de Substance" }
                        , activateLienSubstance (findSubstance substanceDynamic.principal substanceList) subClicker subMenu ( 185, 140 )
                        ]
                    ]
            }

        Potential substancePotential ->
            { subId = substancePotential.subId
            , deployment =
                column [ centerX, alignTop ]
                    [ displaySubstanceWithMenu substance subClicker subMenu Nothing ( 200, 150 ) ]
            }


xplodSubWithChild : List String -> List Substance -> Maybe Substance -> (Substance -> eleMsg) -> ( String, List (L.Attribute eleMsg) ) -> DeployedSubstance eleMsg
xplodSubWithChild deploymentList childrenList originSubstance subClicker subMenu =
    case originSubstance of
        Just substance ->
            case substance of
                Relation substanceRelation ->
                    { subId = substanceRelation.subId
                    , deployment =
                        column substanceAttribute
                            [ displaySubstanceWithMenu substance subClicker (Just subMenu) Nothing ( 200, 150 )
                            , column [ centerX ]
                                [ image [ centerX ] { src = "img/Icons/triangle-relation.png", description = "Ouverture de Substance" }
                                , row rowAttribute
                                    [ deployLienSubstance deploymentList childrenList substanceRelation.substance1 subClicker subMenu
                                    , deployLienSubstance deploymentList childrenList substanceRelation.substance2 subClicker subMenu
                                    ]
                                ]
                            ]
                    }

                Dynamic substanceDynamic ->
                    { subId = substanceDynamic.subId
                    , deployment =
                        column substanceAttribute
                            [ displaySubstanceWithMenu substance subClicker (Just subMenu) Nothing ( 200, 150 )
                            , column [ centerX ]
                                [ image [ centerX ] { src = "img/Icons/triangle-relation.png", description = "Ouverture de Substance" }
                                , deployLienSubstance deploymentList childrenList substanceDynamic.principal subClicker subMenu
                                ]
                            ]
                    }

                Potential substancePotential ->
                    { subId = substancePotential.subId
                    , deployment =
                        column substanceAttribute
                            [ displaySubstanceWithMenu substance subClicker (Just subMenu) Nothing ( 200, 150 ) ]
                    }

        Nothing ->
            { subId = ""
            , deployment = L.text ""
            }


deployLienSubstance : List String -> List Substance -> SubstanceLiee -> (Substance -> eleMsg) -> ( String, List (L.Attribute eleMsg) ) -> Element eleMsg
deployLienSubstance deploymentList childrenList substanceLiee subClicker subMenu =
    case substanceLiee of
        Lien idLien ->
            case List.head (List.filter (\sub -> testSubstance sub idLien) childrenList) of
                Just substance ->
                    if List.member idLien deploymentList then
                        xplodChild deploymentList childrenList substance subClicker subMenu

                    else
                        displaySubstanceWithMenu substance subClicker (Just subMenu) Nothing ( 200, 150 )

                Nothing ->
                    L.text "Erreur d'affichage"

        SubLiee substanceRez ->
            case substanceRez of
                Relation subRel ->
                    if List.member subRel.subId deploymentList then
                        xplodChild deploymentList childrenList substanceRez subClicker subMenu

                    else
                        displaySubstanceWithMenu substanceRez subClicker (Just subMenu) Nothing ( 200, 150 )

                Dynamic subDyn ->
                    if List.member subDyn.subId deploymentList then
                        xplodChild deploymentList childrenList substanceRez subClicker subMenu

                    else
                        displaySubstanceWithMenu substanceRez subClicker (Just subMenu) Nothing ( 200, 150 )

                Potential subPot ->
                    displaySubstanceWithMenu substanceRez subClicker (Just subMenu) Nothing ( 200, 150 )

        Error message ->
            L.text message


xplodChild : List String -> List Substance -> Substance -> (Substance -> eleMsg) -> ( String, List (L.Attribute eleMsg) ) -> Element eleMsg
xplodChild deploymentList childrenList originSubstance subClicker subMenu =
    case originSubstance of
        Relation substanceRelation ->
            column substanceAttribute
                [ displaySubstanceWithMenu originSubstance subClicker (Just subMenu) Nothing ( 200, 150 )
                , column [ centerX ]
                    [ image [ centerX ] { src = "img/Icons/triangle-relation.png", description = "Ouverture de Substance" }
                    , row rowAttribute
                        [ deployLienSubstance deploymentList childrenList substanceRelation.substance1 subClicker subMenu
                        , deployLienSubstance deploymentList childrenList substanceRelation.substance2 subClicker subMenu
                        ]
                    ]
                ]

        Dynamic substanceDynamic ->
            column substanceAttribute
                [ displaySubstanceWithMenu originSubstance subClicker (Just subMenu) Nothing ( 200, 150 )
                , column [ centerX ]
                    [ image [ centerX ] { src = "img/Icons/triangle-relation.png", description = "Ouverture de Substance" }
                    , deployLienSubstance deploymentList childrenList substanceDynamic.principal subClicker subMenu
                    ]
                ]

        Potential substancePotential ->
            column substanceAttribute
                [ displaySubstanceWithMenu originSubstance subClicker (Just subMenu) Nothing ( 200, 150 ) ]


displaySelectableSubstance : Substance -> (String -> eleMsg) -> (String -> eleMsg) -> Maybe (List String) -> Element eleMsg
displaySelectableSubstance substance subClicker cancelClick idList =
    case idList of
        Just stringList ->
            case substance of
                Relation substanceRelation ->
                    if List.member substanceRelation.subId stringList then
                        column
                            (selectedSubstanceAttribute
                                ++ [ onClick (cancelClick substanceRelation.subId) ]
                            )
                            [ decorateVideo substanceRelation.media 270 210
                            , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substanceRelation.name ]
                            ]

                    else
                        column
                            (substanceAttribute
                                ++ [ onClick (subClicker substanceRelation.subId) ]
                            )
                            [ decorateVideo substanceRelation.media 270 210
                            , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substanceRelation.name ]
                            ]

                Dynamic substanceDynamic ->
                    if List.member substanceDynamic.subId stringList then
                        column
                            (selectedSubstanceAttribute
                                ++ [ onClick (cancelClick substanceDynamic.subId) ]
                            )
                            [ decorateVideo substanceDynamic.video 270 210
                            , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substanceDynamic.name ]
                            ]

                    else
                        column
                            (substanceAttribute
                                ++ [ onClick (subClicker substanceDynamic.subId) ]
                            )
                            [ decorateVideo substanceDynamic.video 270 210
                            , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substanceDynamic.name ]
                            ]

                Potential substancePotential ->
                    if List.member substancePotential.subId stringList then
                        column
                            (selectedSubstanceAttribute
                                ++ [ onClick (cancelClick substancePotential.subId) ]
                            )
                            [ image [ L.width (fill |> maximum 270), L.height (fill |> maximum 210) ]
                                { src = substancePotential.image, description = "Potential" }
                            , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substancePotential.name ]
                            ]

                    else
                        column
                            (substanceAttribute
                                ++ [ onClick (subClicker substancePotential.subId) ]
                            )
                            [ image [ L.width (fill |> maximum 270), L.height (fill |> maximum 210) ]
                                { src = substancePotential.image, description = "Potential" }
                            , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substancePotential.name ]
                            ]

        Nothing ->
            case substance of
                Relation substanceRelation ->
                    column
                        (substanceAttribute
                            ++ [ onClick (subClicker substanceRelation.subId) ]
                        )
                        [ decorateVideo substanceRelation.media 270 210
                        , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substanceRelation.name ]
                        ]

                Dynamic substanceDynamic ->
                    column
                        (substanceAttribute
                            ++ [ onClick (subClicker substanceDynamic.subId) ]
                        )
                        [ decorateVideo substanceDynamic.video 270 210
                        , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substanceDynamic.name ]
                        ]

                Potential substancePotential ->
                    column
                        (substanceAttribute
                            ++ [ onClick (subClicker substancePotential.subId) ]
                        )
                        [ image [ L.width (fill |> maximum 270), L.height (fill |> maximum 210) ]
                            { src = substancePotential.image, description = "Potential" }
                        , paragraph [ L.width (fill |> maximum 185), Font.size 14 ] [ L.text substancePotential.name ]
                        ]


displaySubstanceStub : Substance -> (Substance -> eleMsg) -> ( Float, Float ) -> Element eleMsg
displaySubstanceStub substance subClicker dimension =
    case substance of
        Relation substanceRelation ->
            column
                (columnAttribute
                    ++ [ onClick (subClicker substance) ]
                )
                [ decorateVideo substanceRelation.media (round (first dimension * 1.2)) (round (second dimension * 1.2))
                , paragraph [] [ L.text substanceRelation.name ]
                ]

        Dynamic substanceDynamic ->
            column
                (columnAttribute
                    ++ [ onClick (subClicker substance) ]
                )
                [ decorateVideo substanceDynamic.video (round (first dimension * 0.9)) (round (second dimension * 0.9))
                , paragraph [] [ L.text substanceDynamic.name ]
                ]

        Potential substancePotential ->
            image
                [ onClick (subClicker substance)
                , L.width (fill |> maximum 400)
                , L.height (fill |> maximum 400)
                ]
                { src = substancePotential.image, description = "Potential" }


displaySubstanceZoomed : Substance -> eleMsg -> eleMsg -> eleMsg -> ( Float, Float ) -> Bool -> Bool -> Element eleMsg
displaySubstanceZoomed substance closeEvent recordEvent startSaving dimension isRecording isSaving =
    case substance of
        Relation substanceRelation ->
            column
                columnZoomAttribute
                [ decorateVideo substanceRelation.media
                    (round (first dimension * 1.0))
                    (round (second dimension * 1.0))
                , row
                    [ L.width fill, alignBottom, spacing 20 ]
                    [ paragraph zoomedSubstanceTextAttribute [ L.text substanceRelation.name ]
                    , button
                        [ alignRight, centerY ]
                        { onPress = Just closeEvent
                        , label =
                            paragraph
                                [ Font.color (rgb255 107 107 107)
                                , Font.size 30
                                , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
                                , Font.center
                                , mouseOver [ Font.color (rgb255 255 255 255) ]
                                ]
                                [ L.text "X" ]
                        }
                    ]
                ]

        Dynamic substanceDynamic ->
            if isRecording then
                column
                    columnZoomAttribute
                    [ row [ spacing 10 ]
                        [ el [ L.width (fillPortion 2) ]
                            (decorateVideo substanceDynamic.video
                                (round (first dimension * 0.6))
                                (round (second dimension * 1.0))
                            )
                        , column
                            [ spacing 10 ]
                            [ el [ L.width (fillPortion 1) ]
                                (L.html
                                    (video
                                        [ H.width (round (first dimension * 0.4))
                                        , H.height (round (second dimension * 1.0))
                                        , id "elmVid"
                                        , autoplay True
                                        ]
                                        []
                                    )
                                )
                            , el
                                [ alignBottom
                                , Bg.color (rgb255 229 229 229)
                                , L.height (px 50)
                                , L.width fill
                                ]
                                (el
                                    [ L.width fill
                                    , L.height fill
                                    , if isSaving then
                                        Bg.tiledX "img/Media/gif-record.gif"

                                      else
                                        Bg.tiledX "img/Media/sinus.png"
                                    , inFront
                                        (button
                                            [ centerX
                                            , centerY
                                            , padding 10
                                            , Border.rounded 100
                                            , Border.width 2
                                            , Border.color (rgb255 160 160 160)
                                            , Bg.color (rgb255 204 204 204)
                                            , mouseOver [ Bg.color (rgb 255 255 255) ]
                                            ]
                                            { onPress = Just startSaving
                                            , label =
                                                el
                                                    [ L.width (px 25)
                                                    , L.height (px 25)
                                                    , Bg.color (rgb255 158 11 15)
                                                    , centerX
                                                    , centerY
                                                    ]
                                                    (L.text "")
                                            }
                                        )
                                    ]
                                    (L.text "")
                                )
                            ]
                        ]
                    , row
                        [ L.width fill, alignBottom ]
                        [ paragraph zoomedSubstanceTextAttribute [ L.text substanceDynamic.name ]
                        , button [ alignRight, centerY ]
                            { onPress = Just recordEvent
                            , label = image [] { src = "img/Icons/icon-record-off.png", description = "Record Mode" }
                            }
                        , button
                            [ alignRight, centerY ]
                            { onPress = Just closeEvent
                            , label =
                                paragraph
                                    [ Font.color (rgb255 107 107 107)
                                    , Font.size 30
                                    , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
                                    , Font.center
                                    , mouseOver [ Font.color (rgb255 255 255 255) ]
                                    ]
                                    [ L.text "X" ]
                            }
                        ]
                    ]

            else
                column
                    columnZoomAttribute
                    [ decorateVideo substanceDynamic.video
                        (round (first dimension * 1.0))
                        (round (second dimension * 1.0))
                    , row
                        [ L.width fill, alignBottom, spacing 10 ]
                        [ paragraph zoomedSubstanceTextAttribute [ L.text substanceDynamic.name ]
                        , button [ alignRight, centerY ]
                            { onPress = Just recordEvent
                            , label = image [] { src = "img/Icons/icon-record.png", description = "Record Mode" }
                            }
                        , button
                            [ alignRight, centerY ]
                            { onPress = Just closeEvent
                            , label =
                                paragraph
                                    [ Font.color (rgb255 107 107 107)
                                    , Font.size 30
                                    , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
                                    , Font.center
                                    , mouseOver [ Font.color (rgb255 255 255 255) ]
                                    ]
                                    [ L.text "X" ]
                            }
                        ]
                    ]

        Potential substancePotential ->
            column columnZoomAttribute
                [ image
                    [ L.width (fill |> maximum (round (first dimension * 1.0)))
                    , L.height (fill |> maximum (round (second dimension * 1.0)))
                    ]
                    { src = substancePotential.image, description = "Potential" }
                , row
                    [ L.width fill, alignBottom ]
                    [ paragraph zoomedSubstanceTextAttribute [ L.text substancePotential.name ]
                    , button
                        [ alignRight, centerY ]
                        { onPress = Just closeEvent
                        , label =
                            paragraph
                                [ Font.color (rgb255 107 107 107)
                                , Font.size 30
                                , Font.family [ Font.typeface "Lucida Grande", Font.sansSerif ]
                                , Font.center
                                , mouseOver [ Font.color (rgb255 255 255 255) ]
                                ]
                                [ L.text "X" ]
                        }
                    ]
                ]


displaySubstancePlain : Substance -> ( Float, Float ) -> Element eleMsg
displaySubstancePlain substance dimension =
    case substance of
        Relation substanceRelation ->
            column
                columnAttribute
                [ decorateVideo substanceRelation.media (round (first dimension * 1.0)) (round (second dimension * 1.0))
                , paragraph [] [ L.text substanceRelation.name ]
                ]

        Dynamic substanceDynamic ->
            column
                columnAttribute
                [ decorateVideo substanceDynamic.video (round (first dimension * 1.0)) (round (second dimension * 1.0))
                , paragraph [] [ L.text substanceDynamic.name ]
                ]

        Potential substancePotential ->
            image
                [ L.width (fill |> maximum 400)
                , L.height (fill |> maximum 400)
                ]
                { src = substancePotential.image, description = "Potential" }


displayPremierLienSubstance : Substance -> ( Float, Float ) -> Element eleMsgAppEdited
displayPremierLienSubstance substance dimension =
    case substance of
        Relation substanceRelation ->
            visualizeLienSubstance substanceRelation.substance1 dimension

        Dynamic substanceDynamic ->
            visualizeLienSubstance substanceDynamic.principal dimension

        Potential substancePotential ->
            L.text "Pas d'enfant"


displaySecondLienSubstance : Substance -> ( Float, Float ) -> Element eleMsgAppEdited
displaySecondLienSubstance substance dimension =
    case substance of
        Relation substanceRelation ->
            visualizeLienSubstance substanceRelation.substance2 dimension

        Dynamic substanceDynamic ->
            L.text "Pas d'enfant"

        Potential substancePotential ->
            L.text "Pas d'enfant"


displayErrorMsg : Http.Error -> String
displayErrorMsg errorHttp =
    case errorHttp of
        Http.BadUrl stringString ->
            "Mauvaise adresse"

        Http.Timeout ->
            ""

        Http.NetworkError ->
            "Vérifier le réseau Internet et reccommencer"

        Http.BadStatus intBasics ->
            "BS1: Erreur de connexion"

        Http.BadBody stringString ->
            "BB1: Erreur de donnée"


gradientEffect : List (L.Attribute eleMsg)
gradientEffect =
    [ padding 3
    , spaceEvenly
    , gradient { angle = 0, steps = [ rgb255 150 150 150, rgb255 205 205 205 ] }
    ]


rowAttribute : List (L.Attribute eleMsg)
rowAttribute =
    [ Bg.color (rgb255 229 229 229)
    , padding 20
    , spacingXY 30 0
    ]


columnAttribute : List (L.Attribute eleMsg)
columnAttribute =
    [ alignTop, padding 3, spaceEvenly, L.width (fillPortion 4), L.height fill ]


columnZoomAttribute : List (L.Attribute eleMsg)
columnZoomAttribute =
    [ padding 30
    , Bg.color (rgb255 0 0 0)
    , centerX
    , centerY
    , Border.rounded 20
    , spacing 10
    ]


rowSubstanceAttribute : List (L.Attribute eleMsg)
rowSubstanceAttribute =
    [ spacing 30
    , Bg.color (rgb255 255 255 255)
    ]


rowPlainSubstanceAttribute : List (L.Attribute eleMsg)
rowPlainSubstanceAttribute =
    [ spacing 30
    , Bg.color (rgb255 229 229 229)
    , padding 20
    ]


transformAppel : (SubstanceDisplay -> eleMsg) -> Substance -> eleMsg
transformAppel activateSub substance =
    case substance of
        Relation substanceRelation ->
            activateSub (RelationDisplay substanceRelation)

        Dynamic substanceDynamic ->
            activateSub (DynamicDisplay substanceDynamic)

        Potential substancePotential ->
            activateSub (PotentialDisplay substancePotential)


displaySubstanceLink : Substance -> (Substance -> eleMsg) -> ( Float, Float ) -> Element eleMsg
displaySubstanceLink substance displayCall dimension =
    case substance of
        Relation substanceRelation ->
            el
                [ Bg.color (rgb255 0 0 0)
                , padding 2
                , centerX
                , centerY
                ]
                (el
                    [ centerX
                    , centerY
                    , onClick (displayCall substance)
                    ]
                    (L.html
                        (video
                            [ src substanceRelation.media
                            , controls True
                            , H.width (round (first dimension * 0.2))
                            , H.height (round (second dimension * 0.2))
                            ]
                            []
                        )
                    )
                )

        Dynamic substanceDynamic ->
            el
                [ Bg.color (rgb255 0 0 0)
                , padding 2
                , centerX
                , centerY
                ]
                (el
                    [ centerX
                    , centerY
                    , onClick (displayCall substance)
                    ]
                    (L.html
                        (video
                            [ src substanceDynamic.video
                            , controls True
                            , H.width (round (first dimension * 0.2))
                            , H.height (round (second dimension * 0.2))
                            ]
                            []
                        )
                    )
                )

        Potential substancePotential ->
            image
                [ centerX
                , centerY
                , onClick (displayCall substance)
                ]
                { src = substancePotential.image
                , description = "Substance Potentielle"
                }


activateLienSubstance : SubstanceLiee -> (Substance -> eleMsg) -> Maybe ( String, List (L.Attribute eleMsg) ) -> ( Float, Float ) -> Element eleMsg
activateLienSubstance substanceLiee subClicker subMenu dimension =
    case substanceLiee of
        SubLiee principale ->
            column [ alignTop, L.width (fillPortion 1), onClick (subClicker principale) ]
                [ column gradientEffect [ displaySubstanceWithMenu principale subClicker subMenu Nothing dimension ]
                ]

        Error err ->
            column []
                [ paragraph [] [ L.text err ]
                ]

        Lien str ->
            column []
                [ paragraph [] [ L.text ("Error LCA-4S Can't link substance:" ++ str) ]
                ]


visualizeLienSubstance : SubstanceLiee -> ( Float, Float ) -> Element eleMsg
visualizeLienSubstance substanceLiee dimension =
    case substanceLiee of
        SubLiee principale ->
            row rowAttribute
                [ column [ alignTop, L.width (fillPortion 1) ]
                    [ column gradientEffect [ displaySubstancePlain principale dimension ]
                    ]
                ]

        Error err ->
            column []
                [ paragraph [] [ L.text err ]
                ]

        Lien str ->
            column []
                [ paragraph [] [ L.text ("Error LCA-4S Can't link substance:" ++ str) ]
                ]


isRelation : SubstanceDisplay -> (SubstanceDisplay -> eleMsg) -> ( Float, Float ) -> Maybe (Element eleMsg)
isRelation substance activateSubstance dimension =
    case substance of
        RelationDisplay substanceRelation ->
            Maybe.Just
                (el
                    [ Bg.color (rgb255 0 0 0)
                    , padding 2
                    , centerX
                    , centerY
                    ]
                    (el
                        [ onClick (activateSubstance substance)
                        , centerX
                        , centerY
                        ]
                        (L.html
                            (video
                                [ src substanceRelation.media
                                , controls True
                                , H.width (round (first dimension * 0.2))
                                , H.height (round (second dimension * 0.2))
                                ]
                                []
                            )
                        )
                    )
                )

        _ ->
            Maybe.Nothing


decorateVideo : String -> Int -> Int -> Element eleMsg
decorateVideo videoLink maxWidth maxHeight =
    el
        [ centerX
        , centerY
        ]
        (L.html
            (video
                [ src videoLink
                , controls True
                , H.width maxWidth
                , H.height maxHeight
                ]
                []
            )
        )


displayInteractiveSubstanceList : List Substance -> (String -> eleMsg) -> (String -> eleMsg) -> Maybe (List String) -> Element eleMsg
displayInteractiveSubstanceList substanceList clickEventHandler cancelEventHandler idList =
    wrappedRow rowSubstanceAttribute
        (List.map (\a -> displaySelectableSubstance a clickEventHandler cancelEventHandler idList) substanceList)


displayInactiveSubstanceList : List Substance -> (Substance -> eleMsg) -> Maybe ( String, List (L.Attribute eleMsg) ) -> Maybe (DeployedSubstance eleMsg) -> Element eleMsg
displayInactiveSubstanceList substanceList clickEventHandler selectedMenu deployedSubstance =
    row rowPlainSubstanceAttribute
        (List.map (\a -> displaySubstanceWithMenu a clickEventHandler selectedMenu deployedSubstance ( 185, 140 )) substanceList)
